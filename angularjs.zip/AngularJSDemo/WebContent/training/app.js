/**
 * 
 */

var sampleApp = angular.module('sampleApp', [ 'ngRoute' ]);

sampleApp.config([ '$routeProvider', function($routeProvider) {
	$routeProvider.when('/AddNewOrder', {
		templateUrl : 'show_orders.html',
		controller : 'AddOrdersController'
	}).when('/ShowOrders', {
		templateUrl : 'show_orders.html',
		controller : 'ShowOrdersController'
	}).otherwise({
		redirectTo : '/AddNewOrder'
	});

} ]);

sampleApp.controller('AddOrdersController', function($scope) {
	$scope.message = "Add new order screen";
});

sampleApp.controller('ShowOrdersController', function($scope) {
	$scope.message = "Show order screen";
});