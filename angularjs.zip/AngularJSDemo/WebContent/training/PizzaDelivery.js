/**
 * 
 */

var app = angular.module("pizzaApp", []);
app.controller("pizzaCtrl", function($scope) {
	pizzas = [ {
		name : 'Pizza1',
		price : 10
	}, {
		name : 'Pizza2',
		price : 12
	}, {
		name : 'anotherPizza',
		price : 20
	} ];
	
});