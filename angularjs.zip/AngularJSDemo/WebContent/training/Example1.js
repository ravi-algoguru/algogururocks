//var app = angular.module("myApp", []);
app.controller("namesCtrl", function($scope) {
	$scope.names = [ {
		name : 'Jani',
		country : 'Norway'
	}, {
		name : 'Carl',
		country : 'Sweden'
	}, {
		name : 'Mary',
		country : 'England'
	} ];
});

//code defining custom module consisting of a filter. 
//The module needs to be included as dependency for using the filter, titlecase
var customFilterModule = angular.module('CustomFilterModule', []);
customFilterModule.filter('titlecase', function() {
	return function(input) {
		return input.replace(/\w\S*/g, function(txt) {
			return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
		});
	}
});

customFilterModule.filter('reverse', function() {
	return function(input) {
		return input.split('').reverse().join('');
	}
});

customFilterModule.filter('toggle', function() {
	return function(input) {
		return input.replace(/\S/g, function(txt) {
			return txt == txt.toUpperCase() ? txt.toLowerCase() : txt.toUpperCase();
		});
	}
});

app.controller('HelloCtrl', ['$scope', function($scope) {
	$scope.name = '';
}]);
