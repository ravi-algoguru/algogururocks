/**
 * 
 */

var mainApp = angular.module("mainApp", []);
mainApp.controller("studentController", function($scope) {
	$scope.reset = function() {
		$scope.firstname = "satish";
		$scope.lastname = "kumar";
		$scope.email = "satish.kumar@email.com";
	}
	$scope.reset();
});

mainApp.controller("MyController", function($scope) {
	$scope.myForm = {};
	$scope.myForm.car = "nissan";

	$scope.myForm.options = [ {
		id : "nissan",
		name : "Nissan"
	}, {
		id : "toyota",
		name : "Toyota"
	}, {
		id : "fiat",
		name : "Fiat"
	} ];
});

mainApp.controller("customersCtrl", ['$scope', '$http', function($scope, $http) {
/*	$http.get("data.json").success(function(response) {
		$scope.names = response.records;
	});
*/}]);

mainApp.factory('MathService', function() {
	var factory = {};
	factory.multiply = function(a, b) {
		return a * b;
	}
	return factory;
});

//Dependency injection
mainApp.service("CalcService", function(MathService) {
	this.square = function(a) {
		return MathService.multiply(a,a);
	}
});

mainApp.controller('CalcController', function($scope, CalcService) {
	$scope.square = function() {
		$scope.result = CalcService.square($scope.number);
	}
});