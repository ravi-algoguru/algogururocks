
public class Java8 {

}
