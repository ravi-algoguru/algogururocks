import java.util.Set;
import java.util.concurrent.Semaphore;

public class BoundedHasSet<T> {
	
	private final Set<T> set;
	private Semaphore bound;
}
