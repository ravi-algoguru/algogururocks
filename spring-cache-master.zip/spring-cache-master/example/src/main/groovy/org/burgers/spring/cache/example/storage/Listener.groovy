package org.burgers.spring.cache.example.storage

public interface Listener {
    void listen()
}