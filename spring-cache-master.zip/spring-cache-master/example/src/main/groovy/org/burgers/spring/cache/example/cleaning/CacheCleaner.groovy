package org.burgers.spring.cache.example.cleaning

interface CacheCleaner {
    void clean()

    void cleanWithAnnotations()

    void moreAdvancedCleaning()
}