##Camel Ride

**What is this?**

An example of a simple route that can be used to move a file from one directory to another.

Check out the FileMover class for more information.

The app module is a complete WAR file that can be run from the command line using the `maven:jetty run' command.

**Build Notes**

A 'PROJECT_OUTPUT_PATH' environment variable is required for this build. For example, 'c:/temp' will work just fine.