package com.demo.request;
import com.demo.core.manager.YakShopManager;
import com.demo.result.YakStockJob;

public class YakShopRequest  {
	static int count ;
	YakShopManager mgr;
	YakStockJob job;
	boolean queryStock = false;
    
	public YakShopRequest() {
 		mgr =  YakShopManager.ManagerInstanceHolder.getInstance();
 	}
 
    public void startShop(){
	  mgr.register(this);
	}
    
    public void stopShop(){
    	mgr.unregister(this);
    }
    
	public void queryStock(final String name, final int T) {
		queryStock = true;
		 mgr.getJobDone(  new YakStockJob(name, T)); 
	}
	
}
