package com.demo.ruleengine;
 

public interface Rule {
}
