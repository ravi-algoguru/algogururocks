package com.demo.ruleengine;
 

public class MilkCalculator implements Rule {
	    private   float A;
		private   float B;
	 		
	public MilkCalculator(float A, float B){
		this.A = A;
		this.B = B;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(A);
		result = prime * result + Float.floatToIntBits(B);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MilkCalculator other = (MilkCalculator) obj;
		if (Float.floatToIntBits(A) != Float.floatToIntBits(other.A))
			return false;
		if (Float.floatToIntBits(B) != Float.floatToIntBits(other.B))
			return false;
		return true;
	}

	public float getA() {
		return A;
	}

	public void setA(float a) {
		A = a;
	}

	public float getB() {
		return B;
	}

	public void setB(float b) {
		B = b;
	}

  
	
}
