package com.demo.ruleengine;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Logger;

import com.demo.result.YakStockJob;

public class RuleEngineParamHelper {
    
	MilkCalculator milkRuleCalculator = null;
	WoolCalculator woolRuleCalculator = null;
 	 
	void loadRuleCOnstants(){
		
		InputStream inputStream = null;

		try {
			Properties prop = new Properties();
			String propFileName = "./resources/config.properties";

			inputStream = this.getClass().getClassLoader().getResourceAsStream(propFileName);

			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file   not found in the classpath");
			}
             float milkA, woolC, milkB, woolD;
			milkA = Float.valueOf(prop.getProperty("milk.A").trim());
			milkB = Float.valueOf(prop.getProperty("milk.B").trim());
			woolC = Float.valueOf(prop.getProperty("wool.C").trim());
			woolD = Float.valueOf(prop.getProperty("wool.D").trim());
			
			milkRuleCalculator = new MilkCalculator(milkA, milkB);
			woolRuleCalculator = new WoolCalculator(woolC, woolD);
			
				
		} catch (Exception e) {
			Logger.getLogger(this.getClass().getName(), e.getMessage());
		} finally {
			try {
				inputStream.close();
			} catch (IOException e) {
				Logger.getLogger(this.getClass().getName(), e.getMessage());
			}
		}
	
	}
	public RuleEngineParamHelper() {
		 loadRuleCOnstants();
	}
	 
	
	public MilkCalculator getMilkRuleCalculator() {
		return milkRuleCalculator;
	}
	public void setMilkRuleCalculator(MilkCalculator milkRuleCalculator) {
		this.milkRuleCalculator = milkRuleCalculator;
	}
	public WoolCalculator getWoolRuleCalculator() {
		return woolRuleCalculator;
	}
	public void setWoolRuleCalculator(WoolCalculator woolRuleCalculator) {
		this.woolRuleCalculator = woolRuleCalculator;
	}
	 
	
}
