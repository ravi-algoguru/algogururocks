package com.demo.ruleengine;

import com.demo.result.YakStockJob;

public strictfp class WoolCalculator implements Rule{
    private   float C;
	private   float D;
  
	public WoolCalculator(float c, float d) {
	 	C = c;
		D = d;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(C);
		result = prime * result + Float.floatToIntBits(D);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WoolCalculator other = (WoolCalculator) obj;
		if (Float.floatToIntBits(C) != Float.floatToIntBits(other.C))
			return false;
		if (Float.floatToIntBits(D) != Float.floatToIntBits(other.D))
			return false;
		return true;
	}

	public float getC() {
		return C;
	}

	public void setC(float c) {
		C = c;
	}

	public float getD() {
		return D;
	}

	public void setD(float d) {
		D = d;
	}
 
 
 
}
