package com.demo.ruleengine;
 
public class RuleEngine extends Thread {
	
	private static RuleEngine ruleEngine; 
	private RuleEngineParamHelper ruleHelper;
	
	public static class RuleEngineInstanceHelper {

		public static RuleEngine getInstance() {
			if (ruleEngine == null) {
				ruleEngine = new RuleEngine();
				ruleEngine.start();
			}
			return ruleEngine;
		}

	}

	private   RuleEngine(){
		if (ruleEngine != null) {
			throw new IllegalStateException("RuleEngine already constructed");
		}
	 ruleHelper = new RuleEngineParamHelper();
	}

	protected Object readResolve() {
		return ruleEngine;
	}

	@Override
	public final Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

	public RuleEngineParamHelper getRuleHelper() {
		return ruleHelper;
	}

	public void run(){
	}
	
 }
