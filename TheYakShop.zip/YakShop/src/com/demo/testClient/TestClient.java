package com.demo.testClient;
import java.util.Scanner;

import com.demo.core.manager.YakShopManager;
import com.demo.request.YakShopRequest; 

public class TestClient {

	public static void main(String args[]) {

		YakShopManager mgr = YakShopManager.ManagerInstanceHolder.getInstance();
		System.out.println("Welcome to YakShop");
		
		Thread userInputThread = new Thread() {
			public void run() {
				Scanner scanner = new Scanner(System.in);
				while (true) {
					System.out.println("please enter TValue(Age in Days) to start or N to exit");
					String str = scanner.next();
					if (str.equals("N")) {
					   break;
					}
					
					int T = Integer.parseInt(str.trim());
					if(T <= 0){
						System.out.println(" TValue(Age in Days) shoul be greater than   0");
					    continue;
					}
					YakShopRequest myYokShop = new YakShopRequest();
					String fileName = "input";

					myYokShop.queryStock(fileName, T);
					try {
						Thread.sleep(200);
					} catch (InterruptedException e) {
					 	e.printStackTrace();
					}
					System.out.println("******************************************************************************");
				}
				scanner.close();
				System.exit(0);
			}
		};

		userInputThread.start();
	}

}
