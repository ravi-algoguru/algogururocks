package com.demo.result;

import com.demo.ruleengine.MilkCalculator;

public class MilkStock{
  
}
