package com.demo.result;

import java.math.RoundingMode;
import java.text.DecimalFormat;

import com.demo.model.Key;

public strictfp class YakStockJob {
	YakStock stock;
	private int T;
	private double milkStock;
	private int woolStock;
	private Key key;

	DecimalFormat df;
	{
		df = new DecimalFormat("#.###");
		df.setRoundingMode(RoundingMode.CEILING);
	}

	public YakStockJob(String name, int T) {
		if (stock == null)
			stock = new YakStock(name);
		this.T = T;
		this.key = new Key(name, T);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		YakStockJob other = (YakStockJob) obj;
		if (key == null) {
			if (other.key != null)
				return false;
		} else if (!key.equals(other.key))
			return false;
		return true;
	}

	public int getT() {
		return T;
	}

	public void setT(int t) {
		T = t;
	}

	public Key getKey() {
		return key;
	}

	public void setKey(Key key) {
		this.key = key;
	}

	public void setMilkStock(double milkStock) {
		this.milkStock = milkStock;
	}

	public void setWoolStock(int woolStock) {
		this.woolStock = woolStock;
	}

	public YakStock getStock() {
		return stock;
	}

	public void setStock(YakStock stock) {
		this.stock = stock;
	}

	public double getMilkStock() {
		return Double.valueOf(df.format(milkStock));
	}

	public void updateMilkStock(double milk) {

		this.milkStock += milk;
	}

	public int getWoolStock() {
		return woolStock;
	}

	public void updateWoolStock(int wool) {
		this.woolStock += wool;
	}
}
