package com.demo.result;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.Set;

import com.demo.model.Key;
import com.demo.model.Yak;

public class YakStock {
	 private String name;
	 Set<Yak> yakStock = new HashSet<Yak>();
	 private Key key;
	 
     public YakStock(String name){
    	 this.name = name;
    	 setKey(new Key(name));
     }
    
     public YakStock(){
    	 
     }
     
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public Set<Yak> getYakStock() {
		return yakStock;
	}

	public void setYakStock(Set<Yak> yakStock) {
		this.yakStock = yakStock;
	}

	public Key getKey() {
		return key;
	}

	public void setKey(Key key) {
		this.key = key;
	}
	 
}
