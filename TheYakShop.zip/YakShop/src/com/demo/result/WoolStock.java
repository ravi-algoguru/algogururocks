package com.demo.result;

public class WoolStock {

}
