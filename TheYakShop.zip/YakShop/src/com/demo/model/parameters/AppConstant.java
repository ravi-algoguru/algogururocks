package com.demo.model.parameters;

public class AppConstant {
   //input schema
	public static final String XML_ROOT= "herd";
	public static final String XML_ELEMENT = "labyak";
	public static final String[] XML_ATTRIBUTE = new String[]{"name", "age", "sex"};
	 
}
