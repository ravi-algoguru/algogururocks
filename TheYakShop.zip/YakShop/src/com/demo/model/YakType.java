package com.demo.model;

public enum YakType {
    LABYAK;
}
