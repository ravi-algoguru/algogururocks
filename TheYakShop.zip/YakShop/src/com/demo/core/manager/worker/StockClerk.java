package com.demo.core.manager.worker;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.demo.core.input.helper.InputHelper; 
import com.demo.core.manager.YakShopManager;
import com.demo.core.manager.jobscheduler.JobQueue;
import com.demo.core.manager.session.ISession;
import com.demo.model.Key;
import com.demo.model.Yak;
import com.demo.result.YakStockJob;
import com.demo.ruleengine.MilkCalculator;
import com.demo.ruleengine.RuleEngine;
import com.demo.ruleengine.RuleEngineParamHelper;
import com.demo.ruleengine.WoolCalculator;
import com.demo.result.YakStock;

public  class StockClerk extends Thread {
	Logger log = Logger.getLogger(this.getClass().getName());
	JobQueue calQueue = new JobQueue();

	private RuleEngineParamHelper ruleEngineHelper;
	private ISession session;
	private Map<Key, YakStockJob> stockMap;
	private Map<Key, YakStock> herdMap;
	private InputHelper inputHelper;
	private YakShopManager manager;
	private static StockClerk clerk;

	public static class StockClerkHolder {

		public static StockClerk getInstance() {
			if (clerk == null) {
				clerk = new StockClerk();
				clerk.setDaemon(true);
				clerk.start();
			}
			return clerk;
		}
	}

	private StockClerk() {
		if (clerk != null)
			throw new IllegalStateException("StockClerk already constructed");
		manager = YakShopManager.ManagerInstanceHolder.getInstance();
		session = ISession.SessionInstanceHolder.getInstance();
		stockMap = session.getStockMap();
		herdMap = session.getHerdMap();
		inputHelper = InputHelper.InputHelperHolder.getInstance();
		ruleEngineHelper = RuleEngine.RuleEngineInstanceHelper.getInstance().getRuleHelper();
	}

	public void run() {
		while (true) {
			pollJob();
		}
	}

	private void pollJob() {

		YakStockJob job = null;
		try {
			job = (YakStockJob) calQueue.take();
		} catch (InterruptedException e) {
			log.log(Level.SEVERE, e.getMessage());
		}

		if (stockMap.get(job.getKey()) != null) {
			job = (YakStockJob) stockMap.get(job.getKey());
		} else {
			getHerdStock(job);
			stockMap.put(job.getKey(), job);
		}
		while (true) {
			if (stockMap.get(job.getKey()) != null) {
				manager.notifyResult(job);
				break;
			}
		}

	}

	public void getHerdStock(YakStockJob tStock) {
		YakStock stock = herdMap.get(tStock.getStock().getKey());
		if (stock == null) {

			inputHelper.getFileListToProcess();
			inputHelper.process(tStock);
		} 
		while(true){
		stock = herdMap.get(tStock.getStock().getKey());

		if (stock != null) {
			tStock.getStock().getYakStock().addAll(stock.getYakStock());
			applyTransaction(tStock);
			break;
 			}
		}
	}

	private strictfp void applyTransaction(YakStockJob tStock) {

		Collection<Yak> result = tStock.getStock().getYakStock();
		Iterator<Yak> iter = result.iterator();
		int woolSkinStock = 0;
		double milkStock = 0;
		int T = tStock.getT();

		while (iter.hasNext()) {
			Yak temp = iter.next();
			Yak rYak = new Yak(temp.getType());
			
			rYak.name(temp.getName())
				.age((temp.getAge() * 100 + T) / 100)
					.sex(temp.getSex());
			
			
			milkStock = calculateMilk(temp, T);
			woolSkinStock = calculateWool(temp, T);
			
			tStock.updateMilkStock(milkStock);
			tStock.updateWoolStock(woolSkinStock);
			result.add(rYak);
		}

	}

	private strictfp int calculateWool(Yak temp, int days) {
		int woolSkin = 0;
 
		WoolCalculator woolRule = ruleEngineHelper.getWoolRuleCalculator();
		
		float startAge = temp.getAge();
 	 
		
		int presentAge = (int) (startAge * 100) + days;
		if (presentAge < 100)
			return woolSkin;
		if (presentAge > 1000) {
			presentAge = 1000 - (int) (startAge * 100);
			woolSkin = 1 +(int)(presentAge /(woolRule.getC() + (presentAge * woolRule.getD())));
		}
		else{
			woolSkin = 1 + (int) ((days - 1) / (woolRule.getC() +( presentAge * woolRule.getD())));
		}
		return woolSkin;

	}

	private strictfp double calculateMilk(Yak temp, int days) {
		MilkCalculator milkRule= ruleEngineHelper.getMilkRuleCalculator();
		
		double milkProduced = 0.000; 
		float age = temp.getAge();
		int presentAge = (int) (age * 100) + days;
		if (presentAge > 1000) {
			presentAge = 1000 - (int) (age * 100);
		}
		
		int iDay = (int) (age * 100);

		while (iDay < presentAge) {
			milkProduced += (milkRule.getA() - (iDay * milkRule.getB()));
			iDay++;
		}
		
		return milkProduced;

	}

	public void calculate(YakStockJob job) {
		try {
			calQueue.put(job);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
