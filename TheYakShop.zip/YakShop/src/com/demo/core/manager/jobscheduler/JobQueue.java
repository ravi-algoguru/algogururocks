package com.demo.core.manager.jobscheduler;


import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class JobQueue {
	   private static final int MAX_ARRAY_SIZE = Integer.MAX_VALUE - 8;
	   final Lock iLock = new ReentrantLock();
	   final Condition notFull  = iLock.newCondition(); 
	   final Condition notEmpty = iLock.newCondition(); 

	   final Object[] items = new Object[16];
	   int putptr, takeptr, count;

	   public void put(Object x) throws InterruptedException {
	     iLock.lock();
	     try {
	       while (count == items.length)
	         notFull.await();
	       items[putptr] = x;
	       if (++putptr == items.length) putptr = 0;
	       ++count;
	       notEmpty.signal();
	     } finally {
	       iLock.unlock();
	     }
	   }

	   public Object take() throws InterruptedException {
	     iLock.lock();
	     try {
	       while (count == 0)
	         notEmpty.await();
	       Object x = items[takeptr];
	       if (++takeptr == items.length) takeptr = 0;
	       --count;
	       notFull.signal();
	       return x;
	     } finally {
	       iLock.unlock();
	     }
	   }
	   
	   @SuppressWarnings("unused")
	private void expandSize(Object[] array, int oldCapacity) {
		 	Object[] newArray = null;
	 			int newCapacity = oldCapacity + ((oldCapacity < 64) ? (oldCapacity + 2) :(oldCapacity >> 1));
					if (newCapacity - MAX_ARRAY_SIZE > 0) { 
						if(oldCapacity < MAX_ARRAY_SIZE)
							newCapacity = MAX_ARRAY_SIZE;
						else
							throw new OutOfMemoryError();
					}
					newArray = new Object[newCapacity];
		 
			if (newArray == null)  
				Thread.yield();
			System.arraycopy(array, 0, newArray, 0, oldCapacity);
	 	}

	   public static void main(String[] args){
		 
		   
		   JobQueue bb = new JobQueue();
		 
		   Thread t1 = new Thread(new Runnable(){
			  public void run(){
				  int i =0;
				  try {
					   while(i++ < 100){
					bb.put(new Integer(i));
					System.out.println("put : " +i);
					   }
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		   }
			  
		   });
		   Thread t2 = new Thread(new Runnable(){
				  public void run(){
					  int i =0;
					  try {
						   while(true){
								System.out.println("take : " +  bb.take());
								Thread.yield();
			 		   }
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			   }
				  
			   });
		   
		   t1.start();
		   t2.start();
	   }
	 }
