package com.demo.core.manager.jobscheduler;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.demo.core.manager.worker.StockClerk;
import com.demo.core.manager.worker.StockClerk.StockClerkHolder;
import com.demo.result.YakStockJob;

public class JobScheduler extends Thread {
	private final JobQueue queue = new JobQueue();
	private static JobScheduler jobScheduler;
	private static StockClerk clerk = StockClerk.StockClerkHolder.getInstance();
	Logger log = Logger.getLogger(this.getClass().getName());

	public static class JobSchedulerHolder {
		public static JobScheduler getInstance() {
			if (jobScheduler == null) {
				jobScheduler = new JobScheduler();
				jobScheduler.start();
			}
			return jobScheduler;
		}
	}

	private JobScheduler() {
		if (jobScheduler != null) {
			throw new IllegalStateException("TrasanctionManager already constructed");
		}
	}

	protected Object readResolve() {
		return jobScheduler;
	}

	@Override
	public final Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

	public void run() {
		while (true)
			excute();
	}

	public void excute() {
		try {
			YakStockJob job = (YakStockJob) queue.take();
	 		clerk.calculate(job);
		} catch (InterruptedException e) {
			log.log(Level.SEVERE, e.getMessage());
		}
	}

	public void processJob(YakStockJob job) {

		try {
			queue.put(job);
	 		} catch (InterruptedException e) {
			log.log(Level.SEVERE, e.getMessage());

		}

	}
}
