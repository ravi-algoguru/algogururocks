package com.demo.core.manager;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.demo.core.manager.jobscheduler.JobQueue;
import com.demo.core.manager.jobscheduler.JobScheduler;
import com.demo.core.manager.session.ISession;  
import com.demo.model.Yak;
import com.demo.request.YakShopRequest;
import com.demo.result.YakStockJob;

public class YakShopManager extends Thread {
	private static YakShopManager mgr;
	private ISession session;
	private JobScheduler myJobScheduler;
	private JobQueue yakShopMgrToDoList = new JobQueue();

	Logger log = Logger.getLogger(this.getClass().getName());
	
	public void run() {

	//	log.info("Manager Started");
		while (true) {
			assignJobToScheduler();
		}

	}

	private void assignJobToScheduler() {
		try {
			YakStockJob job = (YakStockJob) yakShopMgrToDoList.take();
		 	myJobScheduler.processJob(job);
		} catch (InterruptedException e) {
			log.log(Level.SEVERE, e.getMessage());
		}
	}

	public void notifyResult(YakStockJob stock) {
		System.out.println("In Stock: ");
		System.out.println("	" + stock.getMilkStock() + " liters of milk");
		System.out.println("	" + stock.getWoolStock() + " skins of wool");

		System.out.println("Herd : ");
		for (Yak y : stock.getStock().getYakStock())
			System.out.println("	" + y);
	}

	public void getJobDone(YakStockJob job) {

		try {
			yakShopMgrToDoList.put(job);
	 	} catch (InterruptedException e) {
	 		log.log(Level.SEVERE, e.getMessage());
	 	}

	}

	public static class ManagerInstanceHolder {

		public static YakShopManager getInstance() {
			if (mgr == null) {
				mgr = new YakShopManager();
				mgr.start();
			}
			return mgr;
		}

	}

	private YakShopManager() {
		if (mgr != null) {
			throw new IllegalStateException("TrasanctionManager already constructed");
		}
		session = ISession.SessionInstanceHolder.getInstance();
		myJobScheduler = JobScheduler.JobSchedulerHolder.getInstance();
	}

	protected Object readResolve() {
		return mgr;
	}

	@Override
	public final Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

	public void register(YakShopRequest yakShop) {
		initializeYakShop();
	}

	private void initializeYakShop() {

	}

	public void unregister(YakShopRequest yakShop) {
		cleanUpShop();
	}

	private void cleanUpShop() {

	}

}
