package com.demo.core.manager.session;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.demo.model.Key;
import com.demo.result.YakStockJob;
import com.demo.result.YakStock;

public class ISession   {
 	Map<Key, YakStockJob> stockMap = new ConcurrentHashMap<Key, YakStockJob>();
	Map<Key, YakStock>  herdMap = new ConcurrentHashMap<Key,YakStock>();
	 
	static ISession globalSession; 

	public Map<Key, YakStockJob> getStockMap() {
		return stockMap;
	}

	public void setStockMap(Map<Key, YakStockJob>  stockMap) {
		this.stockMap = stockMap;
	}
	

	public Map<Key, YakStock> getHerdMap() {
		return herdMap;
	}

	public void setHerdMap(Map<Key, YakStock> herdMap) {
		this.herdMap = herdMap;
	}


	public static class SessionInstanceHolder{
		
	 	  public static ISession getInstance(){
	 		  if(globalSession == null){
	 			 globalSession = new ISession ();
	  		  }
	 		  return globalSession;
	 	  }
	 	  
	 	}
		private ISession(){
		 	 if (globalSession != null) {
			        throw new IllegalStateException("TrasanctionManager already constructed");
			    }
		  
		}
			
		protected Object readResolve() {
	        return globalSession;
	    }
		
		@Override 
		public final Object clone() throws CloneNotSupportedException {
		    throw new CloneNotSupportedException();
		  }
}
