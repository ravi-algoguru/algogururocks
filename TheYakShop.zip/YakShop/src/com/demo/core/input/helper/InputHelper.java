package com.demo.core.input.helper;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.demo.core.input.InputReader;
import com.demo.core.input.impl.XMLInputReader;
import com.demo.core.manager.jobscheduler.JobQueue;
import com.demo.core.manager.session.ISession;
import com.demo.result.YakStockJob;

public class InputHelper extends Thread {
    Logger log = Logger.getLogger(this.getClass().getName());
    
	private ISession session = ISession.SessionInstanceHolder.getInstance();
	private String configLocation;
	private String fileType;
	private Collection<File> fileList;
	private InputReader inputReader;
	private static InputHelper inputHelper;
	private JobQueue inputQueue = new JobQueue();

	public static class InputHelperHolder {

		public static InputHelper getInstance() {
			if (inputHelper == null) {
				inputHelper = new InputHelper();
				inputHelper.setDaemon(true);
				inputHelper.start();
			}
			return inputHelper;
		}
	}

	private InputHelper() {
		if (inputHelper != null) {
			throw new IllegalStateException("inputHELPER already constructed");
		}

	}

	protected Object readResolve() {
		return inputHelper;
	}

	@Override
	public final Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

	public void run() {
		loadConfigProperties();
		fileList = loadInputFiles();
		if (fileType.equalsIgnoreCase("XML"))
			inputReader = new XMLInputReader();
	//	log.info("InputHelper Started");
		while (true) {
				processFile();
		}

	}

	private void processFile( ) {
		YakStockJob job = null;
		try {
			job = (YakStockJob)inputQueue.take();
		} catch (InterruptedException e) {
		log.log(Level.SEVERE, e.getMessage());
		}
		getFileListToProcess();
		for (File f : fileList)
			inputReader.read(f, job.getStock());
		session.getHerdMap().put(job.getStock().getKey(), job.getStock());
		 
	}

	public Collection<File> getFileListToProcess() {
		if (fileList == null)
			fileList = loadInputFiles();
		return fileList;
	}

	private void loadConfigProperties() {
		InputStream inputStream = null;

		try {
			Properties prop = new Properties();
			String propFileName = "./resources/config.properties";

			inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);

			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file   not found in the classpath");
			}

			configLocation = prop.getProperty("input.location");
			fileType = prop.getProperty("file.type");
			
		} catch (Exception e) {
			Logger.getLogger(this.getClass().getName(), e.getMessage());
		} finally {
			try {
				inputStream.close();
			} catch (IOException e) {
				Logger.getLogger(this.getClass().getName(), e.getMessage());
			}
		}

	}

	private Collection<File> loadInputFiles() {
		fileList = new ArrayList<File>();
		if (configLocation == null) {
			return fileList;
		}
		File inputDir = new File(configLocation);
		listFilesForFolder(inputDir, fileList);
		return fileList;
	}

	private void listFilesForFolder(File folder, Collection<File> fileList) {
		for (final File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry, fileList);
			} else {
				fileList.add(fileEntry);
			}
		}
	}

	public void process(YakStockJob stock) {

		try {
			inputQueue.put(stock);
		} catch (InterruptedException e) {
			log.log(Level.SEVERE, e.getMessage());
		}

	}

}
