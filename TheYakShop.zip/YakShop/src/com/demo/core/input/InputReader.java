package com.demo.core.input;
import java.io.File;

import com.demo.result.YakStock;

public interface InputReader {
    void read(File file, YakStock stock);
}
