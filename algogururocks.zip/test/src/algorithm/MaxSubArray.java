/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package algogururocks;

/**
 *Kadane's Algorithm(arr[1..n])
begin
    (max, a, b) := (-INFINITY, 0, 0)
    curr := 0
    aa := 1
    for bb := 1 to n do
        curr := curr + arr[bb]
        if curr > max then
            (max, a, b) := (curr, aa, bb)
        endif

        if curr < 0 then
            curr := 0
            aa := bb + 1
        endif
    endfor

    return (max, a, b)
end
 * 
 * 
 * #include <stdio.h>

#define SIZEOF(arr) (sizeof(arr)/sizeof(arr[0]))

int arr[] = { 2, -3, 4, -1, 5, -1, -3, 6, -1, -1, -4, 2, -1};

void MaxSum(int arr[],int length)
{
       int max,sum;
       int i = 0 ;

       max = sum = arr[0];

       for(i=1;i<length;i++)
       {
               sum += arr[i];
               if(sum > max)
               {
                       max = sum;
               }

               if(sum < 0)
               {
                       sum = 0;
               }
       }
       printf("The max sum is : %d\n",max);
}


void PrintArray(int arr[],int size)
{
       int i;
       for(i=0;i<size;i++)
               printf("%d ",arr[i]);
       printf("\n");
}

int main()
{
       PrintArray(arr,SIZEOF(arr));
       MaxSum(arr,SIZEOF(arr));
       return 0;
}
 * @author alok
 */
public class MaxSubArray {

    public static void main(String[]args){
        int[] arr=new int[]{-1000,1,5,-3,4,-6,7,100,-1,-200,4 , 5, -10,20, 3, 4, 6, -8};
       int sum = 0,
                max = Integer.MIN_VALUE,
                a = 0, b = 0,  i = 0;
          
        for (int j = 0; j < arr.length; j++) {
            sum += arr[j];
            if (sum < 0) {
                sum = 0;
                i = j + 1;
            } else if ( sum>max) {
                max=sum;
                a=i;b=j;
            }
        }
      int[] res={max,a,b};
       System.out.println("sum : " + res[0]+", start:"+res[1]+", end: "+res[2]+"\n elements : ");
      int k=a;
       while(k<=b){
           System.out.print(arr[k++]+" , ");
       }
      
    }
}
