/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

/**
 *
 * @author alok
 */
public class BinaryTree {

    Node head;
    Node root;
    Node senital = new Node('&');
    Node candidate = null;

    public BinaryTree() {
        root = null;
    // root.leftChild=null;
    //  root.rightChild=null;
    }

    public void insert(int data) {
        if (root == null) {
            root = new Node(data);
            return;
        }
        insert(root, data);
    }

    private void insert(Node node, int data) {
        if (node == null) {
            node = new Node(data);
            // node.leftChild = senital;
            //node.rightChild = senital;
            //   System.out.println(data);
            return;
        }
        if (data < node.data) {
            if (node.leftChild == null) {
                node.leftChild = new Node(data);
                node.leftChild.parent = node;
            } else {
                insert(node.leftChild, data);
            }
        } else {
            if (node.rightChild == null) {
                node.rightChild = new Node(data);
                node.rightChild.parent = node;
            } else {
                insert(node.rightChild, data);
            }
        }
    }

    public boolean find(int data) {
        return find(root, data);
    }

    private boolean find(Node node, int data) {

        if (node.data == data) {
            return true;
        }
        if (node != null) {
            if (node.leftChild != null) {
                find(node.leftChild, data);
            } else {
                find(node.rightChild, data);
            }
        }
        return false;
    }

    public void printTree() {
        inOrderLevelTreversal(root);
    }

    private void inOrderLevelTreversal(Node node) {
        if (node == null) {
            return;
        } else {
            inOrderLevelTreversal(node.leftChild);
            System.out.print(node.data + " : ");
            if (node.parent != null) {
                System.out.print(" p " + node.parent.data + " , ");
            }
            inOrderLevelTreversal(node.rightChild);
        }
    }

    public void iterative_inOrder() {
        iterative_inOrder(root);
    }

    private void iterative_inOrder(Node node) {
        if (node == null) {
            return;
        }
        Stack<Node> stack = new Stack<Node>();
        int maxSize=0,size=0;
        while (true) {
            while (node != null) {
                stack.push(node);
                size++;
                node = node.leftChild;
                if(size > maxSize)
                    maxSize=size;
            }
            if (stack.size() == 0) {
                break;
            }
            node = stack.pop();
            size--;
            System.out.print(node.data + " , ");
            node = node.rightChild;
        }
        System.out.print("\ninorder :max stackSize ="+maxSize);
    }

    public void iterative_preOrder() {
        iterative_preOrder(root);
    }

    private void iterative_preOrder(Node node) {
        if (node == null) {
            return;
        }
        Stack<Node> stack = new Stack<Node>();
        int maxSize=0,size=0;
        while (true) {
            while (node != null) {
                System.out.print(node.data + " , ");
                stack.push(node);
                size++;
                node = node.leftChild;
                if(node==null){
                    if(maxSize< size)
                        maxSize=size;
                }
            }
            if (stack.size() == 0) {
                break;
            }
            node = stack.pop();
            size--;
            node = node.rightChild;
        }
        System.out.print("\n preorder :max stackSize ="+maxSize);
    }

    public void iterative_postOrder() {
        iterative_postOrder(root);
    }

    private void iterative_postOrder(Node node) {
        Stack<Node> stack = new Stack<Node>();
        Node delNode = null;
        int maxSize=0,size=0;
        while (true) {
            while (node != null) {
                stack.push(node);
                size++;
                node = node.leftChild;
                if(node==null){
                    if(size > maxSize)
                        size=maxSize;
                }
            }
            if (stack.size() == 0) {
                break;
            }
            if (stack.peek().rightChild == null || delNode == stack.peek().rightChild) {
                delNode = stack.pop();
                size--;
                System.out.print(delNode.data + " , ");
            } else {
                node = stack.peek().rightChild;
            }
//            if (stack.peek().rightChild != null && delNode != stack.peek().rightChild) {
//                node = stack.peek().rightChild;
//            } else {
//                delNode = stack.pop();
//                System.out.print(delNode.data + " , ");
//                if (!stack.isEmpty() && delNode != stack.peek().rightChild) {
//                    node = stack.peek().rightChild;
//                }
//            }
        }
        System.out.print("\n postorder: max stackSize ="+maxSize);
    }

    public void iterative_levelOrder() {
        iterative_levelOrder(root);
    }

    private void iterative_levelOrder(Node node) {
        Queue<Node> queue = new LinkedList();
        queue.offer(node);
        Node mark = new Node('&');
        queue.offer(mark);
        while (true) {
            Node delNode = queue.pull();
            if (queue.isEmpty() || delNode == null) {
                break;
            }
            if (delNode != mark) {
                System.out.print(delNode.data + " , ");
                if (delNode.leftChild != null) {
                    queue.offer(delNode.leftChild);
                }
                if (delNode.rightChild != null) {
                    queue.offer(delNode.rightChild);
                }
            } else {
                System.out.println();
                queue.offer(mark);
            }
        }
    }

    public int getHeight() {
        if (root == null) {
            return 0;
        }
        if (root.leftChild == null && root.rightChild == null) {
            return 1;
        }
        return getHeight(root);
    }

    private int getHeight(Node node) {
        if (node == null) {
            return 0;
        }
        return (Math.max(getHeight(node.leftChild), getHeight(node.rightChild)) + 1);
    }

    public boolean isBst() {
        return isBst(root);
    }

    private boolean isBst(Node node) {
        if (node == null) {
            return true;
        }
        if (node.leftChild == null && node.rightChild == null) {
            return true;
        }
        return (node.data > findMax(node.leftChild) && node.data < findMin(node.rightChild) && isBst(node.leftChild) && isBst(node.rightChild));
    }

    public int findMin(Node node) {
        if (node == null) {
            return 100;
        }
        while (node.leftChild != null) {
            node = node.leftChild;
        }
        return node.data;
    }

    public int findMax(Node node) {
        if (node == null) {
            return -100;
        }
        while (node.rightChild != null) {
            node = node.rightChild;
        }
        return node.data;
    }

    public void printAllPaths() {
        int[] arr = new int[100];
        int pathSum = -1;
        printAllPaths(arr, root, pathSum);
    }

    private void printAllPaths(int[] arr, Node node, int pathSum) {
        arr[++pathSum] = node.data;
        if (node.leftChild == null && node.rightChild == null) {
            printPath(arr, pathSum);
        }
        if (node.leftChild != null) {
            printAllPaths(arr, node.leftChild, pathSum);
        }
        if (node.rightChild != null) {
            printAllPaths(arr, node.rightChild, pathSum);
        }
    }

    private void printPath(int[] arr, int pathSum) {
        int data = 0;
        System.out.println();
        for (; data <= pathSum; data++) {
            System.out.print(arr[data] + " , ");
        }
    }

    public void hasPathSum(int data) {
        int[] arr = new int[100];
        int pathSum = -1;
        hasPathSum(arr, root, pathSum, data);
    }

    private void hasPathSum(int[] arr, Node node, int pathSum, int num) {
        if (node == null) {
            return;
        }
        arr[++pathSum] = node.data;
        num -= node.data;
        if (num == 0 && (node.leftChild == null && node.rightChild == null)) {
            System.out.print("\n has path sum");
            printPath(arr, pathSum);
        }
        if (node.leftChild != null && num >= node.leftChild.data) {
            hasPathSum(arr, node.leftChild, pathSum, num);
        }
        if (node.rightChild != null && num >= node.rightChild.data) {
            hasPathSum(arr, node.rightChild, pathSum, num);
        }
    }
    /*void printnode(Node x, int h) 
    {
    for (int i = 0;i<h;i++)
    System.out.print(" ");
    System.out.println("[" + x + "]"); 
    } 
    private  void showR(Node t, int h) 
    { 
    if (t == null) { printnode(null, h); return; } 
    showR(t.rightChild, h+1); 
    printnode(t.data, h); 
    showR(t.leftChild, h+1); 
    } 
    void show() 
    { showR(root, 0); } 
     */

    /*We use a global pointer candidate and the following
    algorithm: at each node we make one two-way
    comparison to decide whether the searched-for
    value is smaller than the node’s value or not.
    If the searched-for value is smaller we turn left,
    otherwise we let candidate point at the current
    node and turn right. When an empty node is found
    we examine candidate. The search has been successful
    if and only if candidate points to a node
    containing the searched-for value.
    this algorithm we obtain the same simple termination
    condition as when using a sentinel but
    instead of removing the test for empty pointers
    we remove the extra comparison made at each
    node in the tree. In the likely case that element
    comparisons are more expensive than pointer
    operations,
    The maximal number of comparisons required
    by this algorithm equals the height of the tree
    plus one, the extra comparison being made when
    testing the value pointed to by candidate.*/
    Node candidateBST(int data) {

        return candidateBST(root, data);

    }

    Node candidateBST(Node node, int data) {
        Node candidate = null;
        while (node != null) {
            if (data < node.data) {
                node = node.leftChild;                // { *** Try left subtree *** }
            } else {
                candidate = node;// { *** Save last rightward node *** }
                node = node.rightChild;// { *** Try right subtree *** }
            }
        }
        if (candidate != null && candidate.data == data) {
            return candidate;
        } else {
            return null;
        }
    }

    public boolean Delete(int data) {
        Node grand = null;
        boolean isLeft = false;
        return Delete(data, root, grand, isLeft);
    }

    private boolean Delete(int data, Node node, Node grand, boolean isLeft) {
        if (node == null) {
            return false;
        }
        if (data < node.data) {
            return Delete(data, node.leftChild, node, true);
        } else if (data > node.data) {
            return Delete(data, node.rightChild, node, false);
        } else {
            if (node.leftChild != null && node.rightChild != null) {
                if (isLeft == true) {
                    Node temp = grand.leftChild;
                    grand.leftChild = findReplacement(node.rightChild);
                    node = grand.leftChild;
                    node.leftChild = temp.leftChild;
                    node.rightChild = temp.rightChild;
                } else {
                    Node temp = grand.rightChild;
                    grand.rightChild = findReplacement(node.rightChild);
                    node = grand.leftChild;
                    node.leftChild = temp.leftChild;
                    node.rightChild = temp.rightChild;
                }
            } else {
                if (node.leftChild == null && node.rightChild == null) {
                    if (isLeft == true) {
                        grand.leftChild = null;
                    } else {
                        grand.rightChild = null;
                    }
                } else if (node.rightChild == null) {
                    if (isLeft == true) {
                        grand.leftChild = node.leftChild;
                    } else {
                        grand.rightChild = node.leftChild;
                    }
                } else if (node.leftChild == null) {
                    if (isLeft == true) {
                        grand.leftChild = node.rightChild;
                    } else {
                        grand.rightChild = node.rightChild;
                    }
                }
            }
            return true;
        }

    }

    Node findReplacement(Node node) {
        Node parent = null;
        Node result = null;
        while (node.leftChild != null) {
            parent = node;
            node = node.leftChild;
            result = node;
        }
        if (node.rightChild != null) {
            parent.leftChild = node.rightChild;
        } else {
            if (parent != null) {
                parent.leftChild = null;
            } else {
                result = node;
            }
        }
        return result;
    }

    public boolean Delete1(int data) {
        Node grand = null;
        boolean isLeft = false;
        return Delete1(data, root, grand, isLeft);
    }

    private boolean Delete1(int data, Node node, Node grand, boolean isLeft) {
        if (node == null) {
            return false;
        }
        if (data < node.data) {
            return Delete1(data, node.leftChild, node, true);
        } else if (data > node.data) {
            return Delete1(data, node.rightChild, node, false);
        } else {
            if (node.leftChild == null && node.rightChild == null) {
                if (isLeft == true) {
                    grand.leftChild = null;
                } else {
                    grand.rightChild = null;
                }
            } else if (node.rightChild != null) {
                node.data = findRightReplacement(node.rightChild).data;

            } else {
                node.data = findRightReplacement(node.leftChild).data;
            }
            return true;
        }
    }

    Node findRightReplacement(Node node) {
        Node parent = null;
        Node result = null;
        while (node.leftChild != null) {
            parent = node;
            node = node.leftChild;
            result = node;
        }
        if (node.rightChild != null) {
            parent.leftChild = node.rightChild;
        } else {
            if (parent != null) {
                parent.leftChild = null;
            } else {
                result = node;
            }
        }
        return result;
    }

    Node findLeftReplacement(Node node) {
        Node parent = null;
        Node result = null;
        while (node.rightChild != null) {
            parent = node;
            node = node.rightChild;
            result = node;
        }
        if (node.leftChild != null) {
            parent.rightChild = node.leftChild;
        } else {
            if (parent != null) {
                parent.rightChild = null;
            } else {
                result = node;
            }
        }
        return result;
    }

    public void MirrorTree() {
        MirrorTree(root);
    }

    private Node MirrorTree(Node node) {
        if (node == null) {
            return node;
        }
        if (node.leftChild == null && node.rightChild == null) {
            return node;
        }
        if (node.leftChild != null && node.rightChild != null) {
            Node ltemp = node.leftChild;
            Node rtemp = node.rightChild;
            node.leftChild = rtemp;
            node.rightChild = ltemp;
            MirrorTree(node.leftChild);
            MirrorTree(node.rightChild);
        } else if (node.leftChild != null) {
            node.rightChild = node.leftChild;
            node.leftChild = null;
            MirrorTree(node.leftChild);
        } else {
            node.leftChild = node.rightChild;
            node.rightChild = null;
            MirrorTree(node.rightChild);
        }
        return node;
    }

    public void ZigZagPrint() {
        ZigZagPrint(root);
    }

    public void ZigZagPrint(Node node) {
        boolean LR = true;
        Stack<Node> pStack = new Stack<Node>();
        pStack.push(node);
        ZigZag(pStack, LR);
    }

    public void ZigZag(Stack<Node> Parent, boolean LR) {
        Stack<Node> Child = new Stack<Node>();
        if (Child.isEmpty() && Parent.isEmpty()) {
            return;
        }
        while (!Parent.isEmpty()) {
            Node temp = Parent.pop();
            System.out.print(temp.data + " , ");
            if (LR) {
                if (temp.leftChild != null) {
                    Child.push(temp.leftChild);
                }
                if (temp.rightChild != null) {
                    Child.push(temp.rightChild);
                }
            } else {
                if (temp.rightChild != null) {
                    Child.push(temp.rightChild);
                }
                if (temp.leftChild != null) {
                    Child.push(temp.leftChild);
                }
            }
        }
        Parent = Child;
        System.out.println();
        ZigZag(Parent, !LR);
    }

    public Node TreeToList() {
        Node header = null;
        header = TreeToList(root);
        printList(header);
        return header;
    }

    private Node TreeToList(Node node) {
        if (node == null) {
            return (null);
        }
        Node header = null;
        Node current = null;
        Node temp = null;
        Stack<Node> stack = new Stack<Node>();
        while (true) {
            while (node != null) {
                stack.push(node);
                node = node.leftChild;
            }
            if (stack.isEmpty()) {
                break;
            }
            node = stack.pop();
            if (header == null) {
                header = current = node;
            } else {
                current.rightChild = node;
                node.leftChild = current;
                current = node;
            }
            node = node.rightChild;
        }
        current.rightChild = header;
        return header;
    }

    public static Node append(Node a, Node b) {
// if either is null, return the other
        if (a == null) {
            return (b);
        }
        if (b == null) {
            return (a);
// find the last node in each using the .previous pointer
        }
        Node aLast = a.leftChild;
        Node bLast = b.rightChild;
// join the two together to make it connected and circular
        aLast.rightChild = b;
        b.leftChild = aLast;
        bLast.rightChild = a;
        a.leftChild = bLast;
        return (a);
    }

    public void printList(Node head) {
        Node current = head;
        if (current == null) {
            return;
        }
        while (true) {
            System.out.print(Integer.toString(current.data) + " , ");
            current = current.rightChild;
            if (current == head) {
                break;
            }
        }
        System.out.println();
    }

    public boolean isEqual(Node node) {
        return isEqual(root, node);
    }

    private boolean isEqual(Node b1, Node b2) {
        if (b1 == null && b2 == null) {
            return true;
        }
        if (b1 != null && b2 != null) {
            return ((b1.data == b2.data) && isEqual(b1.leftChild, b2.leftChild) && isEqual(b1.rightChild, b2.rightChild));
        }
        return false;
    }

    public int findMaxPath() {
        head = root;
        int maxPath = findMaxPath(root, 1);
        return maxPath;
    }

    public int findMaxPath(Node node, int max) {
        if (node == null) {
            return 0;
        }
        int lmax = getHeight(node.leftChild);
        int rmax = getHeight(node.rightChild);
        int path = lmax + rmax + 1;
        if (max < path) {
            max = path;
            head = node;
        }
        findMaxPath(node.leftChild, max);
        findMaxPath(node.rightChild, max);
        return max;
    }

    public void printMaxPath() {
        int len = getHeight(root);
        int[] arr1 = new int[50];
        int[] arr2 = new int[2 * len - 1];
        int count = -1;
        if (root == null) {
            return;
        }
        System.out.print("\n print path  \n");
        //  ++count;
        //   arr1[count] = root.data;
        //   arr2[count] = root.data;
        //System.out.print(root.data+" : ");
        //printMaxPath(root.leftChild, arr1, arr2, count);
        printMaxPath(root, arr1, count);
        for (int i : arr1) {
            System.out.print(i + " : ");
        }
        System.out.print("\n");
        for (int i : arr2) {
            System.out.print(i + " : ");
        }
    }

    private void printMaxPath(Node node) {
        if (node.leftChild != null && node.rightChild != null) {
            int lh = getHeight(node.leftChild);
            int rh = getHeight(node.rightChild);
            if (lh > rh) {
                node = node.leftChild;
                System.out.print(node.data + " : ");
                printMaxPath(node);
            } else {
                node = node.rightChild;
                System.out.print(node.data + " : ");
                printMaxPath(node);
            }
        } else if (node.leftChild != null) {
            node = node.leftChild;
            System.out.print(node.data + " : ");
            printMaxPath(node);
        } else if (node.rightChild != null) {
            node = node.rightChild;
            System.out.print(node.data + " : ");
            printMaxPath(node);
        } else {
            return;
        }
    }

    private void recursive1(Node leftChild, int lHight) {
        if (leftChild == null) {
            return;
        }
        if (getHeight(leftChild.leftChild) == lHight - 1) {
            recursive1(leftChild.leftChild, lHight - 1);
        } else if (getHeight(leftChild.rightChild) == lHight - 1) {
            recursive1(leftChild.rightChild, lHight - 1);
        }

        System.out.print(leftChild.data + " : ");
    }

    private void recursive2(Node rightChild, int rHight) {
        if (rightChild == null) {
            return;
        }
        System.out.print(rightChild.data + "  : ");

        if (getHeight(rightChild.leftChild) == rHight - 1) {
            recursive2(rightChild.leftChild, rHight - 1);
        } else if (getHeight(rightChild.rightChild) == rHight - 1) {
            recursive2(rightChild.rightChild, rHight - 1);
        }

    }

    private void xyz() {
        int[] arr1 = new int[200];

        Node node = printMaxPath(root, arr1, 0);
        int lHight = getHeight(node.leftChild);
        int rHight = getHeight(node.rightChild);

        recursive1(node.leftChild, lHight);
        System.out.print(node.data + " : ");
        recursive2(node.rightChild, rHight);
    }

    private Node printMaxPath(Node node, int[] arr1, int count) {
        if (node == null) {
            return null;
        }
        arr1[++count] = node.data;
        int llh = 0, lrh = 0, rlh = 0, rrh = 0, h = 0;
        h = getHeight(node.leftChild) + getHeight(node.rightChild) + 1;
        if (node.leftChild == null && node.rightChild == null) {
            return node;
        } else if (node.leftChild != null && node.rightChild == null) {
            printMaxPath(node.leftChild, arr1, count);
        } else if (node.leftChild == null && node.rightChild != null) {
            printMaxPath(node.rightChild, arr1, count);
        } else {
            llh = getHeight(node.leftChild.leftChild);
            lrh = getHeight(node.leftChild.rightChild);
            rlh = getHeight(node.rightChild.leftChild);
            rrh = getHeight(node.rightChild.rightChild);

            if (llh + lrh > h) {
                if (node.leftChild != null) {
                    node = node.leftChild;
                }
                printMaxPath(node.leftChild, arr1, count);
                printMaxPath(node.rightChild, arr1, count);
            } else if (h < rlh + rrh) {
                if (node.rightChild != null) {
                    node = node.rightChild;
                }
                printMaxPath(node.leftChild, arr1, count);
                printMaxPath(node.rightChild, arr1, count);
            } else {
                printMaxPath(node.rightChild, arr1, count);
                printMaxPath(node.leftChild, arr1, count);
            }
        }
        return node;
    }

    public int[] getTop2Height(Node node) {
        if (node == null) {
            return null;
        }
        int[] arr = new int[2];
        int first = 0, second = 0, count = 0;
        Node lNode = null, rNode = null;
        while (first != second) {
            lNode = node.leftChild;
            rNode = node.rightChild;
            if (lNode != null) {
                first = getHeight(node.leftChild);
            }
            if (rNode != null) {
                second = getHeight(node.rightChild);
            }
            count++;
        }
        arr[0] = first + count;
        arr[1] = second + count;
        return arr;
    }

    public void OptimizedMaxPath() {
        OptimizedMaxPath(root);
    }

    private void OptimizedMaxPath(Node node) {
        if (node == null) {
            return;
        }
        Stack<Node> stack = new Stack<Node>();
        int count = 0, fMax = 0, sMax = 0;
        Node fNode = root, sNode = null; Node delNode = null;
        while (true) {
            while (node != null) {
                stack.push(node);
                 count++;
                node = node.leftChild;
               }
            if (stack.size() == 0) break;
                node = stack.pop();
                  if (fMax < count) {
                        sMax = fMax;
                        fMax = count;
                        fNode = node;
                    }
                    if (fMax > count && count > sMax) {
                        sMax = count;
                        if(fNode.parent!=sNode)
                        sNode = node;
                    }
                count--;
                node=node.rightChild;
      }
        System.out.print("\n nodes height" + fNode.data + " : " + sNode.data + "\n");
        Stack<Node> rStack = new Stack<Node>();
        while(true){
            if(fNode==root)break;
            if(fNode.parent!=null && fNode.parent.data > sNode.data)break;
            System.out.print(fNode.data+" : ");
            fNode=fNode.parent;
        }
        while (sNode!=fNode) {
            System.out.print(rStack.push(sNode) + " : ");
            sNode=sNode.parent;
        }
        while(!rStack.isEmpty())
            System.out.print(rStack.pop().data+" : ");
    }

    public Node mergeTree(Node node) {
        BinaryTree head = null;
        return mergeTree(root, node, head);
    }
// wrong method
    private Node mergeTree(Node b1, Node b2, BinaryTree b) {
        Node Head = b.root;
        if (b1 == null && b2 == null) {
            return null;
        }
        Node b1p = b1;
        Node b2p = b2;
        Node current = null;
        while (b1p == null || b2p == null) {
            if (b1p.data <= b2p.data) {
                if (Head == null) {
                    Head = current = b1p;
                } else {
                    current = b1p;
                    if (b1p.rightChild != null && b1p.rightChild.data < b2p.data) {
                        b1p = b1p.rightChild;
                    } else if (b1p.leftChild != null && b1p.leftChild.data < b2p.data) {
                        b1p = b1p.leftChild;
                    }
                }
            } else if (b1p.data > b2p.data) {
                if (Head == null) {
                    Head = current = b2p;
                } else {
                    current = b2p;
                    if (b2p.leftChild != null && b2p.leftChild.data < b1p.data) {
                        b2p = b2p.leftChild;
                    } else if (b2p.rightChild != null && b2p.rightChild.data < b1p.data) {
                        b2p = b2p.rightChild;
                    }
                }
            }
        }
        if (b1p == null && b2p != null) {
            while (b2p.leftChild != null && b2p.rightChild != null) {
                if (b2p.leftChild != null) {
                    b.insert(b2p.leftChild.data);
                    b2p = b2p.leftChild;
                }
                if (b2p.rightChild != null) {
                    b.insert(b2p.rightChild.data);
                    b2p = b2p.rightChild;
                }
            }
        }
        if (b2p == null && b1p != null) {
            while (b1p.leftChild != null && b1p.rightChild != null) {
                if (b1p.leftChild != null) {
                    b.insert(b1p.leftChild.data);
                    b1p = b1p.leftChild;
                }
                if (b1p.rightChild != null) {
                    b.insert(b1p.rightChild.data);
                    b1p = b1p.rightChild;
                }
            }
        //  mergeTree(b1, b2, current);
        }
        return Head;
    }

    public static void main(String[] args) {
        System.out.println("Binary Tree");
        BinaryTree bTree = new BinaryTree();
        int[] dataArr = {10, 5, 25, 3, 8, 13, 18, 2, 4, 6, 11, 14, 17, 19, 1, 7, 9, 12, 16, 20, 21, 22, 23, 24};
        for (int data : dataArr) {
            bTree.insert(data);
        }
//                                               10
//                                    5                      15
//                                  3       8           13           18
//                                2  4   6    9     11     14     17    19
//                               1        7           12        16        20
//                                                                          21
//                                                                            22
//                                           
        BinaryTree bTree1 = new BinaryTree();
        int[] dataArr1 = {10, 5, 20, 3, 8, 13, 18, 30, 26, 31, 2, 4, 6, 11, 14, 17, 19, 1, 7, 9, 12, 16, 23, 21, 22, 24, 25, 27, 28, 29};
        for (int data1 : dataArr1) {
            bTree1.insert(data1);
        }
        System.out.print("btree1 :inorder treversal");
        bTree.iterative_inOrder();
        System.out.print("\nbtree2 :inorder treversal");
        bTree1.iterative_levelOrder();
        System.out.print("\nisEqual" + " " + bTree.isEqual(bTree1.root));
        System.out.print("\npreorder treversal");
        bTree.iterative_preOrder();
        System.out.print("\npostorder treversal");
        bTree.iterative_postOrder();
        System.out.print("\nlevel order treversal");
        bTree.iterative_levelOrder();
        System.out.print("\nIs binary Search Tree    :   " + bTree1.isBst());
        System.out.print("\n all possible paths ");
        bTree.printAllPaths();
        bTree.hasPathSum(21);
        System.out.print("\n candidate search : " + bTree.candidateBST(13).data + "\n");
        System.out.print("\ndeleted        :" + bTree.Delete1(14) + "\nis binarytree     :" + bTree.isBst() + "\n");
        bTree.insert(14);
        bTree.iterative_levelOrder();
        System.out.print("\n mirror tree");
        bTree.MirrorTree();
        bTree.iterative_levelOrder();
        System.out.print("\n ZigZag treverse");
        bTree.ZigZagPrint();
        System.out.println("\n height  :  " + bTree.getHeight());
        bTree1.iterative_inOrder();
        bTree1.iterative_levelOrder();
        bTree1.printMaxPath();
        /*  System.out.print("\n max path : " + bTree1.findMaxPath());
        System.out.print("\ntree to circular doubly linked list");
        bTree1.TreeToList();*/
        //BinaryTree b = new BinaryTree();
        // b.root = bTree.mergeTree(bTree1.root);
        // b.iterative_levelOrder();

      //  System.out.print("HIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII \n");
        //  bTree1.xyz();


        BinaryTree bTree2 = new BinaryTree();
        int[] dataArr2 = {10, 15, 20, 23, 28, 3135, 4525, 56727, 5, 4};
        for (int data1 : dataArr2) {
            bTree2.insert(data1);
        }
       // bTree1.xyz();
        bTree1.OptimizedMaxPath();
    //  bTree.printTree();

    }
}
