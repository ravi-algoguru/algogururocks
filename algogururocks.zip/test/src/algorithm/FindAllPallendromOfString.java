/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

import java.util.ArrayList;

/**
 *
 * @author alok
 */
public class FindAllPallendromOfString {

  
    static ArrayList<String> findMaxPalindrome(String str) {
        ArrayList<String> result = new ArrayList<String>();
        char[] ch = str.toCharArray();
        int ld = 0, rd = 0;
        for (int i = 0; i < ch.length - 1; i++) {
            if ((ch[i] == ch[i + 1]) || (i > 0 && ch[i - 1] == ch[i + 1])) {
                if (ch[i] == ch[i + 1]) {
                    ld = i - 1;
                    do{i++;}while(ch[i]==ch[i+1]);
                    rd = i + 1;
                } else if (i > 0) {
                    ld = i - 1;
                    rd = i + 1;
                }
                while (ld >= 0 && rd < ch.length) {
                    if (ch[ld] != ch[rd]) break;
                    ld--;   rd++;
                }
                if (rd - ld  > 3)
                    result.add(str.substring(ld+1, rd));
            }
        }
        return result;
    }

    public static void main(String[] args) {
        String s = "abbiabaiazzzzzbaabczcgdhbjiklerathssidmsoabskcbccmccnjcvcbbssassasasassjldcdkjddsvdskfdsfdsdsbxbxbjaasadsdssfddgkfdlfkbfgbflfbgbggbgbgb";
        char str[] = s.toCharArray();
        System.out.println(findMaxPalindrome(s));
    }
}
