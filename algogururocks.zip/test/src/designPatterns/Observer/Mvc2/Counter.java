package designPatterns.Observer.Mvc2;

/**
 * Class Counter implements a simple counter model.
 */
public class Counter {

  // The model.
  private int count;

  public Counter(int count) {
    this.count = count;
  }
  
  public int getCount() {
    return count;
  }
  
  public void incCount() {
    count++;
  }
  
  public void decCount() {
    count--;
  }
        
}

