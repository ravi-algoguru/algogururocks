package designPatterns.Observer.DelegatedObservable;

import java.util.*;

/**
 * A subclass of Observable that allows delegation.
 */
public class DelegatedObservable
  extends Observable {
  
  public void clearChanged() {
    super.clearChanged();
  }
  
  public void setChanged() {
    super.setChanged();
  }
  
}
  
