package designPatterns.Observer.DelegatedObservable;

/**
 * Test program for SpecialSubject2 with a Delegated Observable.
 */
public class TestSpecial2 {

  public static void main(String args[]) {
  
    // Create the Subject and Observers.
    SpecialSubject2 s = new SpecialSubject2("Corn Pops", 1.29f);
    NameObserver nameObs = new NameObserver();
    PriceObserver priceObs = new PriceObserver();
  
    // Add those Observers!
    s.addObserver(nameObs);
    s.addObserver(priceObs);
  
    // Make changes to the Subject.
    s.setName("Frosted Flakes");
    s.setPrice(4.57f);
    s.setPrice(9.22f);
    s.setName("Sugar Crispies");
  }
  
}

