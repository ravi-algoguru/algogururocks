package designPatterns.Observer.DelegatedObservable;

import java.util.*;

/**
 * A subject to observe!
 * But this subject already extends another class.
 * So use a contained DelegatedObservable object.
 * Note that in this version of SpecialSubject we do
 * not duplicate any of the interface of Observable.
 * Clients must get a reference to our contained
 * Observable object using the getObservable() method.
 */
public class SpecialSubject 
  extends ParentClass {
  
  private String name;
  private float price;
  
  private DelegatedObservable obs;
  
  public SpecialSubject(String name, float price) {
    this.name = name;
    this.price = price;
    obs = new DelegatedObservable();
    System.out.println("SpecialSubject created: " + name + " at " + price);
  }

  public String getName() {
    return name;
  }
  
  public float getPrice() {
    return price;
  }
  
  public Observable getObservable() {
    return obs;
  }
  
  public void setName(String name) {
    this.name = name;
    obs.setChanged();
    obs.notifyObservers(name);
  }
  
  public void setPrice(float price) {
    this.price = price;
    obs.setChanged();
    obs.notifyObservers(new Float(price));
  }
  
}
  
