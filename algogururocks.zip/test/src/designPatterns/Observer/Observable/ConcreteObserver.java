package designPatterns.Observer.Observable;

import java.util.*;

/**
 * An observer.
 */
public class ConcreteObserver
  implements Observer {
  
  private String name;
  private float price; 

  public ConcreteObserver() {
    name = null;
    price = 0;
    System.out.println("ConcreteObserver created: " + name + " at " + price);
  }

  public void update(Observable obj, Object arg) {
    if (obj instanceof ConcreteSubject) {
      if (arg instanceof String) {
        name = (String)arg;
        System.out.println("Name changed to: " + name);
      }
      else if (arg instanceof Float) {
        price = ((Float)arg).floatValue();
        System.out.println("Price changed to: " + price);
      }
    }
  }
  
}
  
