/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PackageB;

/**
 *
 * @author sony
 */
public class TestClient {
    public static void main(String[] args){
        SubClassA subA=new SubClassA();
        int a=subA.a;
        a=subA.superPublicVarA;
        subA.subMethodA(subA);
    }
}
