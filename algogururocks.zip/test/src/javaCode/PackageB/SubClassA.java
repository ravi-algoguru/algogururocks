/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PackageB;
import PackageA.*;

/**
 *
 * @author sony
 */
public class SubClassA extends SuperClassA{
    int a;
    static int b;
    public void subMethodA(SuperClassA superA){
       a= super.superProtectedVarA;
       a=this.superProtectedVarA;
       super.superProtectedMethodA();
     //  super.superProtectedMethodA()
       superA.superPublicMethodA();
       SuperClassA superAref=new SuperClassA();
       a=superAref.superPublicVarA;
       superAref.superPublicMethodA();
        //using superAref protected method of superClass not accessible
       //with superclass refernce access only super variable;
       
    }
    
    public static void SubStaticMethodA(SuperClassA superA){
        b=superA.superPublicVarA;
        b=superProtectedStaticVarA;
       
    }
}
