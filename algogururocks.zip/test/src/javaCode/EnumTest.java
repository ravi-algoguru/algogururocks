/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaCode;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author ravi
 */
public class EnumTest {
    
}
enum Direction {
	// Enum types
	EAST(0) {
		@Override
		public void shout() {
			System.out.println("Direction is East !!!");
		}
	},
	WEST(180) {
		@Override
		public void shout() {
			System.out.println("Direction is West !!!");
		}
	},
	NORTH(90) {
		@Override
		public void shout() {
			System.out.println("Direction is North !!!");
		}
	},
	SOUTH(270) {
		@Override
		public void shout() {
			System.out.println("Direction is South !!!");
		}
	};
	// Constructor only private or default
	private Direction(final int angle) {
		this.angle = angle;
	}

	// Internal state
	private int angle;

	public int getAngle() {
		return angle;
	}

	// Abstract method which need to be implemented
	public abstract void shout();
        
        
        // Lookup table
        private static final Map lookup = new HashMap();

        // Populate the lookup table on loading time
        static {
                for (Direction s : EnumSet.allOf(Direction.class))
                        lookup.put(s.getAngle(), s);
        }

        // This method can be used for reverse lookup purpose
        public static Direction get(int angle) {
                return lookup.get(angle);
        }


}