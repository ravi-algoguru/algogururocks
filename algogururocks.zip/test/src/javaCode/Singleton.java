/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaCode;

/**
 *
 * @author ravi
 */
public class Singleton {
    private Singleton(){
        
    }
    
    private static class InstanceHolder{
        private static final Singleton instance = new Singleton();
    }
    
    public Singleton getInstance(){
        return InstanceHolder.instance;
    }
  
}

class DoubleCheckedLockingSingleton{
     private volatile DoubleCheckedLockingSingleton INSTANCE;
  
     private DoubleCheckedLockingSingleton(){}
  
     public DoubleCheckedLockingSingleton getInstance(){
         if(INSTANCE == null){
            synchronized(DoubleCheckedLockingSingleton.class){
                //double checking Singleton instance -because second check of Singleton instance with lock
 
                if(INSTANCE == null){
                    INSTANCE = new DoubleCheckedLockingSingleton();
                }
            }
         }
         return INSTANCE;
     }
}

/**
 *
 * @author ravi
 */
 enum SingletonEnum{
      Instance;
      public int getInstance(){
          return instance;
      }
}
