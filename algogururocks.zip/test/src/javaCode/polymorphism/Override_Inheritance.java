/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaCode.polymorphism;

import java.util.Collection;
import java.util.HashSet;

/**
 *
 * @author ravi
 */
public class Override_Inheritance {
    public static void main(String args[])  {
       Collection c = new HashSet();
       Override_Inheritance et = new Override_Inheritance();
       et.sort(c);
      
    }
   
    //overloaded method takes Collection argument
    public Collection sort(Collection c){
        System.out.println("Inside Collection sort method");
        return c;
    }
  
   
   //another overloaded method which takes HashSet argument which is sub class
    public Collection sort(HashSet hs){
        System.out.println("Inside HashSet sort method");
        return hs;
    }
      

}
