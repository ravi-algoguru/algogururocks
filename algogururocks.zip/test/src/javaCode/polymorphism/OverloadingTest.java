/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaCode.polymorphism;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author ravi
 */

class ConfusingOverloading{
  
    public boolean hasDuplicates (List collection){
        System.out.print("super class : overloaded method with Type List ");
        return true;
    }
  public int method(Object o){
      System.out.print("super method " + o.toString());
      return 1;
  }
}
 
class subclass extends ConfusingOverloading{
//    @Override
//    public boolean hasDuplicates (List collection){
//        System.out.print("subclass : overloaded method with Type List ");
//        return true;
//    }
    public boolean hasDuplicates (ArrayList collection){
        System.out.print("subclass method with Type ArrayList ");
        return true;
    }
  
  
    public boolean hasDuplicates (LinkedList collection){
        System.out.print("subclass method with Type LinkedList ");
        return true;
    }
    @Override
     public int method(Object o){
      System.out.print("sub method :object : " +this.getClass().getName());
      return 1;
  }
     public int method(String o){
      System.out.print("sub method : string : "+o);
      return 1;
  }
} 
public class OverloadingTest {
  
    public static void main(String args[]){
       List abc = new ArrayList();
       List bcd = new LinkedList();
       ArrayList al= new ArrayList();
       ConfusingOverloading co = new subclass();
       System.out.println("\n superref :");
       co.hasDuplicates(abc); //call to collection
       System.out.println("\n superref :");
       co.hasDuplicates(bcd); //call to collection
       System.out.println("\n superref :");
       co.method("hello");
       
       subclass sc =new subclass(); 
       System.out.println("\n subref :");
       sc.hasDuplicates(abc); //should call to ArryList overloaded method
       System.out.println("\n superref :");
       sc.hasDuplicates(bcd);
       System.out.println("\n superref :");
       sc.method("hello");
       System.out.println("\n superref :");
       sc.method(abc);
       
       System.out.println("\n superref :");
       co.hasDuplicates(al);
       System.out.println("\n subref :");
       sc.hasDuplicates(al);
    }

  
}

