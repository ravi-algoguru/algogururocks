/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaTest;

/**
 *
 * @author sony
 */
public class InitializationTest{
    static int i=j;
    static int j;
    
    int a=this.b;
    int b;
   // int c=this.b;
    
    int z=k;
    static int k;
    
    int f=d;
     int d;
    int g=d;
    
    {
        int l;
        int m=l;
    }
    
    int x;
    int y;
    x=y;
    int dd=y;
    static int yy;
    static{
        int i=jj;
        int jj;
        yy=kk;
        int kk;
        yy==kk;
        kk=yy;
    }
}
