/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaTest;

/**
 *
 * @author funti
 */
public class OperatorPrecedenceTest {
    
    private static int methodA(int i, int j){
     System.out.println(j);
      return i+j;
    }
    public static void main(String[] args){
        int i=10;
        int j=i*methodA(i++,++i);
        System.out.println(i);
        System.out.println(j); //220
        int a=10;
        int b=a++*methodA(a+1,a++);//
         System.out.println(a);
          System.out.println(b);
          System.out.println(~2);
          
          System.out.println(!true);
    }
}
