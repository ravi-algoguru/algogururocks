/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaTest;

/**
 *
 * @author funti
 */
public class MainMethodTest {
    //main method can be overloaded like any other method.
 public static void main(String[]r){
     
 }   
 public static void main(Object[] args) throws IllegalAccessException{
     
 }
}
