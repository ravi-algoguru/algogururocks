/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaTest;

/**
 *
 * @author funti
 */
public class DefaultInitializationTest {
    public static void main(String[] args){
        char c;
        int i;
        if(false)
            i=1;
        System.out.println(i);
        if(true)
            i=10;
        if(i==10)
            c='1';
        System.out.println(c);
        if(true)
            c='1';
        System.out.println(c);
    }
}
