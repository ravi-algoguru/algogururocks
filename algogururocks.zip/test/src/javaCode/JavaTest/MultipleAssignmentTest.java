/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaTest;

/**
 *
 * @author funti
 */
public class MultipleAssignmentTest {
    
    public static void main(String[] args){
        int[] arr={10,20,30,40,50,60};
        int index = 4;
        arr[index]= index = 2;
        System.out.println(index + " " + arr[index]);
    }
    
}
