/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaTest;

import java.util.Set;

/**
 *
 * @author sony
 */
class Point {

    private int x;
    private int y;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setX(int x) { // Problematic
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

//    @Override
//    public boolean equals(Object other) {
//        boolean result = false;
//        System.out.println("POINT EQUALS CALLED");
//        if (other instanceof Point) {
//            Point that = (Point) other;
//            result = (this.getX() == that.getX() && this.getY() == that.getY());
//        }
//        return result;
//    }
    @Override
    public boolean equals(Object other) {
        boolean result = false;
        System.out.println("POINT EQUALS CALLED");
        if (other instanceof Point) {
            Point that = (Point) other;
            result = (this.getX() == that.getX() && this.getY() == that.getY()
                    && this.getClass().equals(that.getClass()));
        }
        return result;
    }

//    @Override
//    public boolean equals(Object other) {
//        boolean result = false;
//        if (other instanceof Point) {
//            Point that = (Point) other;
//            result = (that.canEqual(this) && this.getX() == that.getX() && this.getY() == that.getY());
//        }
//        return result;
//    }
    public boolean canEqual(Object other) {
        return (other instanceof Point);
    }

    @Override
    public int hashCode() {
        return (41 * (41 + getX()) + getY());
    }
}

class ColoredPoint extends Point { // Problem: equals not symmetric

    private final String color;

    public ColoredPoint(int x, int y, String color) {
        super(x, y);
        this.color = color;
    }

//    @Override   not symmetric   but with class test of Point no longer voilates symmtric
//    public boolean equals(Object other) {
//        boolean result = false;
//        System.out.println("COLORED POINT EQUALS CALLED");
//        if (other instanceof ColoredPoint) {
//            ColoredPoint that = (ColoredPoint) other;
//            result = (this.color.equals(that.color) && super.equals(that));
//        }
//        return result;
//    }
    // Equals not transitive
//    @Override
//    public boolean equals(Object other) {
//        boolean result = false;
//        System.out.println("COLORED POINT EQUALS CALLED");
//        if (other instanceof ColoredPoint) {
//            ColoredPoint that = (ColoredPoint) other;
//            result = (this.color.equals(that.color) && super.equals(that));
//        } else if (other instanceof Point) {
//            Point that = (Point) other;
//            result = that.equals(this);
//        }
//        return result;
//    }
//  Use CanEquals Method:  explicitly state that objects of this class are never equal to objects of some superclass that implement a different
//equality method
    @Override
    public boolean equals(Object other) {
        boolean result = false;
        if (other instanceof ColoredPoint) {
            ColoredPoint that = (ColoredPoint) other;
            result = (that.canEqual(this) && this.color.equals(that.color) && super.equals(that));
        }
        return result;
    }

    @Override
    public int hashCode() {
        return (41 * super.hashCode() + color.hashCode());
    }

    @Override
    public boolean canEqual(Object other) {
        return (other instanceof ColoredPoint);
    }
}

public class EqualTest {

    public static void main(String[] args) {
        //Symmetry test
        System.out.println("*****Symmetry Test*********");
        Point p = new Point(1, 2);
        ColoredPoint cp = new ColoredPoint(1, 2, "RED");

        System.out.println(p.equals(cp)); // prints true
        System.out.println(cp.equals(p)); // prints false
        Set<Point> hashSet1 = new java.util.HashSet<Point>();

        hashSet1.add(p);

        System.out.println(hashSet1.contains(cp)); // prints false
        Set<Point> hashSet2 = new java.util.HashSet<Point>();

        hashSet2.add(cp);

        System.out.println(hashSet2.contains(p)); // prints true
        System.out.println("*****Transitive Test*********");
        //Transitive Test
        ColoredPoint redP = new ColoredPoint(1, 2, "RED");
        ColoredPoint blueP = new ColoredPoint(1, 2, "BLUE");

        System.out.println(redP.equals(p)); // prints true
        System.out.println(p.equals(blueP)); // prints true
        System.out.println(redP.equals(blueP)); // prints false
        Point pAnon = new Point(1, 1) {
            @Override
            public int getY() {
                return 2;
            }
        };


        Set<Point> coll = new java.util.HashSet<Point>();
        coll.add(p);
        System.out.println(coll.contains(p)); // prints true
        System.out.println(coll.contains(cp)); // prints false
        System.out.println(coll.contains(pAnon)); // prints true
    }
}
