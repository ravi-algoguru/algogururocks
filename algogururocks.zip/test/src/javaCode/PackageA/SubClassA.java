/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PackageA;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sony
 */
public class SubClassA extends SuperClassA{
    int a;
    static int b;
    public void subMethodA(SuperClassA superA){
       a= super.superProtectedVarA;
       a=this.superProtectedVarA;
       super.superProtectedMethodA();
       SuperClassA superAref=new SuperClassA();
       a=superAref.superPublicVarA;
     
       superAref.superProtectedMethodA();
        //using superAref method of superClass not accessible in subclass outside the pacakge
       //with superclass refernce access only super variable;
       
    }
    
    public static void SubStaticMethodA(SuperClassA superA){
        b=superA.superPublicVarA;
        b=superProtectedStaticVarA;
        
    }
    
    
   
    @Override
   protected String superProtectedMethodA(){  //return type of overridden must be comptible 
       //array, String, and other are subtype of object.
        return "Hello Sub";
    }
   // @Override
   String subAA(String obj){
     
        return "subclass subAA";
   }
   String subAA(Object obj){
     
        return "subclass subAA object";
   }
//   String subAA(String s){//compile time error
//       return"hello";
//   }
void Method1(int x){
    System.out.print("Method 1nt: "+x);
}
 
void Method1(short c){
    System.out.print("Method short: "+c);
    
}
   public static void main(String[] args){
       SuperClassA superA=new SuperClassA();
       String s=(String)superA.superProtectedMethodA();
       //System.out.println(s);
       superA= new SubClassA();
       s= (String)superA.superProtectedMethodA();
      // System.out.println(s);
       s=(String) superA.subAA("hello");
       System.out.println(s);
       SubClassA subB=(SubClassA)superA;  
       s=subB.superProtectedMethodA();
       //System.out.println(s);
       subB.Method1('a');
   }
}

