/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PackageA;

/**
 *
 * @author sony
 */
public class SuperClassA {
    public int superPublicVarA;
    protected int superProtectedVarA;
    int superDefaultVarA;
    private int superPrivateVarA;
    
    public static int superPublicStaticVarA;
    protected static int superProtectedStaticVarA;
    static int superDefaultStaticVarA;
    private static int superPrivateStaticVarA;
    
    protected Object superProtectedMethodA(){
        return"hello super";
    }
    
//   String subAA(String obj){
//       return "";
//   }
   Object subAA(String obj){
       return "hello super SubAA";
   }
    protected static Object superProtectedStaticMethodA(){
        return "hello static";
    }
    public void superPublicMethodA(){
        
    }
    
    public static void superPublicStaticMethodA(){
        
    }
    int A(){
        return 1;
    }
}
