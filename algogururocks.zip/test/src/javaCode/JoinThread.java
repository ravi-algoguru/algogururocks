/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaCode;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ravi
 */
public class JoinThread {
    static volatile int count =1;
    static class MyThread implements Runnable {

        private String mess;

        public MyThread(String mess) {
            this.mess = mess;
        }

        @Override
        public void run() {
            System.out.print(this.mess);
            count++;
        }

    }

    public static void main(String[] args) {
         
        Thread t1 = new Thread(new MyThread(("hello")));
        Thread t2 = new Thread(new MyThread(("you there")));
        Thread t3 = new Thread(new MyThread(("Bye")));
        Thread t4 = new Thread(new MyThread(("disturb")));
        t1.start();
        t2.start();
        t3.start();
        t4.start(); 
//        try {
//            while (count < 5) {
//                switch (count) {
//                    case 1:
//                        t1.join();
//                        break;
//                    case 2:
//                        t2.join();
//                        break;
//                    case 3:
//                        t3.join();
//                        break;
//                    default:
//                        t4.join();
//                }
//                count++;
//            }
//        } catch (InterruptedException ex) {
//            System.out.println("exception : " + ex.getMessage() + "\n");
//            Logger.getLogger(JoinThread.class.getName()).log(Level.SEVERE, null, ex);
//        } finally {
//            System.out.println("Finally");
//        }
//        
        
        
        
    }

}
