package test;

import java.util.Scanner;

public class Palindrome {
 static final char[] validChars = { 'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O',
		 							'P','Q','R','S','T','U','V','W','X','Y','Z',0, 0 ,0, 0,0,0,
		 							'a','b','c','d' ,'e', 'f','g','h','i','j','k','l','m','n','o',
		                            'p','q','r','s','t','u','v','w','x','y','z'
		                           };
  
	public static void main(String[] args){
	    System.out.println("Please enter a string: ");
 		Scanner scanner = new Scanner(System.in);
 	    String str = scanner.nextLine();
        System.out.println(isPallendrome(str));
	    scanner.close();
	}
	    
	    public static boolean isPallendrome(String str) {
		  int len = str.length();
		  int i = 0, j = len -1;
		  char iChar =str.charAt(i);
		  char jChar = str.charAt(j);
		  boolean result = true;
		  while(i < j){
			 
			  while(true){
				if( isValidChar(str.charAt(i))){
					 iChar = str.charAt(i);
					 i++;
					 break;
				}
				i++;
			  }
			  while(true){
				  if(isValidChar(str.charAt(j))){
					  jChar = str.charAt(j);
					  j--;
					  break;
				  }
				  j--;
			  }
			  System.out.println("iChar :"+ iChar+"-jChar :"+jChar);
			  if(iChar != jChar && iChar - 32 != jChar && iChar != jChar -32){			 
				  result = false;
				  break;
			  }
		  }
		  return result;
	    }
 
		private static boolean isValidChar(char ch) {
			if(ch-65 < 0  
					|| ch - 65 > (validChars.length -1)
					|| validChars[ch-64]==0 )
				return false;
			System.out.println((ch -65 +" :"+ validChars[ch-65] +" : "+ch + ":"+(validChars[ch-65] == ch)));
			if(validChars[ch-65] == ch ) 
				return true;
			
			return false;
		} 
}
