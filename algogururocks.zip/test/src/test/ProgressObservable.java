package test;


import java.util.Observable;

/**
 * @version $version$
 */

public class ProgressObservable extends Observable {
    /**
     * constructor. Initalizes the object ....
     */
    public ProgressObservable() {
    }

    /**
     * Indicates that this object has changed.
     *
     */
    public synchronized void setChanged() {
        super.setChanged();
    }
}
