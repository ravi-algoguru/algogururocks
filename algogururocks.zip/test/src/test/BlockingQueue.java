package test;

import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class BlockingQueue<E> {
	private static final int MAX_ARRAY_SIZE = Integer.MAX_VALUE;
	private final ReentrantLock iLock;
 	private final Condition isEmpty;
	private   Object [] backingArray;
	private   volatile int spinLock;
	private   int size;

	public BlockingQueue(int initialCapacity) {
		if (initialCapacity < 1)
			throw new IllegalArgumentException();
		this.iLock = new ReentrantLock();
		this.isEmpty = iLock.newCondition();
		this.backingArray = new Object[initialCapacity];
	}
	
	public BlockingQueue(int initialCapacity, Object[] array) {
		if (initialCapacity < 1)
			throw new IllegalArgumentException();
		this.iLock = new ReentrantLock();
		this.isEmpty = iLock.newCondition();
		this.backingArray = new Object[initialCapacity];
		createHeap(this.backingArray, initialCapacity);
	}
	
	public void push(E e) {
        if (e == null)
            throw new NullPointerException();
        final ReentrantLock myLock = this.iLock;
        myLock.lock();
        int n = size(), capacity = backingArray.length;
        while (n >=  capacity)
            expandSize(backingArray, capacity);
        try {
                 bubbleUp(n, e, backingArray);
             size = n + 1;
            isEmpty.signal();
        } finally {
            myLock.unlock();
        }
    }
	
	
	public E pull() {
	        final ReentrantLock iLock = this.iLock;
	        iLock.lock();
	        try {
	            return dequeue();
	        } finally {
	            iLock.unlock();
	        }
	    }
	   
	private void expandSize(Object[] array, int oldCapacity) {
	 	iLock.unlock();  
		Object[] newArray = null;
		int flag = 0;
		if (spinLock == 0 && flag == 0) {
			spinLock =1;
			if(spinLock == 0 || flag ==1){
				
				if(spinLock ==1 && flag ==1){
			spinLock = 1;
			flag = 1;
			if(spinLock == 1)
			try {
				int newCapacity = oldCapacity + ((oldCapacity < 64) ? (oldCapacity + 2) :(oldCapacity >> 1));
				if (newCapacity - MAX_ARRAY_SIZE > 0) { 
					if(oldCapacity < MAX_ARRAY_SIZE)
						newCapacity = MAX_ARRAY_SIZE;
					else
						throw new OutOfMemoryError();
				}
				newArray = new Object[newCapacity];
			} finally {
				spinLock = 0;
			}
		  }
		 }
		}
		if (newArray == null)  
			Thread.yield();
		iLock.lock();
		if (newArray != null && backingArray == array) {
			backingArray = newArray;
			System.arraycopy(array, 0, newArray, 0, oldCapacity);
		}
	}

	private E dequeue() {
		int n = size() - 1;
		if (n < 0)
			return null;
		else {
			Object[] objArr = backingArray;
			E result = (E) objArr[0];
			E candidateNodeForBubble = (E) objArr[n];
			objArr[n] = null;
			bubbleUP(0, candidateNodeForBubble, objArr, n);
			size = n;
			return result;
		}
	}
	  
	
	   
	private static <T> void bubbleUp(int targetIndex, T bubbleNode, Object[] array) {
		Comparable<? super T> candidateNodeForBubble = (Comparable<? super T>) bubbleNode;
		while (targetIndex > 0) {
			int parentIndex = (targetIndex - 1) >>> 1;
			Object parent = array[parentIndex];
			if (candidateNodeForBubble.compareTo((T) parent) >= 0)
				break;
			array[targetIndex] = parent;
			targetIndex = parentIndex;
		}
		array[targetIndex] = candidateNodeForBubble;
	}

	private static <T> void bubbleUP(int targetIndex, T bubbleNode, Object[] array, int n) {
		if (n > 0) {
			Comparable<? super T> key = (Comparable<? super T>) bubbleNode;
			int half = n >>> 1;  
			while (targetIndex < half) {
				int child = (targetIndex << 1) + 1;  
				Object c = array[child];
				int right = child + 1;
				if (right < n && ((Comparable<? super T>) c).compareTo((T) array[right]) > 0)
					c = array[child = right];
				if (key.compareTo((T) c) <= 0)
					break;
				array[targetIndex] = c;
				targetIndex = child;
			}
			array[targetIndex] = key;
		}
	}
	
	 private void doHeapify() {
	        Object[] array = backingArray;
	        int n = size();
	        int half = (n >>> 1) - 1;
	        for (int i = half; i >= 0; i--)
	        	bubbleUP(i, (E) array[i], array, n);
	    }
	 
	  public int size() {
	        final ReentrantLock lock = this.iLock;
	        lock.lock();
	        try {
	            return size;
	        } finally {
	            lock.unlock();
	        }
	    }
	  
	  private static <T> void fixHeap(Object[] arr,int last) 
		{
			int currentIndex = 0;
			boolean isHeap = false;

			while (!isHeap) {
				int leftChildIndex = 2 * currentIndex + 1;
				int rightChildIndex = 2 * currentIndex + 2;
				int maxIndex = currentIndex;

				if (leftChildIndex <= last &&
						((Comparable<? super T>) arr[maxIndex]).compareTo((T) arr[leftChildIndex]) < 0) {
					maxIndex = leftChildIndex;
				}

				if (rightChildIndex <= last &&
						((Comparable<? super T>) arr[maxIndex]).compareTo((T) arr[rightChildIndex]) < 0) {
					maxIndex = rightChildIndex;
				}

				if (maxIndex != currentIndex) {
					// Swap list[currentIndex] with list[maxIndex]
					Object temp = arr[currentIndex];
					arr[currentIndex] = arr[maxIndex];
					arr[maxIndex] = temp;
					currentIndex = maxIndex;
				} else {
					isHeap = true;
				}
			}
		}

		private static <T> void createHeap(Object[] arr,int p) {
	 		int parent=p;
			while(parent> 0 &&  (((Comparable<? super T>) arr[parent]).compareTo((T) arr[(parent-1)/2]) > 0))
			{
				Object temp=arr[parent];
				arr[parent]=arr[(parent-1)/2];
				arr[(parent-1)/2]=temp;

				parent=(parent-1)/2;

			}
		}
}
