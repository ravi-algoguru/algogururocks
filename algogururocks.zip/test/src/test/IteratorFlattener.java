package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.function.Consumer;

public class IteratorFlattener<E> implements Iterator<E> {
	 protected transient int modCount = 0;
	ArrayList<Iterator<E>> iterList ;
	Iterator<E> mark;
	int markPosition;
	 int cursor;       // index of next element to return
     int lastRet = -1; // index of last element returned; -1 if no such
     int expectedModCount = modCount;
     int size;

     public IteratorFlattener(Iterator<Iterator<E>> root) {
    	 if(root == null || !root.hasNext())
        	 return;
    	 if(iterList == null)
        	 iterList = new ArrayList<Iterator<E>>();
    	 if(root.hasNext())
    		 mark = root.next();
         while(root.hasNext()){
        	 iterList.add(root.next());
        	 while(root.next().hasNext()){
        		 size++;
        	 }    		
         }   
      }
     
     public boolean hasNext() {
         if(mark.hasNext())
        	return true;
         return false;
     }
 
     public E next() {
         if(!mark.hasNext())
        	 throw new NoSuchElementException(); 
         return (E) mark.next();
         
     }

     public void remove() {
         if(mark.hasNext())
        	 ((Iterator<E>) mark.next()).remove();
         else
        	 throw new IllegalStateException ();
     }

     public static void main(String[] args){
    	 ArrayList  list1 = new ArrayList<>();
    	 ArrayList list2 = new ArrayList<>();
    	 ArrayList list3 = new ArrayList<>();
    	 Iterator<Iterator> root = null;
    			  
    	 
    	 
     }
}


 
