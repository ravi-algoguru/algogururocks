package test;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.Map;
import java.util.regex.Pattern;

class AThread extends Thread {

	public void run() {
		System.out.println("T2 started");
		synchronized (Test.lock) {
			System.out.println("Hi hello");
		}
	}
}

public class Test implements Runnable {

	public static final String lock = "lock";
	public static final String lock1 = "lock1";
	static Test t = new Test();
	static Thread T1 = new Thread(t, "Thread T1");
	static AThread T2 = new AThread();
	
	public void run() {

		synchronized (lock)

		{

			System.out.println("T1 started");
			try {

				System.out.println("waiting for T2 to join");
				T2.join();

			} catch (InterruptedException e) {

				System.out.println("e.getMessage() = " + e.getMessage());

			}
			System.out.println("T1 ended");

		}

	}

	public static void main(String[] args) {
//		Map map = Thread.currentThread().getAllStackTraces();
//         System.out.println(map);
//		T1.start();
//		Thread.yield();
//		T2.start();
//		ThreadMXBean mbean = ManagementFactory.getThreadMXBean();
//		long[] ids = mbean.findMonitorDeadlockedThreads(); 
	//	System.out.println(Pattern.compile("[a-zA-Z]").matcher("he' . "));
	//	 System.out.println(Pattern.matches("[a-zA-Z]+", ));
//		for(char ch : TestPallendrome.refArray){
//			System.out.print(ch +",");
//		}
		char[] ar1 = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O',
					'P','Q','R','S','T','U','V','W','X','Y','Z'};
		char[] ar2 = {'a','b','c','d' ,'e', 'f','g','h','i','j','k','l','m','n','o',
                'p','q','r','s','t','u','v','w','x','y','z'};
		 for(int i =0; i < ar1.length; i++){
			 System.out.print((ar2[2] -ar1[1]) +",");
		 }
		 System.out.println(('Z' -'a'));
		 System.out.println(('A' - 0));
		 System.out.println(('Z' - 0));
		 System.out.println(('a' - 0));
		 System.out.println(('z' - 0));
		 System.out.println("Madam, I'm Adam.".toUpperCase());
	}

	

}
