package test;
 

/**
 * @version $version$
 */

public class UIProgressObservable extends ProgressObservable {
    public final static int DECODING_STARTED = 0;
    public final static int DECODING_PROGRESS = 1;
    public final static int DECODING_FINISHED = 2;
    public final static int DECODING_FAILED = 3;

    public final static int ENCODING_STARTED = 4;
    public final static int ENCODING_PROGRESS = 5;
    public final static int ENCODING_FINISHED = 6;
    public final static int ENCODING_FAILED = 7;

    public final static int FILTER_ACTIVATED = 8;
    public final static int FILTER_DEACTIVATED = 9;

    public final static int FILE_MODIFIED = 10;

    public final static int RECOVERING_STARTED = 11;
    public final static int RECOVERING_FINISHED = 12;

    public final static int EDITING_STARTED = 13;
    public final static int EDITING_FINISHED = 14;
    public final static int EDITING_CANCELLED = 15;

    public final static int CHECK_CONNECTION = 16;

    // KD Fix : CR21:001
    public final static int VALIDATION_FAILED = 17;
    public final static int VALIDATION_COMPLETED = 18;

    // CR14
    public final static int FILTERING_STARTED = 19;
    public final static int FILTERING_COMPLETED = 20;
    public final static int FILTERING_FAILED = 21;
    public final static int MASS_EDITING_STARTED = 22;
    public final static int MASS_EDITING_COMPLETED = 23;
    public final static int MASS_EDITING_TOTAL_COMPLETED = 24;
    public final static int MASS_EDITING_FAILED = 25;
    public final static int VISIBLE_ACTION = 26;
    public final static int VISIBLE_CDRS_STATUS_CHANGED = 27;

    public final static int FILTERRESULTS_SUM_STARTED = 28;
    public final static int FILTERRESULTS_SUM_PROGRESS = 29;
    public final static int FILTERRESULTS_SUM_FINISHED = 30;
    public final static int FILTERRESULTS_SUM_FAILED = 31;

    public final static int FILTERRESULTS_COUNT_STARTED = 32;
    public final static int FILTERRESULTS_COUNT_PROGRESS = 33;
    public final static int FILTERRESULTS_COUNT_FINISHED = 34;
    public final static int FILTERRESULTS_COUNT_FAILED = 35;

    protected int myAction;
    protected Throwable myThrowable = null;
    protected boolean myIsRecoverableThrowable = true;

    /**
     * constructor. Initalizes the object ....
     */
    public UIProgressObservable() {
    }

    public void setAction(int action) {
        myAction = action;
    }

    public int action() {
        return myAction;
    }

    public void storeThrowable(Throwable progressThrowable, boolean isRecoverable) {
        myThrowable = progressThrowable;
        myIsRecoverableThrowable = isRecoverable;
    }

    public boolean isRecoverableThrowable() {
        return myIsRecoverableThrowable;
    }

    public boolean isThrowableStored() {
        return (myThrowable != null);
    }

    public Throwable retrieveThrowable() {
        Throwable t = myThrowable;
        myThrowable = null;
        return t;
    }
}
