package com.ericsson.cm.offlineGUI.dvrf.gui.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel; 

public class UICDRDocument implements Observer {
	protected Connection myAutoCommitConnection;
	protected Connection myTransactionConnection;

 	protected String myMainDBTablename;
	protected String myMainTableModifyColumnname;
	public String getMyMainTableModifyColumnname() {
		return myMainTableModifyColumnname;
	}

	private UIProgressObservable myProgressObservable = new UIProgressObservable();

	protected String myMainTableIndexColumnname;
	protected String myFilterMatchTablename;
	 
	protected String mySortFilterMatchTablename = "TEST_SORT";
	protected String myInsertSortSql;
	 
	protected String myMassEditMatchTablename;
	 
	protected boolean myIsTransactionDirty = false;
	protected boolean myIsDocumentDirty = false;

	protected PreparedStatement myDeleteFilterStatement;

	protected PreparedStatement myDeleteSortFilterStatement;
	protected PreparedStatement myInsertSortFilterStatement;

	 
	private Thread myWorkerThread;
 
	// KD Fix : CR21:002
	private int[] myFilteredCDRs = null;

	protected boolean myIsOpen = false;
	private boolean myIsReady = false;
	private boolean myReadOnly = false;
	private boolean myIsEncodingOrDecoding = false;
	protected boolean myIsFiltersActive = false;
	private boolean myIsEncodesAsUsed = false;
	private boolean myIsEncodeUsed = false;
	private boolean myIsBeingMassEdited = false;
	protected boolean myIsSorted = false;
	protected boolean myConnectionAlive = true;
	private boolean isBeingClosed = false;
	private boolean isRollbackInProgress = false;
	// private boolean isFilterResultsCountInProgress = false;
	// private boolean isSumResultsInProgress = false;

	// KD Fix : CR21:004 This flag will rmemeber if when the document has been
	// mass edited. If this flag is true, then data needs to be refreshed when
	// this document is selected in the tree. This will avoid unecessary calls
	// to teh database which fetch cdrs for documents on which user may never
	// click.
	private boolean myHasbeenMassEditedNotRefreshed = false;
	private boolean myIsDocModifiedAgain = true;
	private boolean myIsShowModifiedCalled = true;
	private PreparedStatement myFuncUsedPreparedStatement = null;

	protected PreparedStatement getCollectorIdFromUniqeIdTable;
	// protected Vector mySortedFields,mySortedOrder;

	 // CR3A
	private String m_fieldSelectionName = "";
 private int myVisibleUnmodifiedCDRS;
	private int myLastVisibleAction = 3;
	private int myCDRCount = 0;
	private int myModifiedCDRCount = 0;
	private int myModifiedCount = 0;
	// protected int myModCntTillSavPnt = 0;

	private Vector myEditedRowsVec = new Vector();
	private Vector myReadOnlyColumnVec = new Vector();
	private int myMassEditedCDRs = 0;
	private PreparedStatement myCountUnmodifiedStatement = null;
	private int myPageLimit = 100;
	private int myCurrNext = 0, myCurrPrev = 0;
	private int myFileCDRCount=0;
	public boolean automatedEditingapplied =false;
 	private int tmpClickedColumn = -1;
	private int myEditedCDRs;
	protected boolean connectionWasReset = false;
	protected boolean isOpenedForAutoProfileMode = false;
    private int errorCdrNum= -1;

	/*public UICDRDocument(UISession session, CDRDocument aAPICDRDocument)
			throws Exception {
		myServerSession = session;
		myAPICDRDocument = aAPICDRDocument;

		myAutoCommitConnection = myServerSession.autoDBConnection();
		myTransactionConnection = myServerSession.transactionDBConnection();
		myPageLimit = session.getPageSize();

	}*/
    
    
	 
	/**
	 * 
	 */
	public UICDRDocument() {
	}


	 

	/**
	 * @deprecated
	 */
	private void destroy() {
		

		// cleanup of references to help
		if (myProgressObservable != null)
			myProgressObservable.deleteObservers();
		// remove "cross references"
//				if (myDocumentInfo != null)
//					myDocumentInfo.destroy();
		myProgressObservable = null;
		//myAPICDRDocument = null;
 	}

	public void close() throws Exception 
	{
	     setIsBeingClosed(true);
	    progressObservable().setChanged();
	    progressObservable().notifyObservers(isBeingClosed);
		synchronized (this) 
		{
			if (!this.isOpen())
				return;
			try 
			{
				// rollback any pending db operations
				if (isTransactionDirty()) 
				{
		 			doRollback(false);
				}
 		while(true) 
					{
					 	System.out.println("Hello close");
					}
			 
			}
			catch (Exception e) 
			{
		 
			}
			myIsOpen = false;
			destroy();
		 
		}
	}

	 

	public boolean isReady() {
		return (myIsReady == true && myReadOnly == false);
	}

	public boolean isReadOnly() {
		return myReadOnly;
	}

	 
	public void update(Observable o, Object arg) {
	 	if(arg instanceof Boolean){
		   boolean isBeingClosed = (Boolean)arg;
		   if(isBeingClosed)
			  return;
		   }
		if (arg instanceof Boolean) {
			boolean ci = (Boolean) arg;
		 	while(true) {
				if(!isBeingClosed){
			 	myIsReady = true;
					 myProgressObservable
								.setAction(UIProgressObservable.VISIBLE_ACTION);
						myProgressObservable.setChanged();
						myProgressObservable.notifyObservers();
						 
						}
					}
			  
			 
			}
			if(!isBeingClosed)
				notifyRowsAdded();
		}
 

	protected void startRead() {
		myIsEncodingOrDecoding = true;
		Runnable readRunnable = new Runnable() {
			public void run() {
			 	try {
					read();
				} catch (Throwable t) {
				 	myReadOnly = true;
				 
					handleProgressException(t,
							UIProgressObservable.DECODING_FAILED);
				}
		 	}
		};
		myWorkerThread = new Thread(readRunnable, "CDRRepairDocumentRead");
		myWorkerThread.start();
	}

	private synchronized void read() throws Exception {
		myReadOnly = true;
		 
		int initialRead = 0;

		// we need to observe to make updates of available #CDRS
		myProgressObservable.addObserver(this);
		// EHSRAGA:Converted to thread Safe SwingWorker
		CDRRepairUtils.getInstance().excuteSafelyAndWait(new ACRSRunnable() {
			public void run() {

				myProgressObservable
						.setAction(UIProgressObservable.DECODING_STARTED);
				myProgressObservable.setChanged();
				myProgressObservable.notifyObservers();

				// we need to observe to make updates of available #CDRS
				// myProgressObservable.addObserver(this);
				
			}
		});
		// Converted to thread Safe SwingWorker
 	// EHSRAGA:Converted to thread Safe SwingWorker
		CDRRepairUtils.getInstance().excuteSafelyAndWait(new ACRSRunnable() {
			public void run() {
				myProgressObservable
				.setAction(UIProgressObservable.DECODING_PROGRESS);
				myProgressObservable.setChanged();
				myProgressObservable.notifyObservers(ci);
			}
		},true);
		// Converted to thread Safe SwingWorker

		// lets give the GUI some time to be updated
		Thread.currentThread().yield();

		// next read will block until EOF and notify with CI's
		// myAPICDRDocument.read(UIConfig.nextReadSizeSize,
		// myProgressObservable);
		// myAPICDRDocument.read(UIConfig.nextReadSizeSize);

		myReadOnly = false;

		// lets notify the other observers that we are done...
		// // EHSRAGA:Converted to thread Safe SwingWorker
		CDRRepairUtils.getInstance().excuteSafelyAndWait(new ACRSRunnable() {
			public void run() {
				myProgressObservable
						.setAction(UIProgressObservable.DECODING_FINISHED);
				myProgressObservable.setChanged();
				myProgressObservable.notifyObservers();

			}
		});
		// Converted to thread Safe SwingWorker

		// we no longer need to observe to make updates of available #CDRS
		myProgressObservable.deleteObserver(this);

		/**
		 * Now analyze the data tables
		 */
		/*
		 * UITableInfo[] tables = getTableInfo(); for (int i = 0; i <
		 * tables.length; i++) {
		 * myAPICDRDocument.analyze(tables[i].tablename()); }
		 */

		Debug.println("EXITING THE READ METHOD");
	}

	private void notifyRowsAdded() {
		safeNotifyRowsAdded();
	}

	private void safeNotifyRowsAdded() {
		Runnable doNotifyRowsAdded = new Runnable() {
			public void run() {
				 
			}
		};
	 	try {
			SwingUtilities.invokeAndWait(doNotifyRowsAdded);
		} catch (Exception e) {
		 }
	}

	public ProgressObservable progressObservable() {
		return myProgressObservable;
	}

	 

	 

	public boolean isMyReadOnly() {
		return myReadOnly;
	}

	public void setMyReadOnly(boolean myReadOnly) {
		this.myReadOnly = myReadOnly;
	}

	/**
	 * Edit this document accordning to the rules in the specified massEdit
	 * object
	 */
	public void massEdit(UIMassEdit massEdit, final boolean keepFilters,
			MassEditingStatusFrame msef) throws Exception {
		myReadOnly = true;
		this.setIsBeingMassEdited(true);
		myProgressObservable.setAction(UIProgressObservable.EDITING_STARTED);
		myProgressObservable.setChanged();
		myProgressObservable.notifyObservers();
		final UIMassEditFunction[] functions = massEdit.getMassEditFunctions();
		removeAllFilters(massEdit, keepFilters);

		// check if there are read only fields in the functions
		// of the me. If so prompt the user for continuing with
		// the mass edit. If yes then continue else cancel the
		// editing process which has been started.
		boolean retVal = checkForReadOnlyFields(functions);
		if (!retVal) {
			// cancel the mass editing
			setIsBeingMassEdited(false);
			myReadOnly = false;
			myProgressObservable
					.setAction(UIProgressObservable.EDITING_CANCELLED);
			myProgressObservable.setChanged();
			myProgressObservable.notifyObservers();
			return;
		}

		boolean errorInEditing = false;

		// before performing ME, reset the _MT table
		resetMassEditTable();
		for (int index = 0; index < functions.length; index++) {
			if (errorInEditing)
				break;
			// filters = functions[index].getFilters();
			UIMassEditFunction function = functions[index];
			errorInEditing = applyFilter(function, keepFilters, errorInEditing,
					index, msef);
			// CR1-ACRS4
			// Now update the LAST_USED_BY and LAST_USED_TIME in
			// GLOBALFUNCTIONPOOL tabel.
			//updUsedByTimeInDB(functions[index]);
			// CR1-ACRS4
		}

	

		if (!errorInEditing) {
			Debug.println("EDITING OVER, SETTING COUNT");
			// this piece of code figures out the cdrs which are
			// edited during mass edit and takes care not to count
			// sub table cdrs whose main table cdr is also edited
            int cdrsEdited = myEditedCDRs;
		    MassEditInfo mei = new MassEditInfo(0, cdrsEdited, 0);
			if (msef != null)
				msef.myupdate(mei, this, UIProgressObservable.EDITING_FINISHED);

			CountInfo info = new CountInfo(cdrsEdited, 100, 0);
	        resetEditedCDR();
			myProgressObservable
					.setAction(UIProgressObservable.EDITING_FINISHED);
			myProgressObservable.setChanged();
			myProgressObservable.notifyObservers(info);
		} else {
			myProgressObservable
					.setAction(UIProgressObservable.EDITING_CANCELLED);
			myProgressObservable.setChanged();
			myProgressObservable.notifyObservers();
		}
		
		this.setIsBeingMassEdited(false);
		myReadOnly = false;

		/*
		 * Check if this document is the current document, if so then refresh
		 * else skip
		 */
		// KD Fix : CR21:004
		if (getDesktopHandle().getHandleToMainPanel().getCurrentDocument() == this) {
			showModifiedOnly(myLastVisibleAction, true);
			setHasBeenMassEditedNotRefreshed(false);
		} else {
			setHasBeenMassEditedNotRefreshed(true);
		}

		this.setIsBeingMassEdited(false);
		myReadOnly = false;
	}

	// CR1-ACRS4
	public void updUsedByTimeInDB(UIMassEditFunction uimef) {
		ResultSet rs = null;
		String updVerQuery = myRes.getString("GlobalFunctionPool_Used_Update");
		
		try {
			myFuncUsedPreparedStatement = myServerSession.autoDBConnection()
					.prepareStatement(updVerQuery);
			myFuncUsedPreparedStatement.setLong(1, uimef.getFunctionId());
			myFuncUsedPreparedStatement.executeUpdate();
		} catch (Exception ex) {
			(new CDREExceptionDialog("Error in updating last used by ", ex))
					.showModal(); // To be changed...
		} finally {
			try {
				rs.close();
			} catch (Exception e) {
			}
		}
	}

	public boolean applyFilter(UIMassEditFunction function,
			boolean keepFilters, boolean errorInEditing, int index,
			MassEditingStatusFrame msef) throws Exception {
		MassEditInfo mei;
		if (!keepFilters) {
			// disable all filters.
			mei = new MassEditInfo(0, 0, index);

			setFiltersActive(false, index, null);
			myDocumentInfo.removeAllColumnFilters();
			myDocumentInfo.removeFilters();

			applyConditions(function, myDocumentInfo);
			try {
				setFiltersActive(true, index, msef);
			} catch (Exception fex) {
				{
					errorInEditing = true;
					if (msef != null) {
						mei = new MassEditInfo(-1, 0, index);
						mei.setThrowable(fex);
						msef.myupdate(mei, this,
								UIProgressObservable.FILTERING_FAILED);
					} else {
						throw fex;
					}
				}
			}
		}

		if (!errorInEditing) {
			try {
				mei = new MassEditInfo(0, 0, index);
				if (msef != null)
					msef.myupdate(mei, this,
							UIProgressObservable.MASS_EDITING_STARTED);
				massEdit(function.getUpdates(), index, msef,
						function.getFunctionId());
			} catch (Exception ex) {
				errorInEditing = true;
				mei = new MassEditInfo(0, -1, index);
				mei.setThrowable(ex);
				if (msef != null)
					msef.myupdate(mei, this,
							UIProgressObservable.MASS_EDITING_FAILED);
				/*
				 * myProgressObservable.storeThrowable(ex, false);
				 * myProgressObservable
				 * .setAction(UIProgressObservable.MASS_EDITING_FAILED);
				 * myProgressObservable.setChanged();
				 * myProgressObservable.notifyObservers(mei);
				 */

				/*
				 * Object[] args = {documentInfo().fullFilename()};
				 * CDREExceptionDialog dlg = new
				 * CDREExceptionDialog(myRes.getString
				 * ("UICDRDocument_noMassEdit", args), ex); dlg.showModal();
				 */
			}
		}
		return errorInEditing;
	}

	private void applyConditions(UIMassEditFunction function,
			UICDRDocumentInfo myDocumentInfo) {
		UIConditionList[] filters = function.getConditions();
		try {
			for (int fi = 0; fi < filters.length; fi++) {
				// changed for CR26
				myDocumentInfo.addFilter(new UIDocumentFilterInfo(filters[fi],
						true, myDocumentInfo.internalFormat()));
                myDocumentInfo.filtersForRule = true;
			}
		} catch (Exception ex) {
			// we should reach here only if the field to be
			// filtered on does not exist in the view
			// in which case don't set the active filters
			if (Debug.DEBUGMODE)
				ex.printStackTrace();

		}
	}

	private void removeAllFilters(UIMassEdit massEdit, boolean keepFilters)
			throws Exception {
		UIMassEditFunction[] functions = massEdit.getMassEditFunctions();
		if (functions.length > 0 && !keepFilters) {
			// disable all filters.
			setFiltersActive(false, -1, null);
			myDocumentInfo.removeAllColumnFilters();
			myDocumentInfo.removeFilters();
		}
	}

	// CR25
	public void removeAllFilters(boolean removeTableData) {
		/*
		 * PreparedStatement deleteFilterStatement = null; // disable all
		 * filters. String deleteSql =
		 * myRes.getString("UICDRDocument_deleteFilterSql"); Object[] args =
		 * {myFilterMatchTablename}; String theResultingSQLString =
		 * MessageFormat.format(deleteSql, args); Debug.println("sql:" +
		 * theResultingSQLString);
		 */
		try {
			setFiltersActive(false, -1, null);
			// myDocumentInfo.removeAllColumnFilters();
			// myDocumentInfo.removeFilters();
			UIDocumentFilterInfo[] allfilters = myDocumentInfo.getFilters();
			for(int i = 0 ; i<allfilters.length;i++)
			{
				allfilters[i].setActive(false);
			}
			
			refresh();
			/*
			 * deleteFilterStatement = myTransactionConnection.prepareStatement(
			 * theResultingSQLString); int numdeleted =
			 * deleteFilterStatement.executeUpdate();
			 */
		} catch (Exception ex) {
			Object[] args1 = { documentInfo().fullFilename() };
			CDREExceptionDialog dlg = new CDREExceptionDialog(myRes.getString(
					"UICDRDocument_removeFilterError", args1), ex);
			dlg.showModal();
		}
		if (removeTableData) {
			PreparedStatement deleteFilterStatement = null;
			String deleteSql = myRes.getString("UICDRDocument_deleteFilterSql");
			Object[] args = { myFilterMatchTablename };
			String theResultingSQLString = MessageFormat
					.format(deleteSql, args);
			Debug.println("sql:" + theResultingSQLString);
			try {
				deleteFilterStatement = gettransactionDBConnection()
						.prepareStatement(theResultingSQLString);
				int numdeleted = deleteFilterStatement.executeUpdate();
			} catch (Exception ex) {
				Object[] args1 = { documentInfo().fullFilename() };
				CDREExceptionDialog dlg = new CDREExceptionDialog(
						myRes.getString("UICDRDocument_removeFilterError",
								args1), ex);
				dlg.showModal();
			} finally {
				try {
					if (deleteFilterStatement != null)
						deleteFilterStatement.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		}
	}
	
	//prototype to be implemented in future
	public int removeFile(int i, UICDRDocumentSet docSet) {
       return 0;		
	}

	private boolean checkForReadOnlyFields(UIMassEditFunction[] functions) {
		boolean readOnlyFieldsFound = false;
		for (int i = 0; i < functions.length; i++) {
			UIMassEditFunction meFunc = functions[i];
			UIMassEditUpdate[] updates = meFunc.getUpdates();
			for (int j = 0; j < updates.length; j++) {
				UIMassEditUpdate update = updates[j];
				UICDRFieldInfo fieldInfo = myDocumentInfo
						.getFieldInfoForField(update.getFieldName());
				if (fieldInfo != null && fieldInfo.isFieldReadOnly()) {
					readOnlyFieldsFound = true;
					break;
				}
			}

			if (readOnlyFieldsFound)
				break;
		}

		if (readOnlyFieldsFound) {
			Object[] args = { documentInfo().fullFilename() };
			String msg = myRes.getString("UICDRDocument_readOnlyFieldFound",
					args);
			String title = myRes.getString("UICDRDocument_readOnlyFieldTitle");
			int userAnswer = JOptionPane.showConfirmDialog(null, msg, title,
					JOptionPane.YES_NO_OPTION);

			return (userAnswer == JOptionPane.YES_OPTION ? true : false);
		}

		return true; // continue with mass editing if no readonly fields

	}
	

	private boolean isMatchingTable(BufferedDBTable bdt, UIMassEditUpdate umeu) {
		UICDRFieldInfo field = null;
		UICDRFieldInfo[] fieldsInfo = getModifyFields();
		for (int j = 0; j < fieldsInfo.length; j++) {
			if (umeu.getFieldName().equals(fieldsInfo[j].fullFieldName())) {
				field = fieldsInfo[j];
				break;
			}
		}
		if (field !=null && field.dbTable() != null && field.dbTable().tablename().equalsIgnoreCase(bdt.tablename()))
		{
			return true;
		}
		return false;
	}

	private void massEdit(UIMassEditUpdate[] updates, int index,
			MassEditingStatusFrame msef, long aFuncId) throws Exception {
		TableUpdates tableUpdates = getTableUpdates(updates);

		int cdrsEdited = 0;
		Vector massEditedCDRsNum = null;
		for (int i = 0; i < myTables.length; i++) {
			// myTables[i].refresh();
			if (myTables[i].tableInfo().type() == TableInfo.SUBTABLE_TYPE
					&& tableUpdates.getSubTableUpdates().size() > 0) {
				Vector v = tableUpdates.getSubTableUpdates();
				for (int j=0 ; j< v.size();j++) {
					if (v.get(j) instanceof UIMassEditUpdate) {
						UIMassEditUpdate umeu = (UIMassEditUpdate) v.get(j);
						if(isMatchingTable(myTables[i],umeu)) {
							cdrsEdited += myTables[i].massEdit(umeu);
						}
					}
				}
			} else if (myTables[i].tableInfo().type() == TableInfo.MAINTABLE_TYPE
					&& tableUpdates.getNormalTableUpdates().size() > 0) {
				
				Vector v = tableUpdates.getNormalTableUpdates();
				for (int j=0 ; j< v.size();j++) {
					if (v.get(j) instanceof UIMassEditUpdate) {
						UIMassEditUpdate umeu = (UIMassEditUpdate) v.get(j);
						if(isMatchingTable(myTables[i],umeu)) {
							cdrsEdited += myTables[i].massEdit(umeu);
						}
					}
				}
				massEditedCDRsNum = myTables[i].getMassEditedCDRsNum();
			}
		}

		MassEditInfo mei = new MassEditInfo(0, cdrsEdited, index);
		if (msef != null)
			msef.myupdate(mei, this,
					UIProgressObservable.MASS_EDITING_COMPLETED);
		myProgressObservable
				.setAction(UIProgressObservable.MASS_EDITING_COMPLETED);
		myProgressObservable.setChanged();

		myProgressObservable.notifyObservers(mei);
		
		if (cdrsEdited > 0) {
			logUpdates(updates, massEditedCDRsNum, aFuncId,cdrsEdited);
        	myEditedCDRs = cdrsEdited;
		}
		
		// return cdrsEdited;
	}


  private void resetEditedCDR() {
		// TODO Auto-generated method stub
		myEditedCDRs = 0;
	}
	private void logUpdates(UIMassEditUpdate[] updates,
			Vector massEditedCDRsNum, long aFuncId,int noOfModifiedCDRs) throws SQLException {
		setIsModified(massEditedCDRsNum);
		//if (isLoggingAllowed()) {
			for (int i = 0; i < updates.length; i++) {
				UIMassEditUpdate update = updates[i];
				int startPosition = Log.NOT_APPLICABLE_NUMBER;
				int endPosition = Log.NOT_APPLICABLE_NUMBER;
				String matchValue = Log.NOT_APPLICABLE_STRING;

				if (update.getAction() == MassEditConstants.ACTION_SWAP) {
					if(update.getSwapIndexes() !=null) {
						startPosition = Integer.parseInt((String) update
								.getSwapIndexes().elementAt(0));
						endPosition = Integer.parseInt((String) update
								.getSwapIndexes().elementAt(1));
					} else {
						startPosition = Integer.parseInt((String)update.getStartPosition());
						endPosition = Integer.parseInt((String)update.getEndPosition());						
					}
					matchValue = update.getMatchValue();
				}
				if (aFuncId > 0) {
					Log.add(aFuncId, update.getFieldName(),
							update.getCdrSelectionModel(), update.getAction(),
							update.getChangePoint(), update.getSearchValue(),
							update.getNewValue(), update.getCdrRangeString(),
							startPosition, endPosition, matchValue,noOfModifiedCDRs,this);
				} else {
					Log.add(update.getFieldName(),
							update.getCdrSelectionModel(), update.getAction(),
							update.getChangePoint(), update.getSearchValue(),
							update.getNewValue(), update.getCdrRangeString(),
							startPosition, endPosition, matchValue,noOfModifiedCDRs,this);

				}

			}
		}
	

	private TableUpdates getTableUpdates(UIMassEditUpdate[] updates)
			throws Exception {
		TableUpdates tableUpdates = new TableUpdates();
		/*
		 * Vector subTableUpdates = new Vector(); Vector normalTableUpdates =
		 * new Vector();
		 */
		for (int i = 0; i < updates.length; i++) {
			UIMassEditUpdate update = updates[i];
			UICDRFieldInfo fieldInfo = myDocumentInfo
					.getFieldInfoForField(update.getFieldName());
			if (fieldInfo == null) {
				Object[] args = { update.getFieldName() };
				String msg = myRes.getString("UICDRDocument_fieldNotFound",
						args);
				throw new Exception(msg);
			}

			if (fieldInfo.isFieldReadOnly()) {
				// readOnlyFieldsFound = true;
				continue; // don't include updates pertaining to read only
							// fields
			}

			BufferedDBTable theTable = fieldInfo.dbTable();
			switch (theTable.tableInfo().type()) {
			case UITableInfo.MAINTABLE_TYPE:
				tableUpdates.addNormalTableUpdate(update);
				// normalTableUpdates.addElement(update);
				break;
			case UITableInfo.SUBTABLE_TYPE:
				// if (subTable == null)
				// subTable = theTable;
				tableUpdates.addSubTableUpdate(update);
				// subTableUpdates.addElement(update);
				break;
			default:
				break;
			}
		}
		return tableUpdates;
	}

	/*private void startEncode(final boolean parametersIsChanged) {

		myIsEncodingOrDecoding = true;
		Runnable readRunnable = new Runnable() {
			public void run() {
				Debug.println("ThreadStart:" + Thread.currentThread().getName());
				try {
					doEncode(parametersIsChanged);
				} catch (Throwable t) {
					handleProgressException(t,
							UIProgressObservable.ENCODING_FAILED);
				}
				Debug.println("ThreadStop:" + Thread.currentThread().getName());
			}
		};
		myWorkerThread = new Thread(readRunnable, "CDRRepairDocumentEncode");
		myWorkerThread.start();

	}*/

	private void handleProgressException(Throwable t, int progressActionCode) {
		boolean isRecoverable = false;
		Object notifyArg = null;

		// if this class is registered as observer, we need to do fetch data (if
		// any) before anything else...
		myProgressObservable.deleteObserver(this);

		if (t instanceof CDRParseException) {
			CDRParseException parseEx = (CDRParseException) t;
			notifyArg = parseEx.progressInfo();

			// explicit call to ensure it is called first...
			update(myProgressObservable, notifyArg);

			isRecoverable = true;
		}

		myProgressObservable.storeThrowable(t, isRecoverable);
		myProgressObservable.setAction(progressActionCode);
		myProgressObservable.setChanged();

		myProgressObservable.notifyObservers(notifyArg);
	}

	/*private synchronized void doEncode(boolean parameterChanged)
			throws Exception {

		Debug.println("INSIDE THE DO ENCODE METHOD");

		myProgressObservable.setAction(UIProgressObservable.ENCODING_STARTED);
		myProgressObservable.setChanged();
		myProgressObservable.notifyObservers();
		myProgressObservable.setAction(UIProgressObservable.ENCODING_PROGRESS);

		// if (myIsTransactionDirty == true)
		commitToDB();

		// allow close of frame without "Save Changes? dialog
		// if it fails halfway document is still close'able
		myIsDocumentDirty = false;

		this.myIsEncodeUsed = true;
		try {
			if (parameterChanged) {
				Debug.println("About to ENCODE AS properties:");
				Debug.println("myFullFilename: "
						+ myDocumentInfo.fullFilename());
				Debug.println("myFullModifiedFilename: "
						+ myDocumentInfo.fullModifiedFilename());
				Debug.println("myFullUnmodifiedFilename: "
						+ myDocumentInfo.fullUnmodifiedFilename());
				Debug.println("myFullMoveFilename: "
						+ myDocumentInfo.fullMoveFilename());

				// if(myDocumentInfo.fullModifiedFilename() != null &&
				// myDocumentInfo.fullUnmodifiedFilename()!= null )
				if (!myDocumentInfo.fullModifiedFilename().equals("")
						&& !myDocumentInfo.fullUnmodifiedFilename().equals("")) {
					// the EncodeAs with split file option
					myAPICDRDocument.saveAs(myDocumentInfo.modifiedFilename(),
							myDocumentInfo.modifiedFilepath(), myDocumentInfo
									.unmodifiedFilename(), myDocumentInfo
									.unmodifiedFilepath(), myDocumentInfo
									.externalFormat().id(), myDocumentInfo
									.fileFormat().id(), myDocumentInfo
									.fullMoveFilename(), myDocumentInfo
									.getCommentString(), myDocumentInfo
									.getCompressFile(), myProgressObservable);
				}
				// else if(myDocumentInfo.fullMoveFilename() == null )
				else if (myDocumentInfo.fullMoveFilename().equals("")) {
					// the encode function
					myAPICDRDocument.saveAs(myDocumentInfo.filename(),
							myDocumentInfo.filepath(), myDocumentInfo
									.externalFormat().id(), myDocumentInfo
									.fileFormat().id(), myDocumentInfo
									.getCommentString(), myDocumentInfo
									.getCompressFile(), myProgressObservable);
				} else {
					// the EncodeAs with move function
					myAPICDRDocument.saveAs(myDocumentInfo.filepath(),
							myDocumentInfo.filename(), myDocumentInfo
									.fullMoveFilename(), myDocumentInfo
									.externalFormat().id(), myDocumentInfo
									.fileFormat().id(), myDocumentInfo
									.getCommentString(), myDocumentInfo
									.getCompressFile(), myProgressObservable);
				}
			} else {
				com.ericsson.cm.offlineGUI.dvrf.gui.util.Debug
						.println("INSIDE SIMPLE ENCODE");
				myAPICDRDocument.save(myProgressObservable);
			}
		} catch (Exception ex) {
			// NOTE : If encoding fails, then since the fullFileName field in
			// the
			// class UICDRDocumentInfo is set (before encoding starts) the
			// information
			// in UICDRDocumentInfo regarding the filename is wrong.Therefore it
			// is
			// required to reset the value of the fullFileName variable
			myDocumentInfo.setFullFilename(myDocumentInfo
					.originalFullFilename());
			throw ex;
		}

		Debug.println("BEFORE GIVING CALLS TO OBSERVABLE");
		myProgressObservable.setAction(UIProgressObservable.ENCODING_FINISHED);
		myProgressObservable.setChanged();
		myProgressObservable.notifyObservers();
		Debug.println("AFTER CALLS TO OBSERVABLE IS OVER");

		Debug.println("LEAVING THE DO ENCODE METHOD");

	}*/

	public boolean isTransactionDirty() {
		return myIsTransactionDirty;
	}

	public boolean isDirty() {
		if (myIsTransactionDirty)
			return true;
		else
			return myIsDocumentDirty;
	}

	public boolean isValidFormats() {
		/*
		 * if (myDocumentInfo == null) return true; return
		 * myDocumentInfo.fileFormat().isEncodeValid();
		 */
		return true;
	}

	public boolean isRollbackInProgress() {
		return isRollbackInProgress;
	}

	public void rollbackChangesInDB() throws Exception {
		isRollbackInProgress = true;
		try {
			doRollback(true);
			// refresh buffers so gui shows the old savepoint values
			if (myProgressObservable.action() == UIProgressObservable.EDITING_FINISHED) {
				myProgressObservable
						.setAction(UIProgressObservable.EDITING_CANCELLED);
				myProgressObservable.setChanged();
				myProgressObservable.notifyObservers();
			}
			/*setFiltersActive(false, -1, null);*/
			setFiltersActive(true, -1, null);
			myMassEditedCDRs = 0;
			myEditedRowsVec.removeAllElements();
			refresh();
			myModifiedCount = getmyCDRCount();
			myVisibleUnmodifiedCDRS = myModifiedCount;
			myProgressObservable.setAction(UIProgressObservable.VISIBLE_ACTION);
			myProgressObservable.setChanged();
			myProgressObservable.notifyObservers();
			if (!isDirty()) {
				myProgressObservable
						.setAction(UIProgressObservable.EDITING_CANCELLED);
				myProgressObservable.setChanged();
				myProgressObservable.notifyObservers();
			}
		} finally {
			isRollbackInProgress = false;
		}
	}

	private void doRollback(boolean uptoSavePnt) throws Exception {
		Log.cleanLog(this, uptoSavePnt);
		gettransactionDBConnection().rollback();
		myIsTransactionDirty = false;
		Debug.println("ROLLBACK");
	}

	public void refresh() throws Exception {
		Debug.println("REFRESH");
		if ((!this.isBeingClosed()) && (!this.isBeingEncoded())
				&& this.isReady()) {
			showModifiedOnly(myLastVisibleAction, true);
		} else {
			for (int i = 0; i < myTables.length; i++) {
				BufferedDBTable currentTable = myTables[i];
				currentTable.refresh();
			}
			refreshAll();
		}
	}

	public void refreshAll() throws Exception {
		Debug.println("REFRESHALL");
		if (mySelectedNodeIndexModel != null)
			mySelectedNodeIndexModel.fireTableDataChanged();
		if (mySelectedNodeDataModel != null)
			mySelectedNodeDataModel.fireTableDataChanged();
		setHasBeenMassEditedNotRefreshed(false);
	}

	public boolean isNeedToBeRefrehed() {
		return ((hasBeenMassEditedNotRereshed() && !getEncodingOrDecoding()) || (isShowModifiedCalled()));
	}

	public Vector getEditedRowsVec() {
		return myEditedRowsVec;
	}

	public void setIsModified(Vector editedRowNum) {
		if ((myLastVisibleAction == BufferedDBTable.ALLCDRS)
				||(myLastVisibleAction == BufferedDBTable.MODIFIEDONLY)
				|| (myLastVisibleAction == BufferedDBTable.UNMODIFIEDONLY)) {
			if (editedRowNum != null) {
				for (int i = 0; i < editedRowNum.size(); i++) {
					myEditedRowsVec.addElement(editedRowNum.elementAt(i));
				}
			}
			Vector br = getDesktopHandle().getHandleToMainPanel()
					.getCellRenderer();
			if (br != null && myEditedRowsVec.size() > 0) {
				for (int i = 0; i < br.size(); i++) {
					((BaseRenderer) br.elementAt(i))
							.setEditedRowsVector(myEditedRowsVec);
				}
			}
		}
		myIsTransactionDirty = true;
		Debug.println("Going to set the transaction dirty...");
		myIsTransactionDirty = true;
		Debug.println("Going to send VISIBLE_CDRS_STATUS_CHANGED event....");
		myIsDocModifiedAgain = true;
		if (editedRowNum != null) {
			myProgressObservable
					.setAction(UIProgressObservable.VISIBLE_CDRS_STATUS_CHANGED);
			myProgressObservable.setChanged();
			myProgressObservable.notifyObservers();
		}
		setHasBeenMassEditedNotRefreshed(true);
	}

public void setIsReadOnly(Vector readOnlyColumn) {
		if (readOnlyColumn != null) {
			for (int i = 0; i < readOnlyColumn.size(); i++) {
				myReadOnlyColumnVec.addElement(readOnlyColumn.elementAt(i));
			}
		}
		Vector br = getDesktopHandle().getHandleToMainPanel()
				.getCellRenderer();
		if (br != null && myReadOnlyColumnVec.size() > 0) {
			for (int i = 0; i < br.size(); i++) {
				((BaseRenderer) br.elementAt(i))
						.setReadOnlyColumnVector(myReadOnlyColumnVec);
			}
		}
	}


	protected DVRFWindow getDesktopHandle() {
		return CDRRepairApp.m_sDesktop;
	}
	
	
	private void initFilterStatements() throws Exception {
		String deleteSql = myRes.getString("UICDRDocument_deleteFilterSql");
		Object[] args = { myFilterMatchTablename };
		String theResultingSQLString = MessageFormat.format(deleteSql, args);
		Debug.println("sql:" + theResultingSQLString);
		// myDeleteFilterStatement =
		// myAutoCommitConnection.prepareStatement(theResultingSQLString);
		myDeleteFilterStatement = gettransactionDBConnection()
				.prepareStatement(theResultingSQLString);
		/*
		 * String insertSql =
		 * MessageFormat.format(myRes.getString("UICDRDocument_filterInsert"),
		 * args); myInsertFilterStatement =
		 * myAutoCommitConnection.prepareStatement(insertSql);
		 */
	}

	private void initSortFilterStatements() throws Exception {
		StringBuffer buff = new StringBuffer();
		String deleteSql = myRes.getString("UICDRDocument_deleteSortSql");
		Object[] args = { mySortFilterMatchTablename };
		String theResultingSQLString = MessageFormat.format(deleteSql, args);
		Debug.println("sql:" + theResultingSQLString);
		myDeleteSortFilterStatement =  gettransactionDBConnection()
				.prepareStatement(theResultingSQLString);
      	myDeleteSortFilterStatement.setInt(1,documentInfo().getUniqueId() );

		buff.delete(0, buff.length());
		buff.append(MessageFormat.format(
				myRes.getString("UICDRDocument_sortInsert"), args));
		buff.append(" ( ");

		UIColumnInfo[] columns = mySortTableinfo.columns();
		for (int i = 0; i < columns.length; i++) {
			if (i != 0)
				buff.append(" ,");
			else
				buff.append(" ");
			buff.append(columns[i].name());
		}
		buff.append(" ) ");
		myInsertSortSql = buff.toString();
		buff.append("? ");
		String insertSql = buff.toString();
		Debug.println("Insert Sort .........:::" + insertSql);
		Debug.println("myInsertSort SQL.........:::" + myInsertSortSql);
		myInsertSortFilterStatement = myAutoCommitConnection
				.prepareStatement(insertSql);
	}

	public boolean isFiltersActive() {
		return myIsFiltersActive;
	}

	public void setFiltersActive(boolean active, int index,
			MassEditingStatusFrame msef) throws Exception {
		Debug.println("UICDRDocument.setFiltersActive(" + active + ")");

		myIsFiltersActive = active;
		if (active) {
			// activateFilter();
			try {
				this.activateCondition(index, msef);

				// CR26
				//myServerSession.getFilterStorage().setFilters(
				//		this.documentInfo().getFilters());
				// CR26
			} catch (Exception ex) {
				// ex.printStackTrace();
				myIsFiltersActive = false;
				throw ex;
			}
		}

		for (int i = 0; i < myTables.length; i++) {
			BufferedDBTable currentTable = myTables[i];
			currentTable.setFilterActive(myIsFiltersActive);
		}

		// notification to progressbar that filterstatus has changed
		// lets notify the other observers that we are done...
		int action_indicator;
		if (myIsFiltersActive)
			action_indicator = UIProgressObservable.FILTER_ACTIVATED;
		else
			action_indicator = UIProgressObservable.FILTER_DEACTIVATED;

		myProgressObservable.setAction(action_indicator);
		myProgressObservable.setChanged();
		myProgressObservable.notifyObservers();

		Debug.println("UICDRDocument.setFiltersActive done ");
	}

	protected void activateCondition(int index, MassEditingStatusFrame msef)
			throws Exception {
		// delete all current rows from the filtermatchtable
		String deleteSql = myRes.getString("UICDRDocument_deleteFilterSql");
		String uniqueIDSql = "where \""+ myFilterMatchTablename+"\".unique_id = ";
		Object[] args = { myFilterMatchTablename };
		String theResultingSQLString1 = MessageFormat.format(deleteSql, args);		
		theResultingSQLString1 = theResultingSQLString1 + " " + uniqueIDSql + myDocumentInfo.getUniqueId();
						
		Debug.println("sql:" + theResultingSQLString1);
		myDeleteFilterStatement = gettransactionDBConnection()
				.prepareStatement(theResultingSQLString1);
		try {
			int numdeleted = myDeleteFilterStatement.executeUpdate();
			Debug.println("myDeleteFilterStatement.executeUpdate:" + numdeleted);
		} catch (Exception ex) {
			myTransactionConnection.rollback();
			throw ex;
		} finally {
			myDeleteFilterStatement.close();
		}

		StringBuffer sqlbuf = new StringBuffer();
		sqlbuf.append(generateFilterSQL());
		String theResultingSQLString = sqlbuf.toString();
		if (theResultingSQLString == null
				|| theResultingSQLString.trim().length() < 1) {
			myIsFiltersActive = false;
			return;
		}

		Debug.println("sql:" + theResultingSQLString);
		Debug.println("====================================================");
		Debug.println("bef fill filtertable" + new java.util.Date());
		// Statement filterUpdateStat =
		// myAutoCommitConnection.createStatement();
		Statement filterUpdateStat =gettransactionDBConnection().createStatement();
		sqlbuf.delete(0, sqlbuf.length());
		sqlbuf.append("Insert into " + "\"" +  myFilterMatchTablename + "\"" + " ( "
				+ myFiltertableinfo.columns()[1]+","+ myFiltertableinfo.columns()[0] + ")"
				+ theResultingSQLString);				
		Debug.println("Filter insert SQL :" + sqlbuf.toString());
		// System.out.println("Filter insert SQL :" + sqlbuf.toString());
		MassEditInfo mei;
		mei = new MassEditInfo(0, 0, index);
		if (msef != null)
			msef.myupdate(mei, this, UIProgressObservable.FILTERING_STARTED);
		/*
		 * myProgressObservable.setAction(UIProgressObservable.FILTERING_STARTED)
		 * ; myProgressObservable.setChanged();
		 * System.out.println("Filtering Started");
		 * myProgressObservable.notifyObservers(mei);
		 */
		int rec = -1;
		try {
			rec = filterUpdateStat.executeUpdate(sqlbuf.toString());
		} catch (Exception ex) {
			myTransactionConnection.rollback();
			throw ex;
		} finally {
			filterUpdateStat.close();
		}
		Debug.println("aft fill filtertable--rec updated :" + rec + "on Date :"
				+ new java.util.Date());
		Debug.println("aft fill filtertable" + new java.util.Date());
		Debug.println("====================================================");

		mei = new MassEditInfo(rec, 0, index);
		if (msef != null)
			msef.myupdate(mei, this, UIProgressObservable.FILTERING_COMPLETED);
		/*
		 * myProgressObservable.setAction(UIProgressObservable.FILTERING_COMPLETED
		 * ); myProgressObservable.setChanged();
		 * System.out.println("Filtering Completed");
		 * myProgressObservable.notifyObservers(mei);
		 */
	}

	protected String generateFilterSQL() throws Exception {
		UICDRDocumentInfo docInfo = documentInfo();
		UIDocumentFilterInfo[] filterInfo = docInfo.getFilters();
		StringBuffer buff = new StringBuffer();
		StringBuffer sBuff = new StringBuffer();
		BufferedDBTable currentTable = null;
		String SPACE = " ";
		UIColumnFilter filter;
		UIMassEditFilter meFilter;
		UIColumnInfo column;
		String val;
		UIFilterInfoList filtersToBeRemoved = new UIFilterInfoList();
		for (int i = 0; i < filterInfo.length; i++) {
			if (filterInfo[i].isActive()) {
				UIConditionList condition = filterInfo[i].getCondition();
				for (int ci = 0; ci < condition.size(); ci++) {
					UIConditionRow row = condition.conditionAt(ci);
					if (row.isBoundry()) {
						// no need to create Filter..
						buff.append(SPACE);
						buff.append(row.getGroupOpString(row.groupOperator()));
						buff.append(SPACE);
						buff.append(row.getOperatorString(row.operator()));
					} else {
						// create filter...
						buff.append(SPACE);
						meFilter = row.filter();
						try {
							Debug.println("ME FILTER is :"
									+ meFilter.getField());
							Debug.println("ME FILTER is :"
									+ meFilter.getOperator());
							Debug.println("ME FILTER is :"
									+ meFilter.getValue());
							column = docInfo.getColumnInfoForField(meFilter
									.getField());
							if (column == null) { // throw new
													// Exception("NO_FIELD");
								Object args[] = { meFilter.getField() };
								throw new NotFoundException(myRes.getString(
										"UICDRDocument_fieldNotFound", args));
							}
							filter = new UIColumnFilter(column,
									meFilter.getOperator(), meFilter.getValue());
							column.addFilter(filter);
						} catch (Exception ex) {
							// may happen if field not present...
							if (Debug.DEBUGMODE)
								ex.printStackTrace(Debug.debugStream);
							buff.delete(0, buff.length());
							throw ex;
						}
						for (int tb = 0; tb < myTables.length; tb++) {
							currentTable = myTables[tb];
							val = currentTable.getFilterValue(filter);
							if (val != null) {
								buff.append("\"" + currentTable.tablename() + "\"" + "." + val);
								buff.append(SPACE);
							}
						}
						column.removeFilter(filter);
						buff.append(row.getOperatorString(row.operator()));						
					}
				}

				if (buff.length() > 0) {
					buff.insert(0, "(");
					buff.append(" and \""+ currentTable.tablename()+"\".unique_id ="+myDocumentInfo.getUniqueId());

					//In case the document was opened with Range
					if ( (myMainDBTable.getMyStartRange() > -1) && (myMainDBTable.getMyEndRange() > -1) )
					{
						String indexColumnName = "\"" + currentTable.tablename() + "\"." + myMainTableIndexColumnname;
						buff.append(" and " + indexColumnName + " >= " + myMainDBTable.getMyStartRange() + 
								"and " + indexColumnName + " <= " + myMainDBTable.getMyEndRange() );
					}
					buff.append(")");
				}

				buff.insert(0, createSelectFilterPhrase(false));
				Debug.println("------------------------------------");
				Debug.println("generateFilterSQL :" + buff.toString());
				Debug.println("------------------------------------");
				if (sBuff.length() > 0)
					sBuff.append(" INTERSECT ");
				sBuff.append(buff.toString());
				buff.delete(0, buff.length());
			}
		}
		Debug.println("------------------------------------");
		Debug.println("Final generateFilterSQL :" + sBuff.toString());
		Debug.println("------------------------------------");

		for (int ls = 0; ls < filtersToBeRemoved.size(); ls++) {
			docInfo.removeFilter(filtersToBeRemoved.filterInfoAt(ls));
		}

		return sBuff.toString();
	}

	/**
	 * This method creates the query for fetching the count for each filter
	 * condition.
	 * 
	 * @param aCondition
	 * @return The query that fetches the count for each filter condition.
	 * @throws Exception
	 */
	private String generateFilterCountSQLForACondition(
			UIConditionList aCondition) throws Exception {
		UICDRDocumentInfo theDocInfo = documentInfo();
		StringBuffer theBuff = new StringBuffer();
		StringBuffer theSBuff = new StringBuffer();
		BufferedDBTable theCurrentTable;
		String SPACE = " ";
		UIColumnFilter theFilter;
		UIMassEditFilter theMeFilter;
		UIColumnInfo theColumn;
		String theVal;
		for (int ci = 0; ci < aCondition.size(); ci++) {
			UIConditionRow row = aCondition.conditionAt(ci);
			if (row.isBoundry()) {
				// no need to create Filter..
				theBuff.append(SPACE);
				theBuff.append(row.getGroupOpString(row.groupOperator()));
				theBuff.append(SPACE);
				theBuff.append(row.getOperatorString(row.operator()));
			} else {
				// create filter...
				theBuff.append(SPACE);
				theMeFilter = row.filter();
				try {
					Debug.println("ME FILTER is :" + theMeFilter.getField());
					Debug.println("ME FILTER is :" + theMeFilter.getOperator());
					Debug.println("ME FILTER is :" + theMeFilter.getValue());
					theColumn = theDocInfo.getColumnInfoForField(theMeFilter
							.getField());
					if (theColumn == null) { // throw new Exception("NO_FIELD");
						Object args[] = { theMeFilter.getField() };
						throw new NotFoundException(myRes.getString(
								"UICDRDocument_fieldNotFound", args));
					}
					theFilter = new UIColumnFilter(theColumn,
							theMeFilter.getOperator(), theMeFilter.getValue());
					theColumn.addFilter(theFilter);
				} catch (Exception ex) {
					// may happen if field not present...
					if (Debug.DEBUGMODE)
						ex.printStackTrace(Debug.debugStream);
					theBuff.delete(0, theBuff.length());
					throw ex;
				}
				for (int tb = 0; tb < myTables.length; tb++) {
					theCurrentTable = myTables[tb];
					theVal = theCurrentTable.getFilterValue(theFilter);
					if (theVal != null) {
						theBuff.append(theVal);
						theBuff.append(SPACE);
					}
				}
				theColumn.removeFilter(theFilter);
				theBuff.append(row.getOperatorString(row.operator()));
			}
		}

		if (theBuff.length() > 0) {
			theBuff.insert(0, "(");
			theBuff.append(")");
		}

		theBuff.insert(0, createSelectFilterPhrase(true));
		theSBuff.append(theBuff.toString());

		return theSBuff.toString();
	}

	/*
	 * private String createSelectFilterPhrase() { StringBuffer buff = new
	 * StringBuffer(); String SPACE = " "; buff.append("SELECT DISTINCT ");
	 * buff.append(myMainDBTable.getKeyColumnName()); buff.append(" FROM ");
	 * buff.append(myMainDBTable.tablename()); for (int i = 1; i <
	 * myTables.length; i++) { if (myTables[i].getRowCount() > 0) {
	 * buff.append(SPACE); buff.append(",");
	 * buff.append(myTables[i].tablename()); } } buff.append(" WHERE ");
	 * 
	 * for (int i = 1; i < myTables.length; i++) { if (myTables[i].getRowCount()
	 * > 0) { if (i > 1) buff.append(" AND , ");
	 * buff.append(myMainDBTable.getKeyColumnName()); buff.append(" = ");
	 * buff.append(myTables[i].getKeyColumnName()); } } if (myTables.length > 1
	 * && (buff.toString().substring(buff.toString().indexOf("WHERE ") +
	 * 6)).length() > 0) buff.append(" AND "); return buff.toString(); }
	 */

	/**
	 * It creates the select clause for filter.
	 * 
	 * @return The select clause of the query.
	 */
	private String createSelectFilterPhrase(boolean isCountPhrase) {
		StringBuffer theBuff = new StringBuffer();
		String SPACE = " ";
		// theBuff.append("SELECT count(DISTINCT ");
		if (isCountPhrase) {
			theBuff.append("SELECT count(DISTINCT ");
			theBuff.append("\""+myMainDBTable.tablename() + "\"" + "." + myMainDBTable.getKeyColumnName());
			theBuff.append(",");
			theBuff.append("\""+myMainDBTable.tablename() + "\"" + "." + myMainDBTable.getUniqueColumnName());
			theBuff.append(") FROM ");
		} else {
			theBuff.append("SELECT DISTINCT ");
			theBuff.append("\""+myMainDBTable.tablename()  + "\""  + "." + myMainDBTable.getKeyColumnName());
			theBuff.append("," + "\""+myMainDBTable.tablename() + "\""  + "." + myMainDBTable.getUniqueColumnName());
			theBuff.append(" FROM ");
		}
		theBuff.append("\""+myMainDBTable.tablename()+"\"");
		for (int i = myTables.length - 2; i >=0; i--) {
			theBuff.append(SPACE);
			theBuff.append("left outer join ");
			theBuff.append("\""+myTables[i].tablename()+"\"");
			theBuff.append(" on (");
			theBuff.append("\""+myMainDBTable.tablename()+"\"" + "." + myMainDBTable.getKeyColumnName());
			theBuff.append(" = ");
			theBuff.append("\""+myTables[i].tablename()+"\"" + "." + myTables[i].getKeyColumnName());
			theBuff.append(" and ");
			theBuff.append("\""+myMainDBTable.tablename()+"\"" + "." + "unique_id");
			theBuff.append(" = ");
			theBuff.append("\""+myTables[i].tablename()+"\"" + "." + "unique_id");
			String str[] = myTables[i].getMyIndexColumnListString().split(",");
			if (str!=null && str.length >2) {
				for (int j=1; j<str.length -1 ; j++) {
					String index = str[j];
					theBuff.append(" and ");
					theBuff.append("\""+ myTables[i].tableInfo().getMyParentTableName() +"\"" + "." + index);
					theBuff.append(" = ");
					theBuff.append("\""+myTables[i].tablename()+"\"" + "." + index);
				}
			}
			theBuff.append(" )");
		}
		theBuff.append(" WHERE ");
		boolean myTableNotEmpty = false;
		if (myTables.length > 1
				&& (theBuff.toString().substring(theBuff.toString().indexOf(
						"WHERE ") + 6)).length() > 0)
			theBuff.append(" AND ");
		return theBuff.toString();
	}

	private void activateSorting(Vector selectedFields, Vector orderTypes)
			throws Exception {
		// delete all current rows from the sort table
		Debug.print("delete all current rows from the sort table");

		int numdeleted = myDeleteSortFilterStatement.executeUpdate();
		Debug.println("myDeleteSortFilterStatement.executeUpdate:" + numdeleted);

		// create the matching rows..
		// (we cant prepare this statement because filter criterias change
		// between apply occasions....)
		// only applicable for main table only....
		BufferedDBTable currentTable = myMainDBTable;
		String orderBySQL = currentTable.getMainSortPhrase(selectedFields,
				orderTypes);
		Debug.println("orderByInfo# " + orderBySQL);
		Debug.println("sql:" + orderBySQL);

		Statement filterUpdateStat = gettransactionDBConnection().createStatement();
		StringBuffer sqlbuf = new StringBuffer();
		// sqlbuf.append("select rownum , Index1_1 from ( "+ orderBySQL +" )");
		sqlbuf.append(myRes.getString("UICDRDocument_sortSQL", new Object[] {
				myMainDBTable.getKeyColumnName(), orderBySQL }));
		String theResultingSQLString = sqlbuf.toString();
		sqlbuf.delete(0, sqlbuf.length());
		// sqlbuf.append("Insert into "+ mySortFilterMatchTablename
		// +" (SIndex1 , SIndex2) "+theResultingSQLString);
		sqlbuf.append(myInsertSortSql);
		sqlbuf.append(" ");
		sqlbuf.append(theResultingSQLString);
		Debug.println("++++++++++++++++++++++++++++++++++++++++");
		Debug.println("bef fill sorttable" + new java.util.Date());
		Debug.println(" Resulting SQL string is :" + sqlbuf.toString());
		int rec = filterUpdateStat.executeUpdate(sqlbuf.toString());
		filterUpdateStat.close();

		/*
		 * myInsertSortFilterStatement.setString(1,theResultingSQLString);
		 * myInsertSortFilterStatement.executeUpdate();
		 */
		Debug.println("aft fill sorttable" + new java.util.Date());
		Debug.println("++++++++++++++++++++++++++++++++++++++++");

	}

	public UICDRFieldInfo getRootNode() {
		return myDocumentInfo.rootNode();
	}

	public UICDRFieldInfo getFieldInfo(int selectedColumnNo) {
		return mySelectedFields[selectedColumnNo];
	}

	/*
	 * private void buildTables() throws Exception {
	 * Debug.println("BUILDTABLES"); Vector tablesVector = new Vector();
	 * 
	 * ColumnInfo[] mainTableColumns = new ColumnInfo[10] ; ColumnInfo col1 =
	 * new ColumnInfo("INDEX1_1","Index 1 of top",0); ColumnInfo col2 = new
	 * ColumnInfo("ROWISMODIFIED2_2","ROWISMODIFIED",1); ColumnInfo col3 = new
	 * ColumnInfo("COLUMN3_3","ASCIISTRUCTI",2); ColumnInfo col4 = new
	 * ColumnInfo("COLUMN4_4","ASCIISTRUCTI.anumber",2); ColumnInfo col5 = new
	 * ColumnInfo("COLUMN5_5","ASCIISTRUCTI.bnumber",2); ColumnInfo col6 = new
	 * ColumnInfo("COLUMN6_6","ASCIISTRUCTI.date",2); ColumnInfo col7 = new
	 * ColumnInfo("COLUMN7_7","ASCIISTRUCTI.time",2); ColumnInfo col8 = new
	 * ColumnInfo("COLUMN8_8","ASCIISTRUCTI.nick",2); ColumnInfo col9 = new
	 * ColumnInfo("COLUMN9_9","ASCIISTRUCTI.field02",2); ColumnInfo col10 = new
	 * ColumnInfo("COLUMN10_10","ASCIISTRUCTI.field03",2);
	 * 
	 * mainTableColumns[0] = col1; mainTableColumns[1] = col2;
	 * mainTableColumns[2] = col3; mainTableColumns[3] = col4;
	 * mainTableColumns[4] = col5; mainTableColumns[5] = col6;
	 * mainTableColumns[6] = col7; mainTableColumns[7] = col8;
	 * mainTableColumns[8] = col9; mainTableColumns[9] = col10;
	 * 
	 * 
	 * TableInfo maintableInfo = new
	 * TableInfo("CDRREP_1339408647_28003_0",0,mainTableColumns); UITableInfo
	 * mainTable = new UITableInfo(maintableInfo);
	 * 
	 * 
	 * // first we must find out some tablenames (i.e filtermatchtable)
	 * 
	 * UITableInfo tableinfo = mainTable; Debug.println("Table name is " +
	 * tableinfo.tablename() + " Table type is " + tableinfo.type());
	 * myMainDBTablename = tableinfo.tablename(); myMainTableModifyColumnname =
	 * tableinfo.modifyColumn(); myMainTableIndexColumnname =
	 * tableinfo.indexColumns()[0].name();
	 * 
	 * 
	 * 
	 * 
	 * BufferedDBTable dbtab = new BufferedDBTable( myTransactionConnection,
	 * this, tableinfo, myMainDBTablename, myMainTableIndexColumnname,
	 * myMainTableModifyColumnname);
	 * 
	 * if (tableinfo.type() == UITableInfo.MAINTABLE_TYPE) { myMainDBTable =
	 * dbtab; tablesVector.add(dbtab); }
	 * 
	 * 
	 * 
	 * 
	 * myTables = new BufferedDBTable[tablesVector.size()]; myTables =
	 * (BufferedDBTable[]) tablesVector.toArray(myTables); }
	 */

	/* Following method is created to handle complex type */
	private void buildTables() throws Exception {

		Debug.println("BUILDTABLES");

		UITableInfo[] tables = getTableInfo();
		Debug.println("Number of tables returned " + tables.length);
		// UITableInfo filtertableinfo=null;
		// UITableInfo sortTableinfo=null;
		Vector tablesVector = new Vector();

		// first we must find out some tablenames (i.e filtermatchtable)
		for (int i = 0; i < tables.length; i++) {

			UITableInfo tableinfo = tables[i];
			Debug.println("Table name is " + tableinfo.tablename()
					+ " Table type is " + tableinfo.type());

			if (tableinfo.type() == UITableInfo.MAINTABLE_TYPE) {
				myMainDBTablename = tableinfo.tablename();
				myMainTableModifyColumnname = tableinfo.modifyColumn();
				myMainTableIndexColumnname = tableinfo.indexColumns()[0].name();
			}
			 if (tableinfo.type() == UITableInfo.FILTERTABLE_TYPE) {
	                myFilterMatchTablename = tableinfo.tablename();
	                myFiltertableinfo = tableinfo;
	            }
			 if (tableinfo.type() == UITableInfo.MASSEDITTABLE_TYPE) {
				 myMassEditMatchTablename = tableinfo.tablename();
				 myMassEditTableinfo = tableinfo;
			 }
 if (tableinfo.type() == UITableInfo.SORTTABLE_TYPE) {
	                mySortFilterMatchTablename = tableinfo.tablename();
	                mySortTableinfo = tableinfo;
	            }
		}
		
		 if (myFilterMatchTablename == null)
	            throw new Exception(myRes.getString("UICDRDocument_noFilterTableExc"));
		 
		  // continue with the rest of business...
        for (int i = 0; i < tables.length; i++) {
            UITableInfo tableinfo = tables[i];

            if (tableinfo.type() == UITableInfo.FILTERTABLE_TYPE||
                    tableinfo.type() == UITableInfo.SORTTABLE_TYPE||
            		tableinfo.type() == UITableInfo.MASSEDITTABLE_TYPE)
            	continue;

              BufferedDBTable dbtab = getBufferedDBTable(tableinfo);

            if (tableinfo.type() == UITableInfo.MAINTABLE_TYPE) {
                myMainDBTable = dbtab;
            }

            if (tableinfo.type() == UITableInfo.MAINTABLE_TYPE ||
                    tableinfo.type() == UITableInfo.SUBTABLE_TYPE) {
                tablesVector.add(dbtab);
            }

		} // end for (all tableinfos)

		if (myMainDBTablename == null)
			throw new Exception(myRes.getString("UICDRDocument_noMainTableExc"));

		myTables = getNewBufferedDBTable(tablesVector);
		myTables = convertTableVectorToArray(tablesVector);

	}


	protected BufferedDBTable[] convertTableVectorToArray(Vector tablesVector) {
		return (BufferedDBTable[]) tablesVector.toArray(myTables);
	}


	protected BufferedDBTable[] getNewBufferedDBTable(Vector tablesVector) {
		return new BufferedDBTable[tablesVector.size()];
	}


	private BufferedDBTable getBufferedDBTable(UITableInfo tableinfo)
			throws Exception {
		return new BufferedDBTable(gettransactionDBConnection(), this,
		          tableinfo,myFiltertableinfo, mySortTableinfo,myMainDBTablename,
		          myMainTableIndexColumnname, myMainTableModifyColumnname,
		          myDocumentInfo.getUniqueId(), myDocumentInfo.getStartRange(),
		          myDocumentInfo.getEndRange());
	}

	private UITableInfo[] getTableInfo() throws Exception {
		if(myTableInfo == null)
		{
		List<TableInfo> theTableList = new ArrayList<TableInfo>();
        List<CDRFieldInfo> theCDRFieldList = new ArrayList<CDRFieldInfo>();
         myServerSession.createCDRInfoAndTableInfo(myServerSession.asn1NameReceived.toString(), theTableList, theCDRFieldList);

         // Convert to GUI style TableInfo...

         UITableInfo[] convertedTabs = new UITableInfo[theTableList.size()];
         int i = 0;
         for (Iterator<TableInfo> iterator = theTableList.iterator(); iterator.hasNext();) {
                 TableInfo tableInfo = (TableInfo) iterator.next();
                 convertedTabs[i] = new UITableInfo(tableInfo);
                 i++;
         }
        myTableInfo= convertedTabs;
		}
		
        return  myTableInfo;

	}

	public BufferedDBTable[] getmyTables(){
		return myTables;
	}
	
	public CDRDocumentTableModel getDataAreaTableModel(
			UICDRFieldInfo selectedNode) {
		// CDRDocumentTableModel model = new
		// CDRDocumentTableModel(selectedNode);
		Debug.println("UICDRDocument.getDataAreaTableModel(), myReadOnly: "
				+ myReadOnly);
		CDRDocumentTableModel model = new CDRDocumentTableModel(selectedNode,
				myReadOnly);

		// mySelectedNodeDataModel.removeTableModelListener(this);
		// model.addTableModelListener(this);
		model.addTableModelListener(new TableModelListener() {
			public void tableChanged(TableModelEvent e) {
				if (myProgressObservable.action() != UIProgressObservable.DECODING_PROGRESS
						&& myProgressObservable.action() != UIProgressObservable.DECODING_FAILED
						&& myProgressObservable.action() != UIProgressObservable.ENCODING_FAILED
						&& myProgressObservable.action() != UIProgressObservable.DECODING_FINISHED
						&& myProgressObservable.action() != UIProgressObservable.RECOVERING_FINISHED) {
					myProgressObservable
							.setAction(UIProgressObservable.FILE_MODIFIED);
					myProgressObservable.setChanged();
					myProgressObservable.notifyObservers();
				}
			}
		});

		mySelectedNodeDataModel = model;
		mySelectedFields = selectedNode.getChilds();
		Debug.println("UICDRDocument.getDataAreaTableModel() over");
		return model;
	}

	public CDRDocumentTableModel getSelectedNodeDataModel() {
		return mySelectedNodeDataModel;
	}

	public CDRDocumentIndexTableModel getIndexAreaTableModel(
			UICDRFieldInfo selectedNode) {
		CDRDocumentIndexTableModel model = new CDRDocumentIndexTableModel(
				selectedNode);
		mySelectedNodeIndexModel = model;
		return model;
	}

	public Connection transactionAutoCommitDBConnection() {
		
				try {
					myAutoCommitConnection = getMyServerSession().autoDBConnection();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		return myAutoCommitConnection;
	}

	/**
	 * Returns a Vector with ints that contains the cdr numbers that match the
	 * selection criteria.
	 */
	public Vector findCdrs(UICDRFieldInfo field, int operator, String value) {
		Vector cdrNumbers = new Vector();
		UIColumnInfo column = field.dbColumn();
		Vector<SubTableIndex> cdrIndexlist = new Vector<SubTableIndex>();

		// save the column's current filter.
		Vector v = column.getFilters();

		try {
			UIColumnFilter filter = new UIColumnFilter(column, operator, value);

			filter.column().addFilter(filter);
			String fsql = myMainDBTable.createFilterSqlForColumn(column);
			if (myIsSorted
					&& column.field().dbTable().tableInfo().type() != TableInfo.SUBTABLE_TYPE) {
				// strip the distinct from the command
				// since order by does not work with distinct
				// just a patch, till we find a permanent solution
				// String distinctKeyWord = "distinct";
				// int index = fsql.indexOf(distinctKeyWord);
				// fsql = fsql.substring(0,index) +
				// fsql.substring(index+distinctKeyWord.length()+1,fsql.length());
				fsql += " " + myMainDBTable.myOrderBySQLPhrase;
			}
			else
			{
				fsql += " order by "  +  myMainDBTable.getKeyColumnName() ; 
			}
			Debug.println("FILTER SQL : [" + fsql + "]");
			filter.column().removeFilter(filter);

			Statement stmt = gettransactionDBConnection().createStatement();
			ResultSet rs = stmt.executeQuery(fsql);
			
			while (rs.next()) {
				int nr = rs.getInt(1);
				cdrNumbers.add(new Integer(nr));
							}

			rs.close();
			stmt.close();
		} catch (Exception e) {
			Debug.println("error when building filter: " + e);
		}

		column.setFilters(v);

		 return cdrNumbers;
	}

	
	public Vector findSubTableCdrs(UICDRFieldInfo field, int operator, String value) {
		Vector cdrNumbers = new Vector();
		UIColumnInfo column = field.dbColumn();
		Vector<SubTableIndex> cdrIndexlist = new Vector<SubTableIndex>();

		// save the column's current filter.
		Vector v = column.getFilters();

		try {
			UIColumnFilter filter = new UIColumnFilter(column, operator, value);

			filter.column().addFilter(filter);
			String fsql = myMainDBTable.createFilterSqlForColumn(column);
			if (myIsSorted
					&& column.field().dbTable().tableInfo().type() != TableInfo.SUBTABLE_TYPE) {
				// strip the distinct from the command
				// since order by does not work with distinct
				// just a patch, till we find a permanent solution
				// String distinctKeyWord = "distinct";
				// int index = fsql.indexOf(distinctKeyWord);
				// fsql = fsql.substring(0,index) +
				// fsql.substring(index+distinctKeyWord.length()+1,fsql.length());
				fsql += " " + myMainDBTable.myOrderBySQLPhrase;
			}
			/*else if (myIsSorted){
				fsql += " " + myMainDBTable.myOrderBySQLPhrase;
			}*/
			else
			{
				fsql += " order by "  +  myMainDBTable.getKeyColumnName() ; 
			}
			Debug.println("FILTER SQL : [" + fsql + "]");
			filter.column().removeFilter(filter);

			Statement stmt = gettransactionDBConnection().createStatement();
			ResultSet rs = stmt.executeQuery(fsql);
			
			while (rs.next()) {
				SubTableIndex sbi = new SubTableIndex();
				for (int i=1;i<=column.field().dbTable().indexColumns().length;i++)
				{
					int nr = rs.getInt(i);
					sbi.setSubTableIndex(nr);
				}
				cdrIndexlist.add(sbi);
			}

			rs.close();
			stmt.close();
		} catch (Exception e) {
			Debug.println("error when building filter: " + e);
		}

		column.setFilters(v);

		// return cdrNumbers;
		return cdrIndexlist;
	}

	public String getDocumentId() {
		return myDocumentInfo.getDocumentId();
	}

	/*public CDRDocument getCdrApiDocument() {
		return myAPICDRDocument;
	}*/

	public boolean isLoggingAllowed() {
		return myServerSession.enableAdvancedFeatures();
	}

	public void unsetDirtyFlag() {
		myIsTransactionDirty = false;
		myIsDocumentDirty = false;
	}

	public UICDRFieldInfo[] getSelectedFields() {
		return mySelectedFields;
	}

	public boolean getEncodingOrDecoding() {
		// System.out.println("get encoding or decoding: " +
		// String.valueOf(myIsEncodingOrDecoding));
		return myIsEncodingOrDecoding;
	}

	public void setEncodingOrDecoding(boolean encodingOrDecoding) {
		myIsEncodingOrDecoding = encodingOrDecoding;
	}

	// public void checkConnection() throws CDREditAPIException
	public void checkConnection() {
		try {
			synchronized (this) {
				if (this.isOpen()) {
					myProgressObservable
							.setAction(UIProgressObservable.CHECK_CONNECTION);
					myProgressObservable.setChanged();
					myProgressObservable.notifyObservers();
				}
			}
		} catch (Exception e) {
			if (Debug.DEBUGMODE)
				e.printStackTrace(Debug.debugStream);
		}

	}

	/*public void sendConnectionAliveMessage() throws CDREditAPIException {

		try {
			myAPICDRDocument.checkConnection();
		} catch (CDREditAPIException ex) {
			myConnectionAlive = false;
			throw ex;
		}
	}*/

	public boolean isConnectionAlive() {
      int timeout = 3; //3 sec
		try
		{
			if (!myTransactionConnection.isClosed())
			{
				Statement stm = myTransactionConnection.createStatement();
				stm.executeQuery( "SELECT 1" ).close();
				myConnectionAlive = true;
			}
		}
		catch(SQLException e)
		{
			myConnectionAlive = false;
		}
		
		return myConnectionAlive;
	}

	
	public boolean isConnectionAlive(DRViewerFileDBUniqueId drviewerUid) {

		try {
	if (!myTransactionConnection.isClosed()) {
		Statement stm = myTransactionConnection.createStatement();
		stm.executeQuery("SELECT 1").close();
		myConnectionAlive = true;
	}
} catch (SQLException e) {
	myConnectionAlive = false;
}

return myConnectionAlive;
}
	public boolean isBeingMassEdited() {
		return myIsBeingMassEdited;
	}

	public void setIsBeingMassEdited(boolean flag) {
		myIsBeingMassEdited = flag;
	}

	public void updateCDRModified(int[] cdrNo) throws Exception {
		myMainDBTable.updateCDRModified(cdrNo);
		setIsModified(null);
	}

	public void sortColumn(Vector selectedFields, Vector orderTypes) {
		try {
			activateSorting(selectedFields, orderTypes);
		} catch (Exception ex1) {
			
			// should never happen..
	        ex1.printStackTrace();
	        String theAppendMessage = " Unable to sort " +  this.getFilename() ;
			JOptionPane thePane = new JOptionPane(theAppendMessage, JOptionPane.INFORMATION_MESSAGE,JOptionPane.DEFAULT_OPTION);
			JDialog theMessageWindow = thePane.createDialog("Error");
			theMessageWindow.setModal(true);
			theMessageWindow.setVisible(true);
			if (Debug.DEBUGMODE)
				ex1.printStackTrace(Debug.debugStream);
			return;
		}

		try {
			

			for (int i = 0; i < myTables.length; i++) {
				// myTables[i].sortColumn(mySortedFields,orderTypes);
				myTables[i].sortColumn(selectedFields, orderTypes);
			}

			myIsSorted = true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void undoSort() {
		try {
			
			 Vector renderer = CDRRepairDesktop.getMyInstance().getHandleToMainPanel().getCellRenderer();
			    for (int i = 0; i < renderer.size(); i++) {
			      ( (BaseRenderer) renderer.elementAt(i)).resetEditedRowsVector();
			    }
			for (int i = 0; i < myTables.length; i++) {
				myTables[i].undoSort();
			}
			myIsSorted = false;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public boolean isSorted() {
		return myIsSorted;
	}

	public void setIsBeingClosed(boolean value) {
		isBeingClosed = value;
	}

	public boolean isBeingClosed() {
		return isBeingClosed;
	}

	private void resetMassEditTable() throws SQLException,Exception {
		Debug.println("********RESETTING THE MASS EDIT TABLE***************");
		Object[] args = { myMassEditMatchTablename };
		Statement stmt = gettransactionDBConnection().createStatement();
		String uniqueIDSql =  myRes.getString("UICDRDocument_uniqueID");
		// Statement stmt = myAutoCommitConnection.createStatement();
		// String sql = "delete from " + myMassEditMatchTablename;
		String sql = myRes.getString("UICDRDocument_MassEdit_ResetSql", args);
		sql = sql + " " + uniqueIDSql + myDocumentInfo.getUniqueId();		
		try {
			int numdeleted = stmt.executeUpdate(sql);
		} catch (SQLException ex) {
			myTransactionConnection.rollback();
			throw ex;
		} finally {
			stmt.close();
		}

	}

	public UICDRFieldInfo getFieldforColumnIndex(int index) {
		return getSelectedNodeDataModel().getField(index);
	}

	public boolean isBeingEncoded() {
		boolean isCurrentDocBeingEncoded = false;
		if (this.progressObservable() != null) {
			isCurrentDocBeingEncoded = ((UIProgressObservable) this
					.progressObservable()).action() == UIProgressObservable.ENCODING_PROGRESS;
		}

		return isCurrentDocBeingEncoded;
	}

	public void setColumnState(TableColumn column) {
		TableColumn tableColumn = column;
		String value = tableColumn.getHeaderValue().toString();

		// Debug.println("setcolumnState current doc is :"+document.documentInfo().filename());
		UICDRFieldInfo[] selectedFields = getSelectedFields();
		if (selectedFields == null)
			return;
		int indx = getFieldIndex(value, selectedFields);
		if (indx < 0)
			return;
		if (selectedFields[indx].isFieldVisible()) {
			tableColumn.setMinWidth(0);
			tableColumn.setWidth(75);
			tableColumn.setPreferredWidth(75);
		} else {
			tableColumn.setMinWidth(0);
			tableColumn.setWidth(0);
			tableColumn.setPreferredWidth(0);
		}
	}

	private int getFieldIndex(String fieldName, UICDRFieldInfo[] selectedFields) {
		for (int i = 0; i < selectedFields.length; i++) {
			if (fieldName.equals(selectedFields[i].dbColumn().field()
					.fieldName()))
				return i;
		}
		return -1;
	}

	public String getFilename() {
		if (documentInfo() != null ) {
		return documentInfo().filename();
		}
		return  "";
	}

	public String getFilepath() {
		return documentInfo().filepath();
	}

	public String getInternalFormatName() {
		return documentInfo().internalFormat().name();
	}

	public String getExtenalFormatName() {
		return documentInfo().externalFormat().name();
	}

	public UICDRFieldInfo[] getCDRFiledInfo() {
		return documentInfo().fields();
	}

	public CDRFormatInfo getInternalFormat() {
		return documentInfo().internalFormat();
	}

	public UICDRFieldInfo[] getModifyFields() {
		return documentInfo().modifyFields();
	}

	public String getOriginalFullFileName() {
		return documentInfo().originalFullFilename();
	}

	public UIDocumentFilterInfo[] getFilters() {
		return documentInfo().getFilters();
	}

	public FieldSelectionDetail getFieldSelectionDetail() {
		return m_fieldSelectionDetail;
	}

	public void setFieldSelectionDetail(
			FieldSelectionDetail fieldSelectionDetail) {
		m_fieldSelectionDetail = fieldSelectionDetail;
	}

	public String getFieldSelectionName() {
		return m_fieldSelectionName;
	}

	public void setFieldSelectionName(String name) {
		m_fieldSelectionName = name;
	}

	public int getHiddenFilteredCDRCount() {
		PreparedStatement mySelectHiddenFiltStatememt = null;
		int noOfHiddenFiltCDRs = 0;
		ResultSet rs = null;
		String selectSql = "select count(*) from " + myMainDBTablename + ", "
				+ myFilterMatchTablename + " where "
				+ myMainDBTable.getKeyColumnName() + " = "
				+ myFiltertableinfo.columns()[0] + " and NVL("
				+ myMainDBTable.getModifyColumnName() + ",0) = 0";
		// System.out.println("selectSql: " + selectSql);
		try {
			
			mySelectHiddenFiltStatememt = gettransactionDBConnection()
					.prepareStatement(selectSql);
			rs = mySelectHiddenFiltStatememt.executeQuery();
			while (rs.next()) {
				noOfHiddenFiltCDRs += rs.getInt(1);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (mySelectHiddenFiltStatememt != null)
					mySelectHiddenFiltStatememt.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
			}
		}
		return noOfHiddenFiltCDRs;
	}

	public void showModifiedOnly(int status, boolean refresh) throws Exception {
		myEditedRowsVec.removeAllElements();
		if (myIsDocModifiedAgain) {
			switch (status) {
			case BufferedDBTable.ALLCDRS:

				break;
			case BufferedDBTable.MODIFIEDONLY:
			case BufferedDBTable.UNMODIFIEDONLY:
				try {
					myIsDocModifiedAgain = false;
					Object[] args = { myMainDBTablename };
					String countSQL = myRes.getString(
							"UICDRDocument_countUnModCDRs_statement", args);
					if (myCountUnmodifiedStatement == null) {
						myCountUnmodifiedStatement =gettransactionDBConnection()
								.prepareStatement(countSQL);
					}
					Debug.println("query fired in showModifiedOnly");
					ResultSet rs = myCountUnmodifiedStatement.executeQuery();
					if (rs.next()) {
						myModifiedCount = rs.getInt(1);
					}
					rs.close();
				} catch (SQLException e) {
					myIsDocModifiedAgain = true;
					CDREExceptionDialog dlg = new CDREExceptionDialog(
							myRes.getString("UICDRDocument_visibletable_error"),
							e);
					dlg.showModal();
					try {
						myCountUnmodifiedStatement.close();
					} catch (SQLException exc) {
					} finally {
						myCountUnmodifiedStatement = null;
					}
				}
				break;
			}
		}
		if (refresh) {
			refreshShowModified(status);
		}
		setVisibleAction(UIConfig.docVisibleStatus);
		myVisibleUnmodifiedCDRS = myModifiedCount;
		myProgressObservable.setAction(UIProgressObservable.VISIBLE_ACTION);
		myProgressObservable.setChanged();
		myProgressObservable.notifyObservers();
		if (!this.isBeingEncoded()) {
			setShowModifiedCalled(true);
		} else {
			setShowModifiedCalled(false);
		}
	}

	public void setShowModifiedCalled(boolean showModifiedCalled) {
		myIsShowModifiedCalled = showModifiedCalled;
	}

	public boolean isShowModifiedCalled() {
		return myIsShowModifiedCalled;
	}

	public void refreshShowModified(int status) {
		try {
			for (int i = 0; i < myTables.length; i++) {
				BufferedDBTable currentTable = myTables[i];
				currentTable.setVisibleStatus(status);
			}
			refreshAll();
		} catch (Exception e) {
			//e.printStackTrace();
			CDREExceptionDialog dlg = new CDREExceptionDialog("Unable to refresh view." + "\n" + "Check connection with the database and re-open file", e);
			dlg.showModal();
		}
	}

	public int getMyVisibleUnmodifiedCDRS() {
		return myVisibleUnmodifiedCDRS;
	}

	public int getMyLastVisibleAction() {
		return myLastVisibleAction;
	}

	public void setVisibleAction(int visibleAction) {
		myLastVisibleAction = visibleAction;
	}

	/**
	 * Returns the position of the value in the ArrayList.
	 * 
	 * @param aArrayList
	 *            The hashset where aValue is placed.
	 * @param aValue
	 *            The value whose position has to be determined.
	 * @return The position of aValue in the ArrayList.
	 */
	private int getPositionInArrayList(ArrayList aArrayList, String aValue) {
		Iterator theIterator = aArrayList.iterator();
		for (int k = 0; k < aArrayList.size(); k++) {
			String theFilter = theIterator.next().toString();
			if (aValue.equals(theFilter)) {
				return k;
			}
		}
		return -1;
	}

	public void populatePerFilterTable(final TableModel aTableModel,
			ArrayList aFilters, int aColNum) throws Exception {
		final UIDocumentFilterInfo[] theDocFiltInfo = getFilters();
		final int thePosition[] = new int[theDocFiltInfo.length];
		// If only single condition is applied, the count can be
		// fetched directly from UICDRDocument object.
		if (theDocFiltInfo.length == 1) {
			thePosition[0] = getPositionInArrayList(aFilters,
					theDocFiltInfo[0].toString());
			aTableModel.setValueAt(new Integer(filteredCDRCount()),
					thePosition[0], aColNum + 1);
		} else {
			for (int j = 0; j < theDocFiltInfo.length; j++) {
				thePosition[j] = getPositionInArrayList(aFilters,
						theDocFiltInfo[j].toString());
				aTableModel.setValueAt(
						((PerFilterTableModel) aTableModel).m_FetchingString,
						thePosition[j], aColNum + 1);
				final int theRowNum = j;
				final int theColNum = aColNum;
				final Runnable theWorker = new Runnable() {
					public void run() {
						try {
							executeQueryNPopulatePerFilterTable(
									thePosition[theRowNum], theRowNum,
									theColNum, theDocFiltInfo, aTableModel);
						} catch (Throwable ex) {
							aTableModel
									.setValueAt(
											((PerFilterTableModel) aTableModel).m_errorString,
											thePosition[theRowNum],
											theColNum + 1);
							String excStr = myRes
									.getString("UICDRDocumentSet_PerFilterDialog_ErrorApplyingFilter")
									+ getFilename();
							((PerFilterTableModel) aTableModel).setErrorMsg(
									thePosition[theRowNum], excStr, ex);
						}
						return;
					}
				};
				new Thread(theWorker).start();
			}
		}

		// Put "-" in all the blank fields to show that the particular filter
		// is not applied on particular document.
		for (int i = 1; i < aTableModel.getColumnCount(); i++) {
			for (int j = 0; j < aTableModel.getRowCount(); j++) {
				if (aTableModel.getValueAt(j, i) == null) {
					aTableModel
							.setValueAt(
									myRes.getString("UICDRDocument_PerFilter_BlankCellString"),
									j, i);
				}
			}
		}
	}

	private void executeQueryNPopulatePerFilterTable(int thePosition,
			int aRowNum, int aColNum, UIDocumentFilterInfo[] aDocFiltInfo,
			TableModel aTableModel) throws Exception {
		String theFilterQuery = "";
		ResultSet theResultSet;
		PreparedStatement theFilterPreparedStatement = null;
		theFilterQuery = generateFilterCountSQLForACondition(aDocFiltInfo[aRowNum]
				.getCondition());
		try {
			theFilterPreparedStatement = gettransactionDBConnection()
					.prepareStatement(theFilterQuery);
			theResultSet = theFilterPreparedStatement.executeQuery();
			theResultSet.next();
			int theFilterCount = theResultSet.getInt(1);
			aTableModel.setValueAt(new Integer(theFilterCount), thePosition,
					aColNum + 1);
		} finally {
			if (theFilterPreparedStatement != null) {
				theFilterPreparedStatement.close();
			}
		}
	}

	public void populateSumDialog(UICDRFieldInfo[] aSelectedFields,
			TableModel aTableModel, boolean shouldApplyToWholeDoc)
			throws Exception {
		myProgressObservable
				.setAction(UIProgressObservable.FILTERRESULTS_SUM_STARTED);
		myProgressObservable.setChanged();
		myProgressObservable.notifyObservers();
		myProgressObservable
				.setAction(UIProgressObservable.FILTERRESULTS_SUM_PROGRESS);

		PreparedStatement thePreparedStatement = null;
		ResultSet theResultSet = null;
		StringBuffer theQuery = new StringBuffer();
		try {
			for (int i = 0; i < aSelectedFields.length; i++) {
				theQuery = new StringBuffer("select sum(");
				theQuery.append(aSelectedFields[i].dbColumn().name());
				theQuery.append(") ");
				String theFilterSelectQuery = createSelectFilterPhrase(false);
				;
				int theIndexOfFrom = theFilterSelectQuery.toUpperCase()
						.indexOf("FROM ");
				String theTabSelClause = theFilterSelectQuery
						.substring(theIndexOfFrom);
				int theIndexOfCondToBeRemoved = -1;
				// As createSelectFilterPhrase also appends "AND" or "WHERE" in
				// the query,
				// it should be removed where it is not required.
				int theLastIndexOfAnd = theTabSelClause.lastIndexOf("AND ");
				if (theLastIndexOfAnd == -1) {
					theIndexOfCondToBeRemoved = theTabSelClause
							.indexOf("WHERE ");
				} else {
					theIndexOfCondToBeRemoved = theLastIndexOfAnd;
				}
				theQuery.append(theTabSelClause.substring(0,
						theIndexOfCondToBeRemoved));

				if (isFiltersActive() && !shouldApplyToWholeDoc) {
					if (theQuery.indexOf(" WHERE ") == -1) {
						theQuery.append(" WHERE ");
					} else {
						theQuery.append(" AND ");
					}
					theQuery.append(myMainDBTable.getKeyColumnName());
					theQuery.append(" IN (");
					String theFilterQuery = generateFilterSQL();
					// int theIndexOfFromInFiltQry =
					// theFilterQuery.toUpperCase().indexOf("FROM");
					// String theWhereClause =
					// theFilterQuery.substring(theIndexOfFromInFiltQry);
					// theQuery.append(" ");
					theQuery.append(theFilterQuery);
					theQuery.append(")");
				}
				Debug.println("Filter Results - Sum Query: ");
				Debug.println(theQuery);
				thePreparedStatement = gettransactionDBConnection()
						.prepareStatement(theQuery.toString());

				theResultSet = thePreparedStatement.executeQuery();

				theResultSet.next();

				aTableModel.setValueAt(aSelectedFields[i].fieldName(), i, 0);
				aTableModel.setValueAt(new Long(theResultSet.getLong(1)), i, 1);
			}
		} finally {
			myProgressObservable
					.setAction(UIProgressObservable.FILTERRESULTS_SUM_FINISHED);
			myProgressObservable.setChanged();
			myProgressObservable.notifyObservers();
			if (thePreparedStatement != null) {
				try {
					thePreparedStatement.close();
				} catch (Exception e) {
				}
			}
		}
	}

	public Vector populateCountFilterResultsFrame(
			UICDRFieldInfo[] aSelectedFields, boolean shouldApplyToWholeDoc)
			throws Exception {
		myProgressObservable
				.setAction(UIProgressObservable.FILTERRESULTS_COUNT_STARTED);
		myProgressObservable.setChanged();
		myProgressObservable.notifyObservers();
		myProgressObservable
				.setAction(UIProgressObservable.FILTERRESULTS_COUNT_PROGRESS);
		PreparedStatement thePreparedStatement = null;
		ResultSet myResultSet = null;
		StringBuffer mySQLString = null;
		// Number of rows fetched
		Vector theRowsVec = new Vector();

		// Build a query to get the count and percentage of each unique value.
		mySQLString = new StringBuffer("select ");
		StringBuffer theFieldsString = new StringBuffer();
		for (int i = 0; i < aSelectedFields.length; i++) {
			UIColumnInfo theUICI = aSelectedFields[i].dbColumn();
			theFieldsString.append(theUICI.name().trim());
			if (i < (aSelectedFields.length - 1)) {
				theFieldsString.append(", ");
			}
		}
		mySQLString.append(theFieldsString);
		mySQLString.append(", a COUNT, a*100/b PERCENT from (select ");
		mySQLString.append(theFieldsString);
		mySQLString.append(", count(*) a, (select count(*) ");

		String theFilterSelectQuery = createSelectFilterPhrase(false);
		;
		int theIndexOfFrom = theFilterSelectQuery.toUpperCase()
				.indexOf("FROM ");
		String theTabSelClause = theFilterSelectQuery.substring(theIndexOfFrom);
		int theIndexOfCondToBeRemoved = -1;
		// As createSelectFilterPhrase also appends "AND" or "WHERE" in the
		// query,
		// it should be removed where it is not required.
		int theLastIndexOfAnd = theTabSelClause.lastIndexOf("AND ");
		if (theLastIndexOfAnd == -1) {
			theIndexOfCondToBeRemoved = theTabSelClause.indexOf("WHERE ");
		} else {
			theIndexOfCondToBeRemoved = theLastIndexOfAnd;
		}
		mySQLString.append(theTabSelClause.substring(0,
				theIndexOfCondToBeRemoved));
		mySQLString.append(") b ");
		mySQLString.append(theTabSelClause);
		if (isFiltersActive() && !shouldApplyToWholeDoc) {
			mySQLString.append(myMainDBTable.getKeyColumnName());
			mySQLString.append(" IN (");
			String theFilterQuery = generateFilterSQL();
			mySQLString.append(theFilterQuery);
			mySQLString.append(")");
		} else {
			int theLastIndexOfCond = mySQLString.lastIndexOf("AND ");
			if (theLastIndexOfCond == -1) {
				theLastIndexOfCond = mySQLString.indexOf("WHERE ");
			}
			mySQLString.delete(theLastIndexOfCond, (mySQLString.length() - 1));
		}
		mySQLString.append(" group by ");
		mySQLString.append(theFieldsString);
		mySQLString.append(")");
		try {
			Debug.println("Count Filter Results Query: ");
			Debug.println(mySQLString);
			thePreparedStatement = gettransactionDBConnection()
					.prepareStatement(mySQLString.toString());
			myResultSet = thePreparedStatement.executeQuery();
			// Count of the CDRs for the specific value.
			int theCountCount = 0;
			// Percentage of the CDRs for the specific value.
			double theFetchedPercent = 0;
			Object[] theTempObjArr = null;
			String ASNStringTypeIndicator = new String(
					ASN_StringType.ABSENT_BYTEARR);
			// Total number of CDRs.
			while (myResultSet.next()) {
				theTempObjArr = new Object[aSelectedFields.length + 2];
				for (int i = 0; i < aSelectedFields.length; i++) {
					String theValue = myResultSet.getString(i + 1);
					// If the column is of int or enum type, it should be shown
					// as number column.
					if ((aSelectedFields[i].typeId() == UICDRFieldInfo.DSET_TYPE)
							&& ((aSelectedFields[i].subTypeId() == ASN_Types.AD_INT || aSelectedFields[i]
									.subTypeId() == ASN_Types.AD_ENUM /*
																	 * ||
																	 * aSelectedFields
																	 * [
																	 * i].subTypeId
																	 * () ==
																	 * ASN_Types
																	 * .
																	 * AD_NUMERIC_STR
																	 */))) {
						if (theValue != null && theValue.length() > 0) {
							theTempObjArr[i] = new Integer(theValue);
						} else {
							theTempObjArr[i] = theValue;
						}
					}
					// If the column is of HEX type, the value should be
					// converted
					// to HEX.
					else if ((aSelectedFields[i].typeId() == UICDRFieldInfo.DSET_TYPE)
							&& (aSelectedFields[i].subTypeId() == ASN_Types.AD_GENERAL_STR
									|| aSelectedFields[i].subTypeId() == ASN_Types.AD_BIT_STR || aSelectedFields[i]
									.subTypeId() == ASN_Types.AD_OCTET_STR)) {
						if (theValue != null && theValue.length() > 0) {
							if (theValue.equals(ASNStringTypeIndicator)) // if
																			// field
																			// is
																			// optional
							{
								theTempObjArr[i] = UIColumnFilter.VALUE_ABSENT;
							} else {
								String theHexString = ByteDataConv
										.toHexString(theValue.substring(1));
								theTempObjArr[i] = theHexString;
							}
						} else {
							theTempObjArr[i] = theValue;
						}
					} else {
						if (theValue != null && theValue.length() > 0) {
							if (theValue.equals(ASNStringTypeIndicator)) // if
																			// field
																			// is
																			// optional
							{
								theTempObjArr[i] = UIColumnFilter.VALUE_ABSENT;
							} else {
								theTempObjArr[i] = theValue.substring(1);
							}
						} else {
							theTempObjArr[i] = theValue;
						}
					}
				}
				theFetchedPercent = myResultSet.getDouble("PERCENT");
				theCountCount = myResultSet.getInt("COUNT");
				theTempObjArr[aSelectedFields.length] = new Integer(
						theCountCount);
				theTempObjArr[aSelectedFields.length + 1] = new Double(
						theFetchedPercent);
				theRowsVec.addElement(theTempObjArr);
			}
		} finally {
			if (thePreparedStatement != null) {
				try {
					thePreparedStatement.close();
				} catch (Exception ex) {
				}
			}
		}
		return theRowsVec;
	}

	class TableUpdates {
		private Vector subTableUpdates = new Vector();
		private Vector normalTableUpdates = new Vector();

		public Vector getSubTableUpdates() {
			return subTableUpdates;
		}

		public Vector getNormalTableUpdates() {
			return normalTableUpdates;
		}

		public void addNormalTableUpdate(UIMassEditUpdate update) {
			normalTableUpdates.addElement(update);
		}

		public void addSubTableUpdate(UIMassEditUpdate update) {
			subTableUpdates.addElement(update);
		}

	}
   /* public void updateFilterList(UIFilterInfoList myFilterList)
    {
        Vector v = new Vector();
        for (int i = 0; i < myFilterList.getRowCount(); i++) {
            UIDocumentFilterInfo filter= myFilterList.filterInfoAt(i);
            v.add(filter);
        }
      this.documentInfo().updateFilters(v);
    }*/

	public void setTmpClicked(int pick) {
		// TODO Auto-generated method stub
		tmpClickedColumn=pick;
	}
	
	public int getTmpClicked() {
		// TODO Auto-generated method stub
        return tmpClickedColumn;
	}


	public String[] getCollectorAndASNNameForFileByUniqueId(int uniqueId) {
		ResultSet rs = null;
		String[] resultArray= new String[2];
		String selectQuery = myRes.getString(getCollectorIdAndAsnNameForSaveForwardLogQuery());
		String collectorId="";
		String asnName="";
		try {
			getCollectorIdFromUniqeIdTable = myServerSession.autoDBConnection()
					.prepareStatement(selectQuery);
			getCollectorIdFromUniqeIdTable.setInt(1,uniqueId);
			rs=getCollectorIdFromUniqeIdTable.executeQuery();
			
			
			if(rs.next()){
				collectorId = rs.getString(1);
				asnName=rs.getString(2);
			}
		} catch (Exception ex) {
			(new CDREExceptionDialog("Error in saving collectorId to logs ", ex))
					.showModal(); // To be changed...
		} finally {
			try {
				rs.close();
			} catch (Exception e) {
			}
		}
		resultArray[0]=collectorId;
		resultArray[1]=asnName;
		return resultArray;
	}



	protected String getCollectorIdAndAsnNameForSaveForwardLogQuery() {
		return "GetCollectorIdAndASNNameForSaveAndForwardLog";
	}


	public int getErrorCdrNum() {
		return errorCdrNum;
	}


	public void setErrorCdrNum(int errorCdrNum) {
		this.errorCdrNum = errorCdrNum;
	}
}
