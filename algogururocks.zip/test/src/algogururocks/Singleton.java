/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algogururocks;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alok
 */

public class Singleton {

    private static Singleton ref;
    

    static {
    }
    String str;

    private Singleton(String str) {
        this.str = str;
        System.out.println(str);
    }

    public static void main(String[] args) {
        (new Thread("b ") {

            public void run() {
                synchronized (this) {
                    if (ref == null) {
                        yield();
                        try {
                            this.wait(100);
                        } catch (InterruptedException ex) {
                            Logger.getLogger(Singleton.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        if (ref == null) {
                            ref = new Singleton("hi b");
                        }
                    }
                }
            }
        }).start();

        (new Thread("a ") {

            public void run() {
                synchronized (this) {
                    if (ref == null) {
                        System.out.println("i love u reshmi");
                        yield();
                        if (ref == null) {
                            ref = new Singleton("hi a");
                        }
                        this.notifyAll();
                    }
                }
            }
        }).start();
        System.out.println("bye");
    }
}


//~ Formatted by Jindent --- http://www.jindent.com
