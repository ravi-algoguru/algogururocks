package algogururocks;


public class SynchronizationTest extends Thread {

	/**
	 * @param args
	 */
	
	static Object lock1=new Object();
	static Object lock2=new Object();
	
	static volatile int i1,i2,j1,j2,k1,k2;
	
	SynchronizationTest(String name)
	{
		Thread.currentThread().setName(name);
	}
	public void run()
	{
		while (true)
		{
			doIt();
			check();
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	void doIt()
	{
		synchronized(lock1)
		{
			i1++;
			System.out.println(Thread.currentThread().getName() + " : lock1  "+ i1);
		}
		j1++;
		System.out.println(Thread.currentThread().getName() + " : j1  "+ j1);
		synchronized(lock2)
		{
			k1++;k2++;
			System.out.println(Thread.currentThread().getName() + " : lock2"+ k1+ " "+k2);
		}
		synchronized(lock1)
		{
			i2++;
			System.out.println(Thread.currentThread().getName() + " : lock1");
		}
		j2++;
		System.out.println(Thread.currentThread().getName() + " : j2  "+ j2);
	}
	
	
	void check()
	{
		if(i1!=i2)
			  System.out.println("i");
		if(j1!=j2)
			System.out.println("j");
		if(k1!=k2)
			System.out.println("k");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new SynchronizationTest("A").start();
		new SynchronizationTest("B").start();
        
	}

}
