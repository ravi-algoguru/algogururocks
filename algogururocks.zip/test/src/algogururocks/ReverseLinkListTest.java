package algogururocks;

public class ReverseLinkListTest {

    /**
     * @param args
     */
    static Node root;
    static Node previous;
    public static void insert(int data){
        insert(root,data);
    }
    private static void insert(Node node,int data){
        if(node==null){
            node=new Node(data);
            return;
        }
        insert(node.next,data);
        
    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub
//        int i=0;
//                while(i<10){
//                    insert((int)Math.random());
//                    i++;
//                }
//        display(root);
        Node node1 = new Node();
        Node node2 = new Node();
        Node node3 = new Node();
        Node node4 = new Node();
        Node node5 = new Node();

        root = node1;
        node1.data = 1;
        node1.next = node2;

        node2.data = 2;
        node2.next = node3;

        node3.data = 3;
        node3.next = node4;

        node4.data = 4;
        node4.next = node5;

        node5.data = 5;
        node5.next = null;

         display(root);

        Node n2 = new Node();
        Node n3 = new Node();
        Node n4 = new Node();
        n2.data = 3;
        n3.data = 5;
        n4.data = 6;
        n2.next = n3;
        n3.next = n4;
        n4.next = null;

        Node start = null;
        
        start = (merge(node1, n2));
        start = reverse2(start);
        display(start);
    }

    public static void display(Node node) {
        if (node == null) {
            return;
        }
        while (node != null) {
            System.out.println(node.data);
            node = node.next;
        }

        System.out.println();

    }

    public static class Node {

        int data;
        Node next;
        Node(){
            
        }
        Node(int data){
            this.data=data;
            next=null;
        }
    }

    public static Node reverse(Node parent) {
        return reverse(parent, null);
    }

    public static Node reverse1(Node parent) {
        Node nextParent = null;
        if (parent == null) {
            return null;
        }
        if (parent.next == null) {
            root = parent;
            return root;
        }

        previous = parent;
        nextParent = parent.next;
        parent.next = previous;
        return reverse1(nextParent);
    }

    private static Node reverse2(Node node) {
        if (node == null) {
            return null;
        }
        if (node.next == null) {
            return node;
        }
        Node temp = reverse2(node.next);
        if (node.next.next == null) {
            node.next.next = node;
            node.next = null;
        }
        return temp;
    }

    private static Node reverse(Node parent, Node previus) {

        if (parent == null) {
            return null;
        }
        if (parent.next == null) {
            parent.next = previus;
            return parent;
        }
        Node nextParent = parent.next;
        Node nextPrevius = parent;
        parent.next = previus;
        return reverse(nextParent, nextPrevius);

    }

    private static void reverseLink(Node node) {
        if (node == null) {
            return;
        }
        if (node.next == null) {
            root = node;
            System.out.print(node.data + " ");
            return;
        }
        reverseLink(node.next);
        if (node.next.next == null) {
            node.next.next = node;
            node.next = null;
        }
    }

    public static Node merge(Node n1, Node n2) {
        if (n1 == null && n2 == null) {
            return null;
        }
        if (n1 == null) {
            return n2;
        }
        if (n2 == null) {
            return n1;
        }
        Node res = new Node();
        Node start = res;
        merge(n1, n2, res);
        //display(start);
        return start;
    }

    private static Node merge(Node n1, Node n2, Node res) {
        if (n1 == null && n2 == null) {
            return res;
        }
        if (n1.data < n2.data) {
            res.data = n1.data;
            n1 = n1.next;
        } else {
            res.data = n2.data;
            n2 = n2.next;
        }
        if (n1 != null && n2 != null) {
            res.next = new Node();
            res = res.next;
            return merge(n1, n2, res);
        }
        if (n1 == null && n2 != null) {
            while (n2 != null) {
                res.next = new Node();
                res = res.next;
                res.data = n2.data;
                n2 = n2.next;
            }
        }
        if (n2 == null && n1 != null) {
            while (n1 != null) {
                res.next = new Node();
                res = res.next;
                res.data = n1.data;
                n1 = n1.next;
            }
        }
        return res;
    }
}
