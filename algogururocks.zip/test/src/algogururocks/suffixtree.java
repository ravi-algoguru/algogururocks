package algogururocks;


public class suffixtree
{

	/* Internal classes */

	/**
	 * Generic tree node.  Parent class of LeafNode and InternalNode.
	 */
	class Node { // Generic tree node
	}

	/**
	 * Leaf node.  Holds a suffix ID (where the suffix begins in the string).
	 * For this implementation, a suffix can appear multiple times in the
	 * same tree; this is because $ is treated as a separator/terminator.
	 * The more field allows a linked list of leaf nodes.  Using this,
	 * multiple suffixes can be stored at one "leaf".
	 */
	class LeafNode extends Node { // Leaf node
		int beginIndex; // ID for the suffix that ends here
		LeafNode more; // More than one suffix can end here
	}

	/**
	 * Internal node.  Each internal node has up to 27 children, one for
	 * each letter and one for the separator ($).  Letters are stored in
	 * locations 1 through 26 and the separator corresponds to location 0.
	 */
	class InternalNode extends Node { // Internal (nonleaf) node
		Edge[] child = new Edge[27]; // Child for each letter + separator
	}

	/**
	 * Tree edge.  Each edge corresponds to a substring of the original string.
	 * The beginIndex and endIndex define this substring.  The node is the
	 * node (either LeafNode or InternalNode) that this edge goes to.  The
	 * inclusive/exclusive rules used on the indices are chosen to match
	 * the arguments to String.substring().
	 */
	class Edge { // Tree edge (labeled with a substring)
		int beginIndex; // Beginning index, inclusive
		int endIndex; // Ending index, exclusive
		Node node; // Child node
	}


	/* Fields */

	/**
	 * The Suffix Tree.
	 * The root is the root of the entire suffix tree.
	 * The string is the original string (after converting to lower case
	 * and appending of a $ if necessary).  Indices stored within the suffix
	 * tree refer to locations within the string.
	 */
	InternalNode root = null; // Root of the SuffixTree
	String string; // String that is held in SuffixTree


	/**
	 * Current location within the suffix tree.
	 * Several methods need to find a location within the suffix tree.
	 * We can be at either a node or an edge. If we're at an edge, we need
	 * to know where we are within the edge; this is represented by keeping
	 * track of where we are within the original string
	 */
	boolean isNode; // True iff located at a node
	Node node; // Current node
	Edge edge; // Current edge
	int where; // Position within original string

	/**
	 * Some methods require us to accumulate a list of string positions.
	 * It helps to have a place to store these as they're accumulated.
	 * The field holder[] is used for this purpose.  To ensure that it's
	 * big enough to hold all possible positions, we create it (in the
	 * suffix tree constructor) to be as large as the set of all possible
	 * string positions.  In other words, it needs to be the same length
	 * as the original string.
	 */
	int[] holder;
	int count = 0; // Number of items in holder


	/* Static Helper Methods */

	/**
	 * Convert a String into all lowercase and ensure that only letters
	 * and the separator ($) appear in the String.  Add a final separator
	 * if necessary.
	 * @param string string to be converted
	 * @return a converted version of the string
	 * @exception IllegalArgumentException if a nonletter appears in String
	 */
	public static String convert (String string) {
		string = string.toLowerCase();

//		Check for illegal characters.
		for (int i = 0; i < string.length(); i++) {
			char c = string.charAt(i);
			if (c != '$' && (c < 'a' || c > 'z'))
				throw new IllegalArgumentException("Illegal character: " + c);
		}
//		Append $ if necessary.
		if (string.charAt(string.length()-1) != '$') string = string + '$';
		return string;
	}

	/**
	 * Determine the index that corresponds to the character at the given
	 * position in the String.  $ is 0 and a through z map to 1 through 26.
	 * The expression is used to 'normalise' the indices in this way.
	 * @param string
	 * @param position
	 * @return the index (0..26) of the character at given position in string
	 */
	static int index (String string, int position) {
		char c = string.charAt(position);
		return (c == '$')? 0 : c-'a'+1;
	}



	/**
	 * Constructor; create a SuffixTree.
	 * The input string should consist only of letters and the separator ($).
	 * If the original string does not end with '$' then '$' is appended.
	 */
	public suffixtree (String inputString) {
		string = convert(inputString);
		holder = new int[string.length()]; // Big enough to hold all IDs

//		Build the suffix tree.
//		This version is not efficient; there is a linear time algorithm.
		root = new InternalNode();
		for (int id = 0; id < string.length(); id++) {

//			Determine how much of this substring is already represented
//			in the suffix tree.  Location is the first unrepresented
//			character.  Note that locate updates the information
//			for the current-tree-location.
			int location = id + locate(string.substring(id));

//			If we're at an edge, we break the edge and create a new node.
			if (!isNode) {
				Edge newEdge = new Edge();
				InternalNode newNode = new InternalNode();
				newEdge.beginIndex = edge.beginIndex + (location-id);
				newEdge.endIndex = edge.endIndex;
				newEdge.node = edge.node;
				edge.endIndex = newEdge.beginIndex;
				edge.node = newNode;
				newNode.child[index(string,newEdge.beginIndex)] = newEdge;

//				We now fall through to the node case.
				isNode = true;
				node = newNode;
			}

//			If we're at a leaf node, we have a duplicate suffix.
			if (node instanceof LeafNode) {
				LeafNode leaf = new LeafNode();
				leaf.beginIndex = id;
				leaf.more = (LeafNode)node; // A linked list of suffix IDs
				edge.node = leaf;
				continue;
			}

//			Otherwise, we have to add the new leaf (up to the $).
			edge = new Edge();
			edge.beginIndex = location;
			edge.endIndex = 1 + string.indexOf("$",location);
			edge.node = new LeafNode();
			((LeafNode)(edge.node)).beginIndex = id;
			((InternalNode)node).child[index(string,location)] = edge;
		}
	}

	/**
	 * Report all the suffixes that are stored below the given node.
	 * A suffix is specified by its starting index in the original string.
	 * The results are held in the holder array.
	 * @param empty the index of the next empty position in holder array
	 * @param node the subtree
	 */
	private void reportAll (Node node) {

//		If it's a leaf node...
		if (node instanceof LeafNode) {
			LeafNode leaf = (LeafNode) node;
			holder[count++] = leaf.beginIndex; // Report the suffix
			while (leaf.more != null) { // While more leaf nodes...
				leaf = leaf.more;
				holder[count++] = leaf.beginIndex; // Report theirs, too
			}
			return;
		}
//		If it's an internal node...
		InternalNode iNode = (InternalNode) node;
		for (int i = 0; i < iNode.child.length; i++) {
			if (iNode.child[i] == null) continue; // Skip unused edges

//			Recursively report suffixes for child nodes.
			reportAll(iNode.child[i].node);
		}
		return;
	}

	/**
	 * Locate the query string within this SuffixTree.  Makes use of
	 * the current-tree-location fields that are part of this class.
	 * It may not be possible to use the entire query string; the position
	 * of the first unused character in the query string is returned.
	 * @param query the query string
	 * @return position of the first unused character in the query string
	 */
	private int locate (String query) {

//		We are currently located at the root.
		isNode = true;
		node = root;

//		We loop through the query string, marching through the tree as we go.
		for (int position = 0; position < query.length(); position++) {

//			If we're at a leaf node then we've failed to match entire query.
			if (isNode && (node instanceof LeafNode)) return position;

//			If we're at a nonleaf node, we advance to an edge.
			if (isNode) {
				edge = ((InternalNode)node).child[index(query,position)];

//				If there is no appropriate edge then we've failed to match
//				entire query.
				if (edge == null) return position;

//				We are now located within an edge in the tree and we drop
//				through to the edge case.
				where = edge.beginIndex;
				isNode = false;
			}

//			If we're at an edge and the characters match...
			if (query.charAt(position) == string.charAt(where)) {
				System.out.println(query.charAt(position) + " at " + position + " = " + string.charAt(where) + " at " + where) ;
//				Increment location and check if we've fallen off the edge
				where = where + 1;
				if (where == edge.endIndex) {

//					We've fallen off the edge; move on to the node.
					isNode = true;
					node = edge.node;
				}
			}
//			But if the characters don't match...
			else {
//				We've failed to match entire query.
				return position;
			}
		}

//		If we get here then we've used up the entire query string.
		return query.length();
	}

	/**
	 * Find all occurrences of a query string.
	 * @param query the query string
	 * @return an array of integer indices showing all the places in
	 *  the original string where the query string starts; note that
	 *  the size of the array matches the number of occurrences
	 */
	public int[] findAll (String query) {
		return findAll(query,false);
	}

	/**
	 * Find all occurrences of the query string.
	 * This internal version allows partial matches, but only if
	 * partialOK is true.
	 * @param query the query string
	 * @param partialOK true iff partial (prefix) match is allowed
	 * @return an array of integer indices showing all the places in
	 *  the original string where the query string starts
	 */
	private int[] findAll (String query, boolean partialOK) {

//		Find the query in the suffix tree.
		int position = locate(query);

//		If we didn't find all of it and partial match is not OK,
//		return an array of length 0.
		if (!partialOK && position < query.length()) return new int[0];

//		Find the node at or below the current location in the suffix tree.
		if (!isNode) node = edge.node;

//		Otherwise, find all the suffix IDs and copy them into an array.
		count = 0; // Reset counter
		reportAll(node); // Find all suffixes in subtree
		int[] result = new int[count]; // Space for answer
		System.arraycopy(holder,0,result,0,count);
		return result; // Return answer
	}

	/**
	 * Locate the longest prefix of the given query string that appears as a
	 * suffix in the SuffixTree.
	 * @param query the query string
	 * @return an array of integer indices showing all the places in
	 *  the original string where the longest prefix starts
	 */
	public int[] longestPrefix (String query) {
		return findAll(query,true);
	}

	/* Other Methods */

	/**
	 * Shows all suffixes stored in the tree in sorted (alphabetical) order.
	 * If the SuffixTree is built correctly this is easy to do recursively.
	 * @return a String representation of the SuffixTree.
	 */
	public String toString () {
//		Note: "\n" is treated as end-of-line when used within a String.
		return "SuffixTree for " + string + ":" + toString("\n ",root);
	}

	/**
	 * Shows all Strings stored in the give subtree.  Each string has
	 * prefix placed in front of it.  This implementation is not
	 * particularly efficient; it does a lot of String recopying.
	 * @param prefix a prefix string
	 * @param node the subtree
	 * @return a String representation of the subtree
	 */
	private String toString(String prefix, InternalNode node) {
		StringBuffer buf = new StringBuffer();

//		Create strings for each edge leaving this node.
		for (int i = 0; i < node.child.length; i++) {
			Edge e = node.child[i];
			if (e == null) continue; // Skip unused edges

//			String for this edge; include '.' as node marker.
			String edgeString = "." + string.substring(e.beginIndex,e.endIndex);

//			If we are at a leaf node, we create the string.
			if (e.node instanceof LeafNode) {
				LeafNode leaf = (LeafNode)e.node;

//				Include the edge string and the ID of corresponding suffix.
				buf.append(prefix + edgeString + " " + leaf.beginIndex);

//				Include suffix data from any extra leaf nodes.
				while (leaf.more != null) {
					leaf = leaf.more;
					buf.append("," + leaf.beginIndex);
				}
			}

//			If not at a leaf node, we recursively build the strings
//			corresponding to this node.  The prefix changes.
			else buf.append(toString(prefix+edgeString,(InternalNode)e.node));
		}
		return buf.toString();
	}

	/**
	 * Return a string representation of an array of integers.  Used for
	 * printing results of subtree searches.
	 * @param array the array of integers
	 * @return a String representation of the array of integers
	 */
	static String toString (int[] array) {
		if (array.length == 0) return "{}";
		StringBuffer buf = new StringBuffer("{" + array[0]);
		for (int i = 1; i < array.length; i++)
			buf.append("," + array[i]);
		return buf.append("}").toString();
	}

	/**
	 * A simple testing program for suffix trees.
	 * @param string the string used to build the suffix tree
	 */
	private static void test (String string) {
		suffixtree tree = new suffixtree(string);
		System.out.println(tree);
		System.out.println("'sisppi' occurs at " + toString(tree.findAll("sisppi")));
		System.out.println("'is' occurs at " + toString(tree.findAll("is")));
		System.out.println("'i' occurs at " + toString(tree.findAll("i")));
		System.out.println("The longest prefix of 'issue' occurs at " +
				toString(tree.longestPrefix("issue")));
		System.out.println();
	}

	/**
	 * Main program; used for testing.
	 */
	public static void main (String[] args) {
		test("mississippi$");
	}

}
