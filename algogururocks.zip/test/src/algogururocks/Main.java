/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package algogururocks;

import java.util.Scanner;

/**
 *
 * @author alok
 */
class A{
    int i=4;
    static int j=5;
    A(){
        i=10;j=10;
    }
    final void print(){
        System.out.print("  A: "+j);
    }
    static void PrintB(int i){
        System.out.println("  A printB :" +(i+j)+" " +new A().i);
    }
    void method(String s){
        System.out.print("string"+s);
    }
    void method(Object obj){
        System.out.println("object"+obj.toString());
    }
}

class B extends A{
    static int j=25;
    B b=null;
    B(){
        i=20;
        j=30;
    }
    B(B b) throws CloneNotSupportedException{
        this.b=b;
        b=(B)b.clone();
    }
    protected Object clone(){
    return new B();    
    }
    static void printB(int i){
        System.out.println("  B printB :" +(i+j)+""+new B().i);
     }
}
public class Main {
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws CloneNotSupportedException {
        // TODO code application logic here
     A a=new B();
     a.print();
     a.PrintB(1);
     B b=new B();//(B)a;
     b.print();
     b.PrintB(11);
     System.out.println((new B(b)).i+" : ");
     A a1=new A();
     a1.method(" XYZ");
    }
}
