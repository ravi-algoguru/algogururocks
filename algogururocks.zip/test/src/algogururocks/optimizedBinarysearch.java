package algogururocks;


import algogururocks.BinaryTree;
import algogururocks.Node;




public class optimizedBinarysearch {

	/**
	 * @param args
	 */
	static Node temp=null;
	public static boolean TwoWaybinarySearch(Node node, int data)
	{
		//instead of while(node!=null && node.data!=data)
		//since element comparision is costly than pointer comparision ,hence we removed the 
		//element comparision at each iteration.
		//if data is less then move left 
		//else assign temp to current or right child;
		//treverse till leaf node;
		while(node!=null)
		{
			if(data < node.data)
			{
				System.out.println("L   "+node.data);
				node=node.leftChild;

			}else{
				temp=node;
				System.out.println(temp.data);
				node=node.rightChild;
			}
		}
		if(temp!=null && temp.data==data)
			return true;

		else 
			return false;
	}


	public static boolean senitalBinarySearch(Node node,int data)
	{
		Node senital=new Node(0);

		while(node!=null && node.data!= data)
		{
			if(data< node.data)
				node=node.leftChild;
			else
				node=node.rightChild;
		}
		if(node!= senital)
			return true;
		else 
			return false;

	}
	public static void delete(Node node,int data)
	{
		Node candidate=null;
		if(node!=null)
		{
			if( data < node.data)
				if( node.leftChild!=null)
					delete (node.leftChild,data);
				else if (candidate!= null && candidate.data ==data)
				{
					candidate.data  = node.data;
					Node temp=node;
					node=node.rightChild;
				}
				else if (node.rightChild !=null)
				{
					candidate =node;
				delete (node.rightChild,data);
				}
				else if (data==node.data) 
					temp =node;
			node= node.leftChild;
		}
		}


		public static void main(String[] args) {
			// TODO Auto-generated method stub
			BinaryTree bTree=new BinaryTree();
			int[] arr={10,5,15,2,8,12,20,1,3,7,11,13,18,4,6,9,14,17,19,16};
			for(int i:arr)
				bTree.insert(i);

			/*                            10
			 * 
			 *              5								  15
			 *              
			 *       2       		  8               12                20
			 *       
			 *     1   3           7    9          11    13          18   
			 *     
			 *            4       6              14                17    19
			 *                                                 16
			 *                                                 
			 */
		//	delete(bTree.root,18);
		//	System.out.println(TwoWaybinarySearch(bTree.root, 16));
			//System.out.println(senitalBinarySearch(bTree.root,100));
			

		}

	}
