/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package algogururocks;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alok
 */
public class serializedClone implements Serializable ,Cloneable{
    private static final long serialVersionUID = 5686832478699718214L;
  
    @Override
    public Object clone(){
        ObjectOutputStream os = null;
        Object clone=null;
        try {
            ByteArrayOutputStream bout = new ByteArrayOutputStream();
            os = new ObjectOutputStream(bout);
            os.writeObject(this);
            os.close();

            ByteArrayInputStream bin = new ByteArrayInputStream(bout.toByteArray());
            ObjectInputStream in = new ObjectInputStream(bin);
            clone = (Object)in.readObject();
            in.close();
        }catch (ClassNotFoundException ex) {
            Logger.getLogger(serializedClone.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(serializedClone.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                os.close();
            } catch (IOException ex) {
                Logger.getLogger(serializedClone.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
        }
        return clone;
    }
    

}
