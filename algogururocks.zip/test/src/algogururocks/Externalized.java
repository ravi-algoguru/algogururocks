/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algogururocks;

import java.io.Externalizable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alok
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class Person {
    String name = "name : god";
}


class Employee extends Person implements Externalizable {
    private static final long serialVersionUID = 4324768022542691646L;
String name1;
    int age;
    String sex;
    public Employee(String name, int age) {
        this.name1 = name;
        this.age = age;
    }

    public Employee() {
        this("alok",34);
    }
    
    
    public void setName(String name) {
        this.name1 = name;
    }

    
    String getParentName() {
        return super.name;
    }

    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject("Emp !" +name1 );
        out.writeObject("Person !"+super.name);
        out.writeInt(100 + age);
    }

    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        name1 = " " + in.readChar();
        super.name = " " + in.readChar();
        age=in.readInt();
    }
}
public class Externalized {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Employee secretary = new Employee();
         secretary.setName("Reshmi");
        Employee manager = new Employee();
        manager.setName("Ravi");
        Employee exManager = new Employee();
        exManager.setName("Mrit");
            ObjectOutputStream os = null;
            ObjectInputStream in = null;
            try {
                os = new ObjectOutputStream(new FileOutputStream("externallizedfile.txt"));
                secretary.writeExternal(os);
                manager.writeExternal(os);
                //exManager.writeExternal(os);
              //  os.writeObject(secretary);
                //os.writeObject(manager);
              //  os.writeObject(exManager);

                in = new ObjectInputStream(new FileInputStream("externallizedfile.txt"));
                secretary.name1 = "Hi secretary :" + (String) in.readObject()+" ,My love my life";
                manager.name1 = "\n Hi manager :" + (String) in.readObject();
                //exManager.name1 = "\n Hi exmanager :" + (String) in.readObject();
                secretary.age=in.readInt();
               
                System.out.println(secretary.name1 + " ; " + manager.name1 +
                        " \n Person :" + secretary.getParentName()
                        +"\n age :" +secretary.age);

            } catch (IOException ex) {
                Logger.getLogger(Serialized.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    os.close();
                } catch (IOException ex) {
                    Logger.getLogger(Serialized.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
          }
}
