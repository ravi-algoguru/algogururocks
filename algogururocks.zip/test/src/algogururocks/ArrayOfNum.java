/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algogururocks;

import java.io.IOException;
import java.util.Arrays;
import java.util.Stack;
import java.util.regex.Pattern;

/**
 *
 * @author alok
 */
public class ArrayOfNum {

    static byte[] arr = new byte[32];

    static void findNumByDif(int[] arr, int diff) {
        System.out.println("find all possible set of number whose difference is a given num : " + diff);
        int i = 0, j = 1;
        for( ;  j < arr.length ;  ){
            if(arr[i] + diff <  arr[j])  {
                if(i < j -1)
                    i++;
                else {
                    i = j;
                    ++j;
                }
            }
            else if(arr[i] + diff > arr[j]) j++;
            else {
                System.out.println(arr[j] + " - " + arr[i]+ " = " + diff);
                j++; i++;
            }
        }
    }

    static boolean findNumBySum(int[] arr, int sum) {
        System.out.println("find all those two numbers whose sum is a given num : " + sum);
        int i = 0, j = arr.length - 1;
        while (i < j) {
            if (arr[i] + arr[j] > sum) {
                j--;
            } else if (arr[i] + arr[j] < sum) {
                i++;
            } else {
                System.out.println(arr[i] + " , " + arr[j]);
                i++;
                j--;
            }
        }
        return false;
    }

    static void findSquaredSet(int n) {
        System.out.println("present a givan num as sum of minimum required perfect squares: " + n);
        int j = (int) Math.floor(Math.sqrt(n));
        Stack stack = new Stack();
        int dif = n;
        while (j >= 1 && dif > 0) {
            //dif=dif-j*j;
            if (dif != 3 && dif != 8 && dif < j * j) {
                j--;
            } else {
                if (dif == 3) {
                    stack.push(1);
                    stack.push(1);
                    stack.push(1);
                    break;
                } else if (dif == 8) {
                    stack.push(2);
                    stack.push(2);
                    break;
                } else {
                    if (dif - j * j > 0) {
                        dif = dif - j * j;
                        stack.push(j);
                    }
                    j--;
                }
            }
        }
        while (!stack.isEmpty()) {
            System.out.print(stack.pop() + "^2+ ");
        }
        System.out.println("=" + n);
    }

    static void findClosestPair(int[] arr) {
        int[] x = new int[]{1, 2, 4, 5, 6, 8, 9, 10, 12, 14};
        int[] y = new int[]{100, 98, 45, 63, 33, 96, 2, -10, -100, 400};
        float[] d = new float[10];
        float[] ang = new float[10];
        for (int i = 0; i < 10; i++) {
            d[i] = (float) Math.sqrt(x[i] * x[i] + y[i] * y[i]);
            ang[i] = y[i] / x[i];
        }
        for (int i = 1; i < d.length; i++) {
            float temp = d[i];
            int j = 0;
            while (j < i && d[i] > d[j]) {
                j++;
            }
            d[i] = d[j];
            d[j] = temp;
            float atemp = ang[i];
            ang[i] = ang[j];
            ang[j] = atemp;
        }
    }

    static boolean isPrime(int n) {
        if (n == 1) {
            return false;
        }
        if (n == 2 || n == 3) {
            return true;
        }
        if (n % 2 == 0 || n % 3 == 0) {
            return false;
        }
        if (!(n % 6 == 1 || n % 6 == 5)) {
            return false;
        }
        int i = (int) Math.sqrt(n);
        for (int cnt = 5; cnt <= i; cnt++) {
            if (n % cnt == 0) {
                return false;
            }
        }
        return true;
    }

    static boolean prime(int n) {
        int i = (int) Math.sqrt(n);
        if (n % 2 == 0) {
            return false;
        }
        if (n % 3 == 0) {
            return false;
        }
        int j = 5;
        while (j <= i) {
            if (n % j == 0) {
                return false;
            }
            j++;
        }
        return true;
    }

    static void getByte(int n) {

        int count = 0;
        while (n >= 1) {
            arr[count++] = (byte) (n % 2);
            n = n / 2;
        }
        while (count >= 0) {
            System.out.print(arr[count--] + " ");
        }
    }

    static boolean findNumSetBySum(int[] arr, int sum) {
        int[] result = new int[100];
        boolean done = false;
        System.out.println("find set of num whose sum is a given num : " + sum);
        done= findNumSetBySum(arr, result, sum, 0, 0, false);
        return done;
    }

    static boolean findNumSetBySum(int[] arr, int[] result, int sum, int index, int i, boolean done) {
        if (sum == 0) {
            done = true;
            int j = 0;
            int n = 0;
            while (j < i) {
                if (result[j] != 0) {
                    System.out.print(result[j] + " , ");
                }
                j++;
            }
            System.out.println();
            return true;
        }
        if (done != true) 
        {
            if ((sum > 0 && index == arr.length) || (sum < 0)) {
                return false;
            }
            if (sum > 0 && index < arr.length) {
                findNumSetBySum(arr, result, sum, index + 1, i, false);
                if (sum >= arr[index]) {
                    result[i] = arr[index];
                    findNumSetBySum(arr, result, sum - arr[index], index + 1, i + 1, false);
                }
            }
       //     return false;
        }
        return false;
    }

    public static void doBalanacePartition(int[] arr) {
        int sum = 0;
        for (int i : arr) {
            sum += i;
        }
        int num = sum / 2;
        int k = num;
        while (!findNumSetBySum(arr, k)) {
            k++;
        }
        int j = num;
        while (!findNumBySum(arr, j)) {
            j--;
        }
    }
    
public static void convertIt(int number, int base) {

        if ( base <= 1 || base > 16)
            return;

        char[] array = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A',
                'B', 'C', 'D', 'E', 'F' };
        String convertedNum = "";

        do {
            convertedNum += array[number % base];
            number = number / base;
        } while (number != 0);

        convertedNum = new StringBuilder(convertedNum).reverse().toString();
        System.out.println(convertedNum);
    }

    public static void main(String[] args) throws IOException {
        System.out.print(isPrime(2));
       int[] arr = {1,2,3,5,1};
////{1, 2, 6, 8, 10, 12, 14, 16, 45, 46, 57, 65, 68, 69, 72, 73, 78, 81, 89, 91, 93, 97, 99, 101, 405, 408, 512, 1023, 1024,};
//        for (int i : arr) {
//          //  System.out.print(i + ",");
//        }
//        convertIt(5, 5);
//         int[] pattern = {9, 4 , 8,  7, 4, 2, 3, 2, 0}; //position in sorted array, index represent number
//         for(int i =0 ; i < arr.length; i++){
//             int x =arr[i];
//             arr[i] = pattern[arr[i]]; 
//           System.out.println(x + ">" + arr[i]);
//           //  System.out.print(arr[i]);
//       }
//            Arrays.sort(arr);
//             for(int i =0 ; i < arr.length; i++)
//             System.out.print(arr[i]);
//       String sortedStr = Arrays.toString(pattern);
//        System.out.println("\n");
//       System.out.println("sortedStr :"+ sortedStr.toString());
//       System.out.println("\n");
//        int[] pattern1 = {9, 4 , 8, 7, 2, 1, 6, 5, 0, 3};
//          for(int i =0 ; i < arr.length; i++){
//           int x = arr[i];
//              arr[i] =  pattern1[arr[i]];
//           System.out.println(x + ">" + arr[i]);
//       }
//          for(int i =0 ; i < arr.length; i++){
//             System.out.print(arr[i]);// Character.isJavaIdentifierStart(0)
////        System.out.print("\n");
       findNumBySum(arr, 18);
//        findNumByDif(arr, 4);
//        findSquaredSet(301);
//     // System.out.print(""+findNumSetBySum(arr, 25));
//        System.out.print("\nisPrime  :  "+isPrime(1108729));
//        doBalanacePartition(arr);


//        BufferedWriter bw = new BufferedWriter(new FileWriter("C:\\Users\\alok\\Desktop\\prime999999"));
//        BufferedWriter bdif = new BufferedWriter(new FileWriter("C:\\Users\\alok\\Desktop\\dif"));
//        BufferedWriter bprime = new BufferedWriter(new FileWriter("C:\\Users\\alok\\Desktop\\prime"));
//        int[] arr1 = new int[100000];
//        int[] dif = new int[100000];
//        int count = 0;
//       int n = 1;
//        while (n < 999999) {
//            if (isPrime(n)) {
//                System.out.print("\n"+n);
//            }
//            if(prime(n))System.out.print(" ! "+ n);
//           // System.out.println();
//            n++;
//        }
//                arr1[count] = n;
//                bw.write(" \n " + n + "            ");
//                bprime.write(n + ".");
//                bw.write(Integer.toBinaryString(n));
//                if (count > 0) {
//                    dif[count] = -arr1[count - 1] + arr1[count];
//                    bw.write(",            " + dif[count]);
//                    bdif.write(",          " + (-arr1[count - 1] + arr1[count]));
//                }
//                System.out.println(count);
//                count++;
//            }
//            n++;
//        }

    }
}
