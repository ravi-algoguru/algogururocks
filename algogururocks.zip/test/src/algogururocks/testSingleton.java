package algogururocks;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
class SingletonRegistry {
	public static SingletonRegistry REGISTRY = new SingletonRegistry();
	private static HashMap map = new HashMap();
	protected SingletonRegistry() {
		// Exists to defeat instantiation
	}
	private static Class getClass(String classname) 
	throws ClassNotFoundException {
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		if(classLoader == null)
			classLoader = Singleton.class.getClassLoader();
		return (classLoader.loadClass(classname));
	}
	public static synchronized Object getInstance(String classname) {
		Object singleton = map.get(classname);
		if(singleton != null) {
			return singleton;
		}
		try {
			singleton = Class.forName(classname).newInstance();
		    // singleton= getClass(classname);
			System.out.println("created singleton: " + singleton);
		}
		catch(ClassNotFoundException cnf) {
			System.out.println("Couldn't find class " + classname);    
		}
		catch(InstantiationException ie) {
			System.out.println("Couldn't instantiate an object of type " + 
					classname);    
		}
		catch(IllegalAccessException ia) {
			System.out.println("Couldn't access class " + classname);    
		}
		map.put(classname, singleton);
		return singleton;
	}
	
	
}

 class Singleton {
	public static final Singleton INSTANCE = null;
	private Singleton() {
		// Exists only to thwart instantiation.
	}
	public static Singleton getInstance(String classname) {

		return (Singleton)SingletonRegistry.REGISTRY.getInstance(classname);
	}
}
//	Serialization

	//If you serialize a singleton and then deserialize it twice, you will have two instances of your singleton,
	//unless you implement the readResolve() method, like this:
	class serializeSingleton implements java.io.Serializable {
		   public static serializeSingleton INSTANCE = new serializeSingleton();
		   protected serializeSingleton() {
		      // Exists only to thwart instantiation.
		   }
		      private Object readResolve() {
		            return INSTANCE;
		      }
		}
public class testSingleton{
	public void testSerialize() {
		System.out.println("testing singleton serialization...");
	      writeSingleton();
	      Singleton s1 = readSingleton();
	      Singleton s2 = readSingleton();
	      }
	   private void writeSingleton() {
	      try {
	         FileOutputStream fos = new FileOutputStream("serializedSingleton");
	         ObjectOutputStream oos = new ObjectOutputStream(fos);
	         Singleton s = Singleton.INSTANCE;
	         oos.writeObject(Singleton.INSTANCE);
	         oos.flush();
	      }
	      catch(NotSerializableException se) {
	    	  System.out.println("Not Serializable Exception: " + se.getMessage());
	      }
	      catch(IOException iox) {
	    	  System.out.println("IO Exception: " + iox.getMessage());
	      }
	   }
	   private Singleton readSingleton() {
	      Singleton s = null;
	      try {
	         FileInputStream fis = new FileInputStream("serializedSingleton");
	         ObjectInputStream ois = new ObjectInputStream(fis);
	         s = (Singleton)ois.readObject();
	      }
	      catch(ClassNotFoundException cnf) {
	    	  System.out.println("Class Not Found Exception: " + cnf.getMessage());
	      }
	      catch(NotSerializableException se) {
	         System.out.println("Not Serializable Exception: " + se.getMessage());
	      }
	      catch(IOException iox) {
	    	  System.out.println("IO Exception: " + iox.getMessage());
	      }
	      return s;
	   }
	
}