/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algogururocks;

//~--- JDK imports ------------------------------------------------------------
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author alok
 */
public class anagram {

    static int count = 1;
    static Set<char[]> set = new HashSet<char[]>();

//    public static void doAnagram(String str) {
//        int n = str.length();
//        char[] chstr = str.toCharArray();
//
//        doAnagram(chstr, n);
//    }
//
//    private static void doAnagram(char[] str, int n) {
//        if (n == 1) {
//            return;
//        }
//
//        for (int i = 0; i < n; i++) {
//            str = rotate(str, n, i);
//            doAnagram(str, n - 1);
//        }
//    }
//
//    private static char[] rotate(char[] str, int n, int i) {
//        char[] previous = str;
//
//        // System.out.print("\n previous  :  ");
//        // System.out.print(previous);
//        while (i > 0) {
//            int max = str.length - 1;
//            int index = str.length - n;
//            char ch = str[str.length - n];
//
//            for (; index < max; index++) {
//                str[index] = str[index + 1];
//            }
//
//            str[max] = ch;
//
//            // System.out.print("  n :" + n + "   i:" + i);
//            printStr(str);
//            i--;
//        }
//
//        return str;
//    }
//
//    private static void swap(char[] str) {
//        char ch = str[0];
//
//        str[0] = str[1];
//        str[1] = ch;
//    }
//
//    private static void printStr(char[] str) {
//        System.out.print("\n ");
//        System.out.print(count + "    ");
//
//        if (count < 1000) {
//            System.out.print(" ");
//        }
//
//        if (count < 100) {
//            System.out.print(" ");
//        }
//
//        if (count < 10) {
//            System.out.print(" ");
//        }
//
//        for (int i = 0; i < str.length; i++) {
//            System.out.print(str[i] + " ");
//        }
//
//        count++;
//    }

    
    static void doAnagram(StringBuilder prefix, StringBuilder suffix){
        if(suffix.length()==1){
            System.out.println(prefix.append(suffix));
            return;
        }
        for(int i=0;i < suffix.length();i++){
            String tempPre=prefix.toString();
            String tempSuf=suffix.toString();
            doAnagram(prefix.append(suffix.charAt(i)),new StringBuilder(suffix.substring(0, i)+suffix.substring(i+1, suffix.length())));
            prefix=new StringBuilder(tempPre);suffix=new StringBuilder(tempSuf);
        }
    }
    static void permute(String str) {
        int length = str.length();
        boolean[] used = new boolean[length];
        StringBuilder out = new StringBuilder();
        char[] in = str.toCharArray();

        doPermute(in, out, used, length, 0);
    }

    static void doPermute(char[] in, StringBuilder out,
            boolean[] used, int length, int level) {
        if (level == length) {
            System.out.println(out.toString());
            ++count1;
            return;
        }

        for (int i = 0; i < length; ++i) {
            if (used[i]) {
                continue;
            }
            out.append(in[i]);
            used[i] = true;
            doPermute(in, out, used, length, level + 1);
            used[i] = false;
            out.setLength(out.length() - 1);
        }
    }
static int count1=0;
    public static void main(String[] args) {
        System.out.println("enter string");

        String str = new String("ABCDEFGH");
        permute(str);
       // System.out.println(count1);
       doAnagram(new StringBuilder(),new StringBuilder(str));
    }
}


//~ Formatted by Jindent --- http://www.jindent.com
