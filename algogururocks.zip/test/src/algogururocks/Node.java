/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algogururocks;

/**
 *
 * @author alok
 */
public class Node {

    public int data;
    public Node leftChild;
    public Node rightChild;
    public int color = 0;
    public Node parent;

    public Node(int data) {
        this.data = data;
        leftChild = null;
        rightChild = null;
        color = 0;
        parent = null;
    }

    public Node getGrand() {
        return getGrand(this);
    }

    private Node getGrand(Node node) {
        if (node != null && node.parent != null && node.parent.parent != null) {
            return node.parent.parent;
        }
        return null;
    }

    public Node getUncle() {
        return getUncle(this);
    }

    private Node getUncle(Node node) {
        if(node==null)return null;
        Node grand = getGrand();
        if (grand == null) {
            return null;
        }
        if (node.parent != null && node.parent == grand.leftChild) {
            return grand.rightChild;
        } else {
            return grand.leftChild;
        }
    }
}
