/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algogururocks;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alok
 */
class Person {

    String name="god";
  //  int age;

    Person(String name) {
        this.name = name;
        //this.age = age;
    }
}


class Employee extends serializedClone implements Serializable {
    private static final long serialVersionUID = -9183196480807103204L;
    transient Person father=new Person("GOD");
    String name;
    int age;
    GregorianCalendar dob;
    transient int id;
   transient  String fatherName;

    Employee(String name, int age, int year, int month, int day) {
        this.name = name;
        this.age = age;
        dob = new GregorianCalendar(year, month, day);
    }
    
    private void writeObject(ObjectOutputStream os) throws IOException{
        os.defaultWriteObject();
        os.writeInt(100);
        os.writeChars("father");
        //os.writeObject(new Person("God"));
    }
    
    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException{
        in.defaultReadObject();
        id=in.readInt();
        fatherName=""+in.readChar();
    //    father=(Person)in.readObject();
    }
   String getFather(){
        return fatherName;
    }
   int getId(){
       return id;
   }
}

class Manager extends Employee {
    private static final long serialVersionUID = -6895931588244096035L;

    double salary;
    Employee secretary;
    

    Manager(String name, int age, int year, int month, int day, double salary, Employee secretary) {
        super(name, age, year, month, day);
        this.salary = salary;
        this.secretary = secretary;
    }
   private void writeObject(ObjectOutputStream os) throws IOException{
        os.defaultWriteObject();
        os.writeInt(200);
        //os.writeObject(new Person("God"));
    }
    
    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException{
        in.defaultReadObject();
        id=in.readInt();
    //    father=(Person)in.readObject();
    }
   String getFather(){
        return father.name;
    }
    @Override
   int getId(){
       return id;
   }
}
public class Serialized {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Employee secretary = new Employee("reshmi", 21, 1983, 9, 14);
        Manager manager = new Manager("ravi", 25, 1983, 8, 18, 85000, secretary);
        Manager exManager = new Manager("mrit", 25, 1981, 12, 12, 125000, secretary);
        Employee[] resdoll = new Employee[3];
        resdoll[0] = exManager;
        resdoll[1] = manager;
        resdoll[2] = secretary;
        Employee resh, ravi, mrit;
        {
            ObjectOutputStream os = null;
            ObjectInputStream in = null;
            try {
                os = new ObjectOutputStream(new FileOutputStream("resh.txt"));
                os.writeObject(resdoll);
                //   os.putFields();
                // os.writeFields();
                os.writeObject(secretary);
                
                os.writeObject(manager);
                os.writeObject(exManager);
                os.close();

                in = new ObjectInputStream(new FileInputStream("resh.txt"));
                Employee[] staff = (Employee[]) in.readObject();
                resh = (Employee) in.readObject();
                ravi = (Employee) in.readObject();
                mrit = (Employee) in.readObject();

                for (Employee e : staff) {
                    System.out.print(e);
                }
                System.out.println("\n" + resh + " : " + ravi + " : " + mrit);
                System.out.println(resh.getId()+" ; father :"+resh.fatherName);
                      System.out.println(mrit.getId());
                System.out.println(ravi.getId());
          
            } catch (IOException ex) {
                Logger.getLogger(Serialized.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    os.close();
                } catch (IOException ex) {
                    Logger.getLogger(Serialized.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
  Employee cloned=new Employee("cloned", 1000, 2100, 12, 12);
           Employee newClone=(Employee) cloned.clone();
         System.out.println(cloned==newClone);

            File f = new File("resh.txt");
            System.out.print("file : " + f.createNewFile());
           // System.out.println("\n" + in.getClass().getDeclaredFields() + " " + os.getClass().getConstructors());
        }
    }
}
