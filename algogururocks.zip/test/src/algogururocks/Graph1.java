package algogururocks;


public class Graph1 {

}
