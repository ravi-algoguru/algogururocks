/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package algogururocks;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author alok
 */
public class primePattern {
   static int[] doFreq(int[]arr,int l,int r){
        int[]freq=new int[100];
        int i=l+1;
        if(i<=r){
            freq[arr[i]]++;
        }
        return arr;
    }
public static void main(String[]args) throws FileNotFoundException, IOException{
    int[]prime=new int[76471];
    int[] dif=new int[76471];
    String[] str=null;
    BufferedReader br=new BufferedReader(new FileReader("C:\\Users\\alok\\Desktop\\prime"));
    String bstr=br.readLine();
    while(bstr!=null){
         if(bstr.length()==0)return;
         //if(!bstr.contains(" "))return;
         int a=0;
         StringBuilder num=new StringBuilder();
         while(a<bstr.length()){
             //if(bstr.charAt(a)==(char)' ')
             //{System.out.println();a++;}
             num=num.append(bstr.charAt(a++));
        // System.out.print();
         }
         //str=(br.readLine()).split(' '+"");
         str=num.toString().split("\\.");
         int i=0;
         while(str!=null && i<76471&& (str[i].length()!=0 || str[i]!=null)){
            prime[i]=Integer.parseInt(str[i].trim());
            i++;
         }
         //str=null;
     }
    System.out.println("writing resdoll !!!!!");
    BufferedWriter bw=new BufferedWriter(new FileWriter("C:\\Users\\alok\\Desktop\\resdoll"));
    int i=0,count=-1;
    int[][]freq=new int[6][100];
while(i<664576){
    while(prime[i]<=99)
        freq[0]=doFreq(prime,count,i);
    count=i;
    while(prime[i]>99 && prime[i]<=999)
       freq[1]=  doFreq(prime,count,i);
    count=i;
    while(prime[i]>999 && prime[i]<=9999)
       freq[2]=  doFreq(prime,count,i);
    count=i;
    while(prime[i]>9999 && prime[i]<=99999)
         freq[3]=doFreq(prime,count,i);
    count=i;
    while(prime[i]>99999 && prime[i]<=999999)
         freq[4]=doFreq(prime,count,i);
    count=i;
    while(prime[i]>999999 && prime[i]<=999999)
        freq[5]= doFreq(prime,count,i);
    count=i;
}
    int j=0,k=0;
    while(j<6){
        while(k<100)
            bw.write(freq[j][k]);
        System.out.println();
    }
}
}
