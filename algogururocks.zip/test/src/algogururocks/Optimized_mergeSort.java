/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algogururocks;

/**
 *
 * @author alok
 */

/*
 * Revision of Carrano's MergeSort algorithm:
 *
 * (1)  Make the public method symmetric with other sorting
 *      methods:  whateverSort(Comparable[], int size);
 * (2)  Eliminate the O(n log n) space required by all of the
 *      tempArray allocations.  Instead, allocate the tempArray
 *      in the public method and then PASS that along to the
 *      private methods for them to use.
 *
 * Author:  Timothy Rolfe
 */
class MergeSort {
// Kludge to jump over to the driver in the TextPad environment
    public static void main(String[] args) {
        Optimized_mergeSort.main(args);
    }    // Trace the progress of the algorithm on Integer objects
    private static final boolean DEBUG = true;

    private static void merge(Comparable[] theArray,
            Comparable[] tempArray, int first, int mid, int last) {
        // ---------------------------------------------------------
        // Merges two sorted array segments theArray[first..mid] and
        // theArray[mid+1..last] into one sorted array.
        // Precondition: first <= mid <= last. The subarrays
        // theArray[first..mid] and theArray[mid+1..last] are
        // each sorted in increasing order.
        // Postcondition: theArray[first..last] is sorted.
        // Implementation note: This method merges the two
        // subarrays into a temporary array and copies the result
        // into the original array anArray.
        // ---------------------------------------------------------

        // initialize the local indexes to indicate the subarrays
        int first1 = first;    // beginning of first subarray
        int last1 = mid;      // end of first subarray
        int first2 = mid + 1;  // beginning of second subarray
        int last2 = last;     // end of second subarray
        // while both subarrays are not empty, copy the
        // smaller item into the temporary array
        int index = first1;    // next available location in
        // tempArray
        while ((first1 <= last1) && (first2 <= last2)) {
            // Invariant: tempArray[first1..index-1] is in order
            if (theArray[first1].compareTo(theArray[first2]) < 0) {
                tempArray[index] = theArray[first1];
                first1++;
            } else {
                tempArray[index] = theArray[first2];
                first2++;
            }  // end if
            index++;
        }  // end while

        // finish off the nonempty subarray

        // finish off the first subarray, if necessary
        while (first1 <= last1) {
            // Invariant: tempArray[first1..index-1] is in order
            tempArray[index] = theArray[first1];
            first1++;
            index++;
        }  // end while

        // finish off the second subarray, if necessary
        while (first2 <= last2) {
            // Invariant: tempArray[first1..index-1] is in order
            tempArray[index] = theArray[first2];
            first2++;
            index++;
        }  // end while

        if (DEBUG) {
            System.out.println("Result of merging " + first +
                    " to " + mid + " with " +
                    (mid + 1) + " to " + last);
            //Print the blank front of the array
            for (index = 0; index < first; index++) {
                System.out.print("   ");
            }
        }
        // copy the result back into the original array
        for (index = first; index <= last; ++index) {
            theArray[index] = tempArray[index];
            if (DEBUG) // NOTE:  presumes Comparable is Integer
            {
                System.out.print(
                        (((Integer) (theArray[index])).intValue() < 10 ? "  " : " ") +
                        theArray[index]);
            }
        }  // end for
        if (DEBUG) {
            System.out.println();
        }
    }  // end merge

    private static void mergesort(Comparable[] theArray,
            Comparable[] tempArray, int first, int last) {
        // ---------------------------------------------------------
        // Sorts the items in an array into ascending order.
        // Precondition: theArray[first..last] is an array.
        // Postcondition: theArray[first..last] is sorted in
        // ascending order.
        // Calls: merge.
        // ---------------------------------------------------------
        if (first < last) {
            // sort each half
            int mid = (first + last) / 2;   // index of midpoint
            // sort left half theArray[first..mid]
            mergesort(theArray, tempArray, first, mid);
            // sort right half theArray[mid+1..last]
            mergesort(theArray, tempArray, mid + 1, last);

            // merge the two halves
            merge(theArray, tempArray, first, mid, last);
        }  // end if
    }  // end private mergesort

    public static void mergesort(Comparable[] theArray,
            int size) {
        // ---------------------------------------------------------
        // Sorts the items in an array into ascending order.
        // Precondition: theArray[] is an array.
        // Postcondition: theArray[] is sorted in ascending order.
        // Calls: private mergesort.
        //
        // NOTE:  the differences in parameter lists allow us to
        //        overload the method name "mergesort".
        // ---------------------------------------------------------
        // int maxSize = size; omit --- just use the parameter passed
        // temporary array allocated just this ONCE.  Everyone shares it.
        Comparable[] tempArray = new Comparable[size];

        if (DEBUG) // NOTE:  presumes Comparable is Integer
        {
            System.out.println("Initial state of the array:");
            //Print the blank front of the array
            for (int index = 0; index < size; index++) {
                System.out.print(
                        (((Integer) (theArray[index])).intValue() < 10 ? "  " : " ") + theArray[index]);
            }
            System.out.println();
        }

        // Invoke the private method that does ALL the work
        mergesort(theArray, tempArray, 0, size - 1);
    // NOTE:  In an environment without garbage collection,
    //        return tempArray space for re-use.
    } // end public mergesort
}

public class Optimized_mergeSort {
    /*
     * Exercise MergeSort.mergesort
     *
     * Author:  Revised from the website by Timothy Rolfe
     */

    public static void main(String[] args) {
        Integer[] values = new Integer[10];
        values[0] = new Integer(9);
        values[1] = new Integer(15);
        values[2] = new Integer(13);
        values[3] = new Integer(20);
        values[4] = new Integer(5);
        values[5] = new Integer(0);
        values[6] = new Integer(7);
        values[7] = new Integer(10);
        values[8] = new Integer(3);
        values[9] = new Integer(2);
        MergeSort.mergesort(values, values.length);
    }
}
/*  Result of a run --- output from MergeSort due to DEBUG flag

Initial state of the array:
9 15 13 20  5  0  7 10  3  2
Result of merging 0 to 0 with 1 to 1
9 15
Result of merging 0 to 1 with 2 to 2
9 13 15
Result of merging 3 to 3 with 4 to 4
5 20
Result of merging 0 to 2 with 3 to 4
5  9 13 15 20
Result of merging 5 to 5 with 6 to 6
0  7
Result of merging 5 to 6 with 7 to 7
0  7 10
Result of merging 8 to 8 with 9 to 9
2  3
Result of merging 5 to 7 with 8 to 9
0  2  3  7 10
Result of merging 0 to 4 with 5 to 9
0  2  3  5  7  9 10 13 15 20
 */


