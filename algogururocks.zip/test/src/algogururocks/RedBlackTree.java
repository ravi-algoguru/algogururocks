/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algogururocks;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author alok
 */
public class RedBlackTree {

    Node root;///0 =red, 1=black;

    public RedBlackTree() {
        root = null;
    }

    public boolean rbInsert(int data) {
        if (root == null) {
            root = new Node(data);
            root.color = 1;
            return true;
        }
        return rbInsert(root, data);
    }

    private boolean rbInsert(Node node, int data) {
        if (node == null) {
            return false;
        }
        if (data < node.data) {
            if (node.leftChild == null) {
                node.leftChild = new Node(data);
                node.leftChild.parent = node;
                doBalance(node.leftChild);
            } else {
                rbInsert(node.leftChild, data);
            }
        } else if (data > node.data) {
            if (node.rightChild == null) {
                node.rightChild = new Node(data);
                node.rightChild.parent = node;
                doBalance(node.rightChild);
            } else {
                rbInsert(node.rightChild, data);
            }
        } else {
            return false;
        }
        return true;
    }

    public int getHeight() {
        if (root == null) {
            return 0;
        }
        if (root.leftChild == null && root.rightChild == null) {
            return 1;
        }
        return getHeight(root);
    }

    private int getHeight(Node node) {
        if (node == null) {
            return 0;
        }
        return (Math.max(getHeight(node.leftChild), getHeight(node.rightChild)) + 1);
    }

    public Node doBalance(Node node) {
        int x = getHeight();
        if (x == 3 || x == 4) {
            doRightRotation_color(node);
            doLeftRotation_Color(node);
        }
        while (node != null && node.getGrand() != null && node != root && node.color == 0) {
            if (node.parent != null && node.getGrand() != null && node.getUncle() != null) {
                Node res = null;
                if (node.parent == node.getGrand().leftChild) {
                    if (node.getUncle().color == 0)//red
                    {
                        res = doColor(node);
                    } else {
                        if (node == node.parent.rightChild) {
                            res = doLeftRotation(node);
                        } else {
                            res = doRightRotation_color(node);
                        }
                    }
                } else {
                    if (node.getUncle().color == 0) {
                        res = doColor(node);
                    } else {
                        if (node.parent.leftChild == node) {
                            res = doRightRotation(node);
                        } else {
                            res = doRightRotation_color(node);
                        }
                    }
                }
                node = res;
            } else {
                break;
            }
        }
        return node;
    }

    private Node doColor(Node node) {
        Node grand = node.getGrand();
        while (node!=null && node != root && grand != null) {
            if (node.parent != null && node.parent.color == 0 && node.getGrand() == null) {
                node.parent.color = 1;
                break;
            } else {
                node.parent.color = 1;
                if (node.getUncle() != null) {
                    node.getUncle().color = 1;
                }
                if (node.getGrand() != null) {
                    node.getGrand().color = 0;
                    node = node.getGrand();
                }
            }
        }
        return node;
    }

    private Node doRightRotation(Node node) {
        Node grand = node.getGrand();
        if (grand != null && grand.rightChild == node.parent && node.parent.leftChild == node) {
            Node pTemp = grand.rightChild;
            Node node_rightTemp = node.rightChild;
            grand.rightChild = node;
            node.parent = grand;
            node.rightChild = pTemp;
            if (pTemp != null) {
                pTemp.leftChild = node_rightTemp;
            }
            if (node_rightTemp != null) {
                node_rightTemp.parent = pTemp;
            }
            node = doLeftRotation_Color(node);
        }
        return node;
    }

    private Node doLeftRotation(Node node) {
        Node grand = node.getGrand();
        if (grand != null && node.parent == grand.leftChild && node.parent.rightChild == node) {
            Node ptemp = grand.leftChild;
            Node node_leftTemp = node.leftChild;
            grand.leftChild = node;
            node.parent = grand;
            node.leftChild = ptemp;
            if (ptemp != null) {
                ptemp.rightChild = node_leftTemp;
            }
            if (node_leftTemp != null) {
                node_leftTemp.parent = ptemp;
            }
            node = doRightRotation_color(node);
        }
        return node;
    }

    private Node doRightRotation_color(Node node) {
        Node pNode = node.parent;
        if (pNode != null) {
            Node gNode = pNode.parent;
            Node ggNode = pNode.getGrand();
            Node gNodeTemp = null;
            if (gNode != null && ggNode != null) {
                if (ggNode.leftChild == gNode) {
                    gNodeTemp = ggNode.leftChild;
                    ggNode.leftChild = pNode;
                } else {
                    gNodeTemp = ggNode.rightChild;
                    ggNode.rightChild = pNode;
                }
                pNode.parent = ggNode;
                Node pNode_rightTemp = pNode.rightChild;
                pNode.rightChild = gNodeTemp;
                gNodeTemp.parent = pNode;
                gNodeTemp.leftChild = pNode_rightTemp;
                pNode.color = 1;
                gNodeTemp.color = 1;
                if (pNode_rightTemp != null) {
                    pNode_rightTemp.parent = gNodeTemp;
                }
            }
        }
        return pNode;
    }

    public Node doLeftRotation_Color(Node node) {
        Node pNode = node.parent;
        if (pNode != null) {
            Node gNode = pNode.parent;
            Node ggNode = pNode.getGrand();
            Node gNodeTemp = null;
            if (gNode != null && ggNode != null) {
                if (ggNode.leftChild == gNode) {
                    gNodeTemp = ggNode.leftChild;
                    ggNode.leftChild = pNode;
                } else {
                    gNodeTemp = ggNode.rightChild;
                    ggNode.rightChild = pNode;
                }
                pNode.parent = ggNode;
                Node pNode_leftTemp = pNode.leftChild;
                pNode.leftChild = gNodeTemp;
                gNodeTemp.parent = pNode;
                gNodeTemp.rightChild = pNode_leftTemp;
                pNode.color = 1;
                gNodeTemp.color = 1;
                if (pNode_leftTemp != null) {
                    pNode_leftTemp.parent = gNodeTemp;
                }
            }
        }
        return pNode;
    }

    public void printTree() {
        inOrderLevelTreversal(root);
    }

    private void inOrderLevelTreversal(Node node) {
        if (node == null) {
            return;
        } else {
            inOrderLevelTreversal(node.leftChild);
            System.out.print(node.data + " , ");
            inOrderLevelTreversal(node.rightChild);
        }
    }

    public void iterative_levelOrder() {
        iterative_levelOrder(root);
    }

    private void iterative_levelOrder(Node node) {
        Queue<Node> queue = new LinkedList();
        queue.offer(node);
        Node mark = new Node('&');
        queue.offer(mark);
        while (true) {
            Node delNode = queue.poll();
            if (queue.isEmpty() || delNode == null) {
                break;
            }
            if (delNode != mark) {
                System.out.print(delNode.data + " , ");
                if (delNode.leftChild != null) {
                    queue.offer(delNode.leftChild);
                }
                if (delNode.rightChild != null) {
                    queue.offer(delNode.rightChild);
                }
            } else {
                System.out.println();
                queue.offer(mark);
            }
        }
    }

    public static void main(String[] args) {
        RedBlackTree rbTree = new RedBlackTree();
//        int[] dataArr = {6, 5, 4, 3, 2, 1, 7, 8, 9, 10, 11, 12, 13, 14, 15,-1,-2,-3,-4,-5,-6};
//        for (int data : dataArr) {
//            rbTree.rbInsert(data);
//        }
//        rbTree.doRightRotation_color(rbTree.root);
        int count = 0;
        while (count < 50) {
            rbTree.rbInsert(count);
            count++;
        }
        rbTree.iterative_levelOrder();
    }
}
