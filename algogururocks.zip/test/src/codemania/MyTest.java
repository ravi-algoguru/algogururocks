/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;

/**
 *
 * @author sony
 */
public class MyTest {

    public static void main(String[]args){
        String num="12ABZ";
        convertUnknownBaseNumberToBase10(num);
    }
    public static Double convertUnknownBaseNumberToBase10(String number) {
        // null check
        if (number == null || number.length() == 0) {
            return null;
        }

        // turn to upper case - so that our logic below is easy
        number = number.toUpperCase();

        // scan through the string to find out the maximum number or the character
        int maxAscii = 0;
        for (int i = 0; i < number.length(); i++) {
            int ascii = number.charAt(i);
            if (!(((ascii >= '0') && (ascii <= '9')) || ((ascii >= 'A') && (ascii <= 'Z')))) {
                System.out.println("Illegal number, can have only digits (0-9) and letters (A-Z)");
                return null;
            }
            maxAscii = Math.max(ascii, maxAscii);
        }

        // check if the number has letters or not
        double finalNumber = 0;
        int length = number.length();
        if (maxAscii >= 'A') {
            int maxNumber = maxAscii - 'A' + 10 + 1;
            for (int i = 0; i < length; i++) {
                int charCode = number.charAt(i);
                if (charCode >= 'A') {
                    charCode = charCode - 'A' + 10;
                }
                int num = charCode;
                finalNumber = finalNumber + (num * Math.pow(maxNumber, (length - i - 1)));
            }
        } else {
            int maxNumber = maxAscii - '0' + 1;
            // just iterate over a normal loop
            for (int i = 0; i < length; i++) {
                int num = number.charAt(i) - '0';
                finalNumber = finalNumber + (num * Math.pow(maxNumber, (length - i - 1)));
            }
        }
         System.out.println(finalNumber);
        return finalNumber;
    }
}
