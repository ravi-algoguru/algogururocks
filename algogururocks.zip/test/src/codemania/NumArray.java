/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;

import java.io.IOException;

/**
 *
 * @author sony
 */
public class NumArray {

    public static void main(String[] args) throws IOException {
        int[] arr = {1, 2, 6, 8, 10, 12, 14, 16, 45, 46, 57, 65, 68, 69, 72, 73, 78, 81, 89, 91, 93, 97, 99, 101, 405, 408, 512, 1023, 1024,};
        for (int i : arr) {
            //     System.out.print(i + ",");
        }
//        System.out.print("\n");
//        findNumBySum(arr, 18);
//        findNumByDif(arr, 4);
//        System.out.print(interpolatedSearch(arr, 57));
        int n = 1000;

        //    System.out.print(n&~(n-1));
        //      findSquaredSet(301);
        //      System.out.print("" + findNumSetBySum(arr, 25));
//        System.out.print("\nisPrime  :  " + isPrime(1108729));
//     doBalanacePartition(arr);
        int arr1[] = {4, 2, 4, 5, 2, 3, 1};
        find2Duplicate(arr);
    }

    static void find2Duplicate(int arr[]) {
        int xor = arr[0]; /* Will hold xor of all elements */
        int set_bit_no;  /* Will have only single set bit of xor */
        int i;
        int size = arr.length;
        int n = size - 2;
        int x = 0, y = 0;

        /* Get the xor of all elements in arr[] and {1, 2 .. n} */
        for (i = 1; i < size; i++) {
            xor ^= arr[i];
        }
        for (i = 1; i <= n; i++) {
            xor ^= i;
        }

        /* Get the rightmost set bit in set_bit_no */
        set_bit_no = Integer.lowestOneBit(xor);//xor & ~(xor - 1);
          if(xor%2==0) set_bit_no=0;
          else set_bit_no=1;
        /* Now divide elements in two sets by comparing rightmost set
         bit of xor with bit at same position in each element. */
        for (i = 0; i < size; i++) {
            if ((arr[i] & set_bit_no) > 0) {
                x = x ^ arr[i]; /*XOR of first set in arr[] */
            } else {
                y = y ^ arr[i]; /*XOR of second set in arr[] */
            }
        }
        for (i = 1; i <= n; i++) {
            if ((i & set_bit_no) > 0) {
                x = x ^ i; /*XOR of first set in arr[] and {1, 2, ...n }*/
            } else {
                y = y ^ i; /*XOR of second set in arr[] and {1, 2, ...n } */
            }
        }

        System.out.println("\n The two repeating elements are " + x + "," + y);
    }

    public static void findNumBySum(int[] arr, int num) {
        int i = 0;
        int sum = 0;
        int j = arr.length - 1;
        while (i < j) {
            sum = arr[i] + arr[j];
            if (sum < num) {
                i++;
            } else if (sum > num) {
                j--;
            } else {
                System.out.print(arr[i] + "," + arr[j] + "\n");
                i++;
                j--;
            }
        }
    }

    public static void findNumByDif(int[] arr, int diff) {
        int i = 0;
        int sum = 0;
        int j = 1;
        int len = arr.length;
        while (i < j && j < len) {
            sum = arr[i] + diff;
            if (sum < arr[j]) {
                i++;
            } else if (sum == arr[j]) {
                System.out.print(arr[i] + "," + arr[j] + "\n");
                i++;
                j++;
            } else {
                j++;
            }
        }
    }

    private static int interpolatedSearch(int[] arr, int num) {
        int low = 0;
        int high = arr.length - 1;
        int iPoint = 0;
        int index = -1;
        while (num <= arr[high] && num >= arr[low]) {
            iPoint = low + (high - low) * (num - arr[low]) / (arr[high] - arr[low]);
            if (num < arr[iPoint]) {
                high = iPoint - 1;
            } else if (num > arr[iPoint]) {
                low = iPoint + 1;
            } else {
                index = iPoint;
                break;
            }
        }
        return index;

    }
}