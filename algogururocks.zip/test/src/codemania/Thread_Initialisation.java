/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author sony
 */
public class Thread_Initialisation {
    
}
class Safe { 

  private Object me;
  private Set set = new HashSet();
  private Thread thread;

  public Safe() { 
    // Safe because "me" is not visible from any other thread
    me = this;

    // Safe because "set" is not visible from any other thread
    set.add(this);

    // Safe because MyThread won't start until construction is complete
    // and the constructor doesn't publish the reference
    thread = new MyThread(this);
  }

  public void start() {
    thread.start();
  }

  private class MyThread extends Thread {
    private Object theObject;

    public MyThread(Object o) { 
      this.theObject = o;
    }

//    ...
  }
}

 class Unsafe {
  public static Unsafe anInstance;
  public static Set set = new HashSet();
  private Set mySet = new HashSet();
  private Thread thread;

  public Unsafe() {
    // Unsafe because anInstance is globally visible
    anInstance = this;

    // Unsafe because SomeOtherClass.anInstance is globally visible
    SomeOtherClass.anInstance = this;

    // Unsafe because SomeOtherClass might save the "this" reference
    // where another thread could see it
    SomeOtherClass.registerObject(this);

    // Unsafe because set is globally visible 
    set.add(this);

    // Unsafe because we are publishing a reference to mySet
    mySet.add(this);
    SomeOtherClass.someMethod(mySet);

    // Unsafe because the "this" object will be visible from the new
    // thread before the constructor completes
    thread = new MyThread(this);
    thread.start();
  }

  public Unsafe(Collection c) {
    // Unsafe because "c" may be visible from other threads
    c.add(this);
  }
  public void start() {
    thread.start();
  }

  private class MyThread extends Thread {
    private Object theObject;

    public MyThread(Object o) { 
      this.theObject = o;
    }

//    ...
  }
}
// The best strategy is to avoid using the this reference at all (directly or indirectly) in constructors
// For example, when thread A starts thread B, the Java Language Specification (JLS) guarantees that all variables that were visible to thread A when it starts thread B are visible to thread B, which is effectively like having an implicit synchronization in Thread.start(). If we start a thread from within a constructor, the object under construction is not completely constructed, and so we lose these visibility guarantees.
//To prevent this hazard, try to avoid using this, creating instances of inner classes, or starting threads from constructors

