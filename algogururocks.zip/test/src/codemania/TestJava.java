/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;

/**
 *
 * @author sony
 */
public class TestJava {
    TestJava(){
        super();
    }
    public static void main(String[] args){
        int a=20;
        final int b=20;
       final short s=(short)a;
        byte b1=b;//byte range -127 to 128
        //b1=a;
        b1 = (byte)127;
        
        int[]arr=new int[50];
        arr[a]=a=2;
    }
}
