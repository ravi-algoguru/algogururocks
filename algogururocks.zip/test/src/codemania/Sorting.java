/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;

/**
 *
 * @author sony
 */
public class Sorting {

    public static void main(String[] args) {
        int[] arr = {10, 52, 23, 26, 56, 98, 12, 32, 54, 89};
        for (int num : arr) {
            System.out.print(num + ",");
        }
        Sorting sort = new Sorting();
        //sort.CombSort11Algorithm(arr);
        sort.heapSort(arr);
        System.out.println("");
        for (int num : arr) {
            System.out.print(num + ",");
        }
    }

    public void heapSort(int[] a) {
        System.out.print("\n ******heap Sort********** \n");
        int end = a.length - 1;
        // Establish the heap property.
        for (int i = end / 2; i >= 1; i--) {
            System.out.println("\n \n root " + i + " ,end " + end + " ,key " + a[i]);
            fixHeap(a, i, end, a[i]);
            for (int num : a) {
                System.out.print(num + ",");
            }
        }
        // Now place the largest element last,
        // 2nd largest 2nd last, etc.
        for (int i = end; i > 1; i--) {
            // a[1] is the next-biggest element.
            swap(a, 1, i);
            // Heap shrinks by 1 element.
            fixHeap(a, 1, i - 1, a[1]);
        }
    }

    /**
     * Assuming that the partial order tree property holds for all descendants
     * of the element at the root, make the property hold for the root also.
     *
     * @param root the index of the root of the current subtree
     * @param end the highest index of the heap
     */
    private void fixHeap(int[] a, int root, int end, int key) {
        int child = 2 * root; // left child
        // Find the larger child.
        if (child < end && a[child] < a[child + 1]) {
            child++;  // right cBhild is larger
        }
        // If the larger child is larger than the
        // element at the root, move the larger child
        // to the root and filter the former root 
        // element down into the "larger" subtree.
        if (child <= end && key < a[child]) {
            a[root] = a[child];
            System.out.println("\n root : " + a[root]);
            for (int num : a) {
                System.out.print(num + ",");
            }
            fixHeap(a, child, end, key);
        } else {
            a[root] = key;
            System.out.println("\n root : " + a[root]);
            for (int num : a) {
                System.out.print(num + ",");
            }
        }
    }

    /**
     * Swaps two entries of the array.
     */
    private void swap(int[] a, int i, int j) {
        int temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    public void CombSort11Algorithm(int[] a) {
        System.out.print("\n ******Comb Sort********** \n");

        final float SHRINKFACTOR = (float) 1.3;

        boolean flipped = false;
        int gap, top;
        int i, j;

        gap = a.length;
        do {
            System.out.print("\n gap " + gap + " :");
            gap = (int) ((float) gap / SHRINKFACTOR);

            switch (gap) {
                case 0: /* the smallest gap is 1 - bubble sort */
                    gap = 1;
                    break;
                case 9: /* this is what makes this Combsort11 */
                case 10:
                    gap = 11;
                    break;
                default:
                    break;
            }
            //flipped = false;
            top = a.length - gap;
            for (i = 0; i < top; i++) {
                System.out.print("\n gap " + gap + " : index  " + i + " top " + top + "     ");

                j = i + gap;
                if (a[i] > a[j]) {
                    System.out.println("\n swaping " + a[i] + " with " + a[j]);
                    int T = a[i];
                    a[i] = a[j];
                    a[j] = T;
                    // flipped = true;
                    for (int num : a) {
                        System.out.print(num + ",");
                    }
                }
            }
            System.out.println();
            for (int num : a) {
                System.out.print(num + ",");
            }

        } while ((gap > 1));
        /* like the bubble and shell sorts we check for a clean pass */
    }
}
