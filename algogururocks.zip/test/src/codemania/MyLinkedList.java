/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;

/**
 *
 * @author sony
 */
class LNode {

    LNode next;
    int data;

    LNode(int data) {
        this.data = data;
    }
}

public class MyLinkedList {

    LNode head;

    public MyLinkedList() {
        head = null;
    }

    public LNode reverse(LNode node){
      //  LNode node = head;
        LNode ahead ,current, previous = null;
        while(node != null){
            current = node;
            ahead = node.next;
            node.next = previous;
            previous = node;
            node = ahead;      
        }
        return previous;
    }
    
    public LNode reversePairs(LNode node) {
        LNode first = node, second = first.next, third = second.next;
        if (first == null || second == null) {
            return node;
        }
        node = second;
        while (first != null && second != null) {
            second.next = first;
            if (third.next == null) {
                first.next = third;
            } else {
                first.next = third.next;
            }
            first = third;
            second = first.next;
            if (second == null) {
                return node;
            }
            third = second.next;
        }
        return node;
    }

    public static void main(String[] str1) {
        MyLinkedList list = new MyLinkedList();
        int i = 1;
        while (i < 10) {
            list.insert(i++);
        }
        list.display();

//        System.out.println("\n reverse list \n");
//        list.reverse();
//        System.out.println("\n iterative reverse list \n");
//        list.iterative_reverse();
//        list.display();
        System.out.println("\n paired swap list \n");
        // list.pairSwap_iterative(list.head);
        list.head = list.reverse(list.head);
        //list.head = list.pairSwap(list.head);

        //        list.head=list.reversePairsSLL(list.head);
        list.display();
    }

    public void insert(int data) {
        if (head == null) {
            head = new LNode(data);
            return;
        }
        insert(head, data);
    }

    private void insert(LNode node, int data) {

        while (node.next != null) {
            node = node.next;
        }
        node.next = new LNode(data);

    }

    public void display() {
        System.out.println("\n");

        if (head == null) {
            System.out.println("empty list");
            return;
        }
        LNode node = head;
        while (node != null) {
            System.out.print("," + node.data);
            node = node.next;
        }
    }

 
    public LNode iterative_reverse() {
        if (head == null) {
            System.out.print("empty list");
            return null;
        }
        head = iterative_reverse(head);
        return head;
    }

    private LNode iterative_reverse(LNode node) {
        LNode forwardLink = null;
        LNode backwardLink = null;
        while (node != null) {
            forwardLink = node.next;
            node.next = backwardLink;
            backwardLink = node;
            node = forwardLink;
        }
        return backwardLink;
    }

    public LNode pairSwap(LNode node) {
        if (node == null) {
            return null;
        }
        if (node.next == null) {
            return node;
        }
        LNode first = node;
        LNode second = node.next;
        LNode third = second.next;
        node = second;
        while (first != null && second != null) {
            second.next = first;
            if(third==null){
                first.next=null;
                break;
            }
            if (third.next == null) {
                first.next = third;
            } else {
                first.next = third.next;
            }
            first = third;
            second = first.next;
            if (second == null) {
                return node;
            }
            third = second.next;
        }
        return node;
    }
}