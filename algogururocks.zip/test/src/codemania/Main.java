/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;

/**
 *
 * @author sony
 */
import java.applet.*;
import java.awt.*;

/*
 * This file contains the source code for a Java applet/application that
 * runs a variety of Java language construct benchmarks.  The resulting
 * output can be run as an applet or as a Java application.  The code below
 * is sparsely documented, but it also isn't very complicated.  There is a
 * _lot_ of copying that could be replaced with calls to a common function,
 * but I was unclear as to how this would impact the tests I was trying
 * to run.  The goal wasn't to produce well factored code (or even maintainable),
 * but to produce code that measured what I wanted to measure.
 *
 * The applet/application only uses JDK 1.0 constructs, so should run with
 * most non-buggy Java implementations.
 */

/*
 * The Main class that holds the init() and main() methods.
 */
public class Main extends Applet
{
    public static void main (String[] args)
    {
        new MainFrame().show();   
    }
    
    public void init()
    {
        new MainFrame().show();   
    }
}

/*
 * This class provides the GUI for the applet/application.
 */
class MainFrame extends Frame
{
    private Panel  buttonPanel = new Panel();
    private Button callButton = new Button ("Method Calls");
    private Button objectButton = new Button ("Object Creation");
    private Button castButton = new Button ("Cast Operations");
    private Button arrayButton = new Button ("Arrays");
    private Button monitorButton = new Button ("Synchronization");
    private Button clearButton = new Button ("Clear");

    private Button allButton = new Button ("All");
    private Checkbox  useAWTThread = new Checkbox ("Use AWT Thread");
    private TextArea  resultsField = new TextArea();
    private TextField statusField = new TextField();
    
    public MainFrame ()
    {
        super ("Java Speed Tester V1.00");
        
        statusField.setEditable (false);
        resultsField.setEditable (false);
        
        setLayout (new BorderLayout ());
        setBackground (Color.lightGray);
        
        Panel westPanel = new Panel();
        westPanel.setLayout (new BorderLayout ());
        buttonPanel.setLayout (new GridLayout (7, 1));
        westPanel.add ("North", buttonPanel);
            buttonPanel.add (callButton);
            buttonPanel.add (objectButton);
            buttonPanel.add (monitorButton);
            buttonPanel.add (castButton);
            buttonPanel.add (arrayButton);
            buttonPanel.add (allButton);            
            buttonPanel.add (clearButton);
        westPanel.add ("South", useAWTThread);
        add ("West", westPanel);
        
        add ("Center", resultsField);
        add ("South", statusField);
        pack();
    }
    
    public void disableButtons()
    {
        Component[] components = buttonPanel.getComponents();
        for (int i = 0; i < components.length; ++i)
            components[i].disable ();
    }
    
    public void enableButtons ()
    {
        Component[] components = buttonPanel.getComponents();
        for (int i = 0; i < components.length; ++i)
            components[i].enable ();
    }
    
    /**
     * Event handling loop function for the main Frame GUI.
     * We use this instead of the JDK1.1 event model so that
     * earlier JVM/JITs can be tested.
     */
    public boolean handleEvent (Event event)
    {
        if (event.id == Event.WINDOW_DESTROY)
        {
            hide();
            dispose();
            System.exit(0);
            return true;
        }
        else if (event.id == Event.ACTION_EVENT)
        {
            if (event.target == callButton)
            {
                WorkerThread wt = new WorkerThread (statusField, resultsField, this, WorkerThread.CALL_TEST);
                if (useAWTThread.getState() == true)
                    wt.run();
                else                
                    wt.start();
                    
                return true;
            }
            else if (event.target == objectButton)
            {
                WorkerThread wt = new WorkerThread (statusField, resultsField, this, WorkerThread.OBJECT_TEST);
                if (useAWTThread.getState() == true)
                    wt.run();
                else                
                    wt.start();
                    
                return true;
            }
            else if (event.target == castButton)
            {
                WorkerThread wt = new WorkerThread (statusField, resultsField, this, WorkerThread.CAST_TEST);
                if (useAWTThread.getState() == true)
                    wt.run();
                else                
                    wt.start();
                    
                return true;
            }
            else if (event.target == arrayButton)
            {
                WorkerThread wt = new WorkerThread (statusField, resultsField, this, WorkerThread.ARRAY_TEST);
                if (useAWTThread.getState() == true)
                    wt.run();
                else                
                    wt.start();
                    
                return true;                
            }
            else if (event.target == monitorButton)
            {
                WorkerThread wt = new WorkerThread (statusField, resultsField, this, WorkerThread.MONITOR_TEST);
                if (useAWTThread.getState() == true)
                    wt.run();
                else                
                    wt.start();
                    
                return true;
            }
            else if (event.target == allButton)
            {
                WorkerThread wt = new WorkerThread (statusField, resultsField, this, WorkerThread.ALL_TESTS);
                if (useAWTThread.getState() == true)
                    wt.run();
                else                
                    wt.start();
                    
                return true;
            }
            else if (event.target == clearButton)
            {
                resultsField.setText ("");
            }
        }

		return super.handleEvent(event);        
    }
}

/*
 * This class gives you the option of _not_ hanging the GUI
 * while running the tests.
 */
class WorkerThread extends Thread
{
    // Each of these corresponds to one of the tests.
    //
    public static final int CALL_TEST      = 0;
    public static final int OBJECT_TEST    = 1;
    public static final int MONITOR_TEST   = 2;
    public static final int ARRAY_TEST     = 3;
    public static final int CAST_TEST      = 4;
    public static final int ALL_TESTS      = 100;
    
    private TextField statusField;
    private TextArea  resultsField;
    private MainFrame mainFrame;
    private int       test;
    
    public WorkerThread (TextField statusField,
                         TextArea  resultsField,
                         MainFrame mainFrame,
                         int test)
    {
        this.statusField  = statusField;
        this.resultsField = resultsField;
        this.mainFrame    = mainFrame;
        this.test         = test;
    }
    
    public void run ()
    {
        try
        {
            mainFrame.disableButtons();
            
            switch (test)
            {
                case CALL_TEST:
                    CallTest ct = new CallTest ("Method Call Test",
                                                 statusField,
                                                 resultsField);
                    ct.runTest();            
                    break;
                
                case OBJECT_TEST:
                    ObjectTest ot = new ObjectTest ("Object Creation Test",
                                                     statusField,
                                                     resultsField);
                    ot.runTest();            
                    break;
                    
                case MONITOR_TEST:
                    MonitorTest mt = new MonitorTest ("Monitor Cost Test",
                                                     statusField,
                                                     resultsField);
                    mt.runTest();            
                    break;
                    
                case ARRAY_TEST:
                    ArrayTest at = new ArrayTest ("Array Test",
                                                   statusField,
                                                   resultsField);
                    at.runTest();            
                    break;                
                    
                case CAST_TEST:
                    CastTest ct2 = new CastTest ("Cast Test",
                                                 statusField,
                                                 resultsField);
                    ct2.runTest();
                    break;

                case ALL_TESTS:
                    new ArrayTest   ("Array Test",           statusField, resultsField).runTest();
                    new CallTest    ("Method Call Test",     statusField, resultsField).runTest();
                    new ObjectTest  ("Object Creation Test", statusField, resultsField).runTest();
                    new MonitorTest ("Monitor Cost Test",    statusField, resultsField).runTest();
                    new CastTest    ("Cast Test",            statusField, resultsField).runTest();
                    break;
            }
        }
        finally
        {
            mainFrame.enableButtons();
        }
    }    
}

/*
 * All test inherit from this class.
 *
 * It provides a common runTest method, methods to output the results,
 * and code to calculate loop overhead.
 */
abstract class Test
{
    private String name;
    private TextField status;
    private TextArea output;
    
    public Test (String name, TextField status, TextArea output)
    {
        this.name = name;
        this.status = status;
        this.output = output;
    }
    
    public void runTest ()
    {
        try
        {
            status.setText ("Running " + name + " ...");
//            output.setText ("");
            runImpl ();
        }
        finally
        {
            status.setText ("Ready");
        }
    }
    
    protected void print (String text)
    {
        output.appendText (text);
        System.out.print (text);
    }

    protected void println (String text)
    {
        output.appendText (text + "\n");    
        System.out.println (text);
    }
    
    protected void setStatus (String text)
    {
        status.setText (text);
    }
    
    // The code below calculates loop overhead.  I don't want to
    // penalize the method calls on a given platform because the
    // loop construct runs slowly.
    //
    // We use two iteration counts because we want the largest
    // baseline possible without boring the users to death.  Non-JIT
    // machines run to slowly with the LOOP_ITERATIONS value.
    //
    static protected final int LOOP_ITERATIONS_SHORT = 10000000;
    
    static protected final int LOOP_ITERATIONS = 1000000000;
    static protected int loopOverhead;
    static protected boolean isLoopOverheadCalculated = false;
    
    private int calculateLoopOverheadFast ()
    {
        long t1 = System.currentTimeMillis ();
        
        for (int i = 0; i < LOOP_ITERATIONS_SHORT; ++i)
        {
            Helper.foo();
            Helper.foo2();
        }
        
        long t2 = System.currentTimeMillis();
        
        for (int i = 0; i < LOOP_ITERATIONS_SHORT; ++i)
        {
            Helper.foo();
        }
        
        long t3 = System.currentTimeMillis();
                
        long loopPlusTwoCalls = (t2 - t1);
        long twoLoopsPlusTwoCalls = (t3 - t2) * 2;
        
        return (int)(twoLoopsPlusTwoCalls - loopPlusTwoCalls);                
    }

    private int calculateLoopOverheadSlow ()
    {
        long t1 = System.currentTimeMillis ();
        
        for (int i = 0; i < LOOP_ITERATIONS; ++i)
        {
            Helper.foo();
            Helper.foo2();
        }
        
        long t2 = System.currentTimeMillis();
        
        for (int i = 0; i < LOOP_ITERATIONS; ++i)
        {
            Helper.foo();
        }
        
        long t3 = System.currentTimeMillis();
                
        long loopPlusTwoCalls = (t2 - t1);
        long twoLoopsPlusTwoCalls = (t3 - t2) * 2;
        
        return (int)(twoLoopsPlusTwoCalls - loopPlusTwoCalls);                
    }
    
    protected double calculateLoopOverhead (int iterations)
    {
        synchronized (Test.class)
        {
            if (isLoopOverheadCalculated == false)
            {
                println ("Calculating loop overhead.  This may take a while...");

                // We do this because the long version takes forever on
                // non-JITed systems.
                int fast = calculateLoopOverheadFast();

                System.out.println (fast);

                if (fast > 2000)
                {
                    loopOverhead = fast * 100;
                    isLoopOverheadCalculated = true;
                }
                else
                {
                    int slow = calculateLoopOverheadSlow();
                    loopOverhead = slow;
                    isLoopOverheadCalculated = true;
                }        
            }
        }
        
        return (loopOverhead * iterations)/LOOP_ITERATIONS;
    }
    
    
    protected abstract void runImpl ();
}

class Helper
{
    static void foo() {}
    static void foo2() {}
}

//
//
// Object Creation (and collection) Test.  The classes below implement
// the object creation tests.
//
//

/*
 * This class _runs_ the object creation test.  Most of the
 * test______ methods look very much alike.
 */
class ObjectTest extends Test
{
    // We use a shorter loop for the big objects to keep from paging.
    //
    private static final int OBJECTS_TO_CREATE = 1000000;
    private static final int BIG_OBJECTS_TO_CREATE = 100000;
    
    public ObjectTest (String name, TextField status, TextArea output)
    {
        super (name, status, output);   
    }
    
    protected void runImpl ()
    {
        calculateLoopOverhead(100000);
        println ("OBJECT CREATION");        
                
        testEmptyObject();
        testIntObjectFree();
        testInitializedIntObjectFree();

        println (""); 
        println ("Java has no notion of 'containment' in the C++ sense.");
        println ("This test builds an object with sub-objects to see how");
        println ("the sub-objects impact object creation time.");
        testComplexObject();        
        
        println (""); 
        println ("Each test below allocates an uninitialized object slightly");
        println ("larger than the one before it.  This measures the effect of");
        println ("object size on object creation time.");
        println ("----------------------------------------------------");
        testIntObject();
        testUnInitializedBig02IntObject();
        testUnInitializedBig05IntObject();
        testUnInitializedBig10IntObject();
        
        println (""); 
        println ("Each test below allocates an initialized object slightly");
        println ("larger than the one before it.  This measures the effect of");
        println ("object size on object creation time.");
        println ("----------------------------------------------------");
        testInitializedIntObject();        
        testInitializedBig02IntObject();
        testInitializedBig03IntObject();
        testInitializedBig04IntObject();
        testInitializedBig05IntObject();
        testInitializedBig06IntObject();
        testInitializedBig07IntObject();
        testInitializedBig08IntObject();
        testInitializedBig09IntObject();
        testInitializedBig10IntObject();
        testInitializedBig11IntObject();
        testInitializedBig12IntObject();
        testInitializedBig13IntObject();
        testInitializedBig14IntObject();
        testInitializedBig15IntObject();
        testInitializedBig16IntObject();
        testInitializedBig17IntObject();
        testInitializedBig18IntObject();
        testInitializedBig19IntObject();
        testInitializedBig20IntObject();
        testInitializedBig21IntObject();
        testInitializedBig22IntObject();
        testInitializedBig23IntObject();
        testInitializedBig24IntObject();
        testInitializedBig25IntObject();
        testInitializedBig26IntObject();
        println (""); 
        testInitializedIntObjectInChunks();        
        println (""); 
    }
    
    protected void testEmptyObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;

        double loopOverhead = calculateLoopOverhead(OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an empty object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < OBJECTS_TO_CREATE; ++i)
                dummy = new EmptyObject();
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);

        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + microSecondsPerOperation + " microseconds.");
    }
    
    protected void testIntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;

        double loopOverhead = calculateLoopOverhead(OBJECTS_TO_CREATE);        
        
        print ("Creating, but not freeing, an 'uninitialized int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < OBJECTS_TO_CREATE; ++i)
                dummy = new IntObject();
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    
    
    protected void testIntObjectFree()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(OBJECTS_TO_CREATE);
        
        print ("Creating, and freeing, an 'int' object takes ... ");
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < OBJECTS_TO_CREATE; ++i)
                dummy = new IntObject();
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
//            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    
    
    protected void testInitializedIntObjectFree()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(OBJECTS_TO_CREATE);
        
        print ("Creating, and freeing, an 'initialized int' object takes ... ");
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < OBJECTS_TO_CREATE; ++i)
                new IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }
    
    protected void testInitializedIntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }
    
    protected void testInitializedBig02IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 2 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big02IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig03IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 3 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big03IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig04IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 4 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big04IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig05IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 5 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big05IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig06IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 6 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big06IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig07IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 7 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big07IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig08IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 8 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big08IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig09IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 9 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big09IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig10IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 10 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big10IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig11IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 11 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big11IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig12IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 12 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big12IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig13IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 13 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big13IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig14IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 14 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big14IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig15IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 15 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big15IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig16IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 16 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big16IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig17IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 17 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big17IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig18IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 18 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big18IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig19IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 19 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big19IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig20IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 20 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big20IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig21IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 21 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big21IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig22IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 22 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big22IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig23IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 23 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big23IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    } 

    protected void testInitializedBig24IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 24 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big24IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testInitializedBig25IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 25 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big25IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }
    
    protected void testInitializedBig26IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'initialized 26 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new Big26IntObject(i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    } 

    Object dummy;
    
    protected void testUnInitializedBig02IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'uninitialized 2 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < OBJECTS_TO_CREATE; ++i)
                dummy = new Big02IntObject();
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testUnInitializedBig05IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'uninitialized 5 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
            {
                dummy = new Big05IntObject();
//                Big05IntObject b = new Big05IntObject();
//                b.set (i);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testUnInitializedBig10IntObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, an 'uninitialized 10 int' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                dummy = new Big10IntObject();
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    

    protected void testComplexObject()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);
        
        print ("Creating, but not freeing, a 'complex' object takes ... ");
        do
        {
            // We're only testing object creation for now...
            System.gc();
            
            long startTime = System.currentTimeMillis ();
        
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new ComplexObject(i, i);
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime += (endTime - startTime);
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");
    }    
    
    protected void testInitializedIntObjectInChunks()
    {
        int iterations = 0;
        long cumulativeTime   = 0;
        long cumulativeTime_A = 0;
        long cumulativeTime_B = 0;
        long cumulativeTime_C = 0;
        long cumulativeTime_D = 0;
        long cumulativeTime_E = 0;
        
        double loopOverhead = calculateLoopOverhead(BIG_OBJECTS_TO_CREATE);

        println ("This shows whether the size or number of objects");
        println ("on the heap effects object creation time.");
        println ("----------------------------------------------------");        
        do
        {
            // We're only testing object creation for now...
            System.gc();
            long startTime;
            long endTime;
            
            startTime = System.currentTimeMillis ();
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new IntObject(i);
            endTime = System.currentTimeMillis();
            cumulativeTime_A += (endTime - startTime);
            
            startTime = System.currentTimeMillis ();
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new IntObject(i);
            endTime = System.currentTimeMillis();
            cumulativeTime_B += (endTime - startTime);
            
            startTime = System.currentTimeMillis ();
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new IntObject(i);
            endTime = System.currentTimeMillis();
            cumulativeTime_C += (endTime - startTime);
            
            startTime = System.currentTimeMillis ();
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new IntObject(i);
            endTime = System.currentTimeMillis();
            cumulativeTime_D += (endTime - startTime);

            startTime = System.currentTimeMillis ();
            for (int i = 0; i < BIG_OBJECTS_TO_CREATE; ++i)
                new IntObject(i);
            endTime = System.currentTimeMillis();
            cumulativeTime_E += (endTime - startTime);

            
            cumulativeTime = cumulativeTime_A +
                             cumulativeTime_B +
                             cumulativeTime_C +
                             cumulativeTime_D +
                             cumulativeTime_E;
            
            ++iterations;
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
        } while (cumulativeTime < 10000);
        
        cumulativeTime_A -= (long)(loopOverhead * iterations);
        cumulativeTime_B -= (long)(loopOverhead * iterations);
        cumulativeTime_C -= (long)(loopOverhead * iterations);
        cumulativeTime_D -= (long)(loopOverhead * iterations);
        cumulativeTime_E -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation;
        double truncated;
        
        microSecondsPerOperation = ( (cumulativeTime_A) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);
        truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;        
        println ("    First chunk (" + (BIG_OBJECTS_TO_CREATE * 4) + " bytes) allocated each object in " + truncated + " microseconds.");
        
        microSecondsPerOperation = ( (cumulativeTime_B) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);
        truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;        
        println ("    Second chunk (" + (BIG_OBJECTS_TO_CREATE * 4) + " bytes) allocated each object in " + truncated + " microseconds.");

        microSecondsPerOperation = ( (cumulativeTime_C) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);
        truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;        
        println ("    Third chunk (" + (BIG_OBJECTS_TO_CREATE * 4) + " bytes) allocated each object in " + truncated + " microseconds.");

        microSecondsPerOperation = ( (cumulativeTime_D) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);
        truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;        
        println ("    Fourth chunk (" + (BIG_OBJECTS_TO_CREATE * 4) + " bytes) allocated each object in " + truncated + " microseconds.");

        microSecondsPerOperation = ( (cumulativeTime_E) * 1000.0) / ((double)iterations * BIG_OBJECTS_TO_CREATE);
        truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;        
        println ("    Fifth chunk (" + (BIG_OBJECTS_TO_CREATE * 4) + " bytes) allocated each object in " + truncated + " microseconds.");
    }    
}





class EmptyObject
{
}

class IntObject
{
    private int i;
    
    public IntObject ()
    {
    }
    
    public IntObject (int i)
    {
        this.i = i;
    }
}

class ObjectObject
{
    private Object o;
}

class LongObject
{
    private long l;
}

class Big02IntObject
{
    int a;
    int b;

    public Big02IntObject ()
    {
    }
    
    public Big02IntObject(int value)
    {
        a = value;
        b = value;
    }
}

class Big03IntObject
{
    int a;
    int b;
    int c;

    public Big03IntObject ()
    {
    }
    
    public Big03IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
    }
}

class Big04IntObject
{
    int a;
    int b;
    int c;
    int d;

    public Big04IntObject ()
    {
    }
    
    public Big04IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
    }
}

class Big05IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;

    public Big05IntObject ()
    {
    }
    
    public void set (int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
    }
    
    public Big05IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
    }
}

class Big06IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;

    public Big06IntObject ()
    {
    }
    
    public Big06IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
    }
}

class Big07IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;

    public Big07IntObject ()
    {
    }
    
    public Big07IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
    }
}

class Big08IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;

    public Big08IntObject ()
    {
    }
    
    public Big08IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
    }
}

class Big09IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;

    public Big09IntObject ()
    {
    }
    
    public Big09IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
    }
}

class Big10IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;

    public Big10IntObject ()
    {
    }
    
    public Big10IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
    }
}

class Big11IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;

    public Big11IntObject ()
    {
    }
    
    public Big11IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
    }
}

class Big12IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;

    public Big12IntObject ()
    {
    }
    
    public Big12IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
    }
}

class Big13IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;

    public Big13IntObject ()
    {
    }
    
    public Big13IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
        m = value;
    }
}

class Big14IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;

    public Big14IntObject ()
    {
    }
    
    public Big14IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
        m = value;
        n = value;
    }
}

class Big15IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;
    int o;

    public Big15IntObject ()
    {
    }
    
    public Big15IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
        m = value;
        n = value;
        o = value;
    }
}

class Big16IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;
    int o;
    int p;

    public Big16IntObject ()
    {
    }
    
    public Big16IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
        m = value;
        n = value;
        o = value;
        p = value;
    }
}

class Big17IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;
    int o;
    int p;
    int q;

    public Big17IntObject ()
    {
    }
    
    public Big17IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
        m = value;
        n = value;
        o = value;
        p = value;
        q = value;
    }
}

class Big18IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;
    int o;
    int p;
    int q;
    int r;

    public Big18IntObject ()
    {
    }
    
    public Big18IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
        m = value;
        n = value;
        o = value;
        p = value;
        q = value;
        r = value;
    }
}

class Big19IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;
    int o;
    int p;
    int q;
    int r;
    int s;

    public Big19IntObject ()
    {
    }
    
    public Big19IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
        m = value;
        n = value;
        o = value;
        p = value;
        q = value;
        r = value;
        s = value;
    }
}

class Big20IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;
    int o;
    int p;
    int q;
    int r;
    int s;
    int t;

    public Big20IntObject ()
    {
    }
    
    public Big20IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
        m = value;
        n = value;
        o = value;
        p = value;
        q = value;
        r = value;
        s = value;
        t = value;
    }
}
class Big21IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;
    int o;
    int p;
    int q;
    int r;
    int s;
    int t;
    int u;

    public Big21IntObject ()
    {
    }
    
    public Big21IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
        m = value;
        n = value;
        o = value;
        p = value;
        q = value;
        r = value;
        s = value;
        t = value;
        u = value;
    }
}
class Big22IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;
    int o;
    int p;
    int q;
    int r;
    int s;
    int t;
    int u;
    int v;

    public Big22IntObject ()
    {
    }
    
    public Big22IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
        m = value;
        n = value;
        o = value;
        p = value;
        q = value;
        r = value;
        s = value;
        t = value;
        u = value;
        v = value;
    }
}

class Big23IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;
    int o;
    int p;
    int q;
    int r;
    int s;
    int t;
    int u;
    int v;
    int w;

    public Big23IntObject ()
    {
    }
    
    public Big23IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
        m = value;
        n = value;
        o = value;
        p = value;
        q = value;
        r = value;
        s = value;
        t = value;
        u = value;
        v = value;
        w = value;
    }
}

class Big24IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;
    int o;
    int p;
    int q;
    int r;
    int s;
    int t;
    int u;
    int v;
    int w;
    int x;

    public Big24IntObject ()
    {
    }
    
    public Big24IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
        m = value;
        n = value;
        o = value;
        p = value;
        q = value;
        r = value;
        s = value;
        t = value;
        u = value;
        v = value;
        w = value;
        x = value;
    }
}

class Big25IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;
    int o;
    int p;
    int q;
    int r;
    int s;
    int t;
    int u;
    int v;
    int w;
    int x;
    int y;

    public Big25IntObject ()
    {
    }
    
    public Big25IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
        m = value;
        n = value;
        o = value;
        p = value;
        q = value;
        r = value;
        s = value;
        t = value;
        u = value;
        v = value;
        w = value;
        x = value;
        y = value;
    }
}

class Big26IntObject
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;
    int o;
    int p;
    int q;
    int r;
    int s;
    int t;
    int u;
    int v;
    int w;
    int x;
    int y;
    int z;

    public Big26IntObject ()
    {
    }
    
    public Big26IntObject(int value)
    {
        a = value;
        b = value;
        c = value;
        d = value;
        e = value;
        f = value;
        g = value;
        h = value;
        i = value;
        j = value;
        k = value;
        l = value;
        m = value;
        n = value;
        o = value;
        p = value;
        q = value;
        r = value;
        s = value;
        t = value;
        u = value;
        v = value;
        w = value;
        x = value;
        y = value;
        z = value;
    }
}

class ComplexObject
{
    Integer i;
    IntObject i2;
    IntObject i3;
    Big02IntObject i4;
    
    ComplexObject (int a, int b)
    {
        i = new Integer (a);
        i2 = new IntObject (b);
        i3 = new IntObject();
        i4 = new Big02IntObject (a);
    }
}

//
//
// Call Test Code.  The pattern should be obvious.
//
//


class CallTest extends Test
{
    private static final int CALLS_TO_MAKE = 1000000;
    
    public CallTest (String name, TextField status, TextArea output)
    {
        super (name, status, output);   
    }
    
    protected void runImpl ()
    {
        calculateLoopOverhead(100000);
        println ("METHOD CALLS");        

        println ("");
        println ("Look at the costs of some basic method calls.  Consider");
        println ("things like final versus non-final, static versus non-static");
        println ("and various return types.");
        println ("----------------------------------------------------");                
        testStaticVoidMethod();
        testVirtualVoidMethod();
        testFinalVoidMethod();
        testVirtualIntMethod();
        testVirtualLongMethod();
        testVirtualFloatMethod();
        testVirtualDoubleMethod();

        println ("");
        println ("Now look at the cost of adding parameters.");
        println ("----------------------------------------------------");                
        testVirtualVoidMethod();
        testVirtualVoidMethod1IntArg(1);
        testVirtualVoidMethod2IntArgs(1, 2);
        testVirtualVoidMethod3IntArgs(1, 2, 3);        
        testVirtualVoidMethod4IntArgs(1, 2, 3, 4);
        testVirtualVoidMethod5IntArgs(1, 2, 3, 4, 5);
        testVirtualVoidMethod6IntArgs(1, 2, 3, 4, 5, 6);
        testVirtualVoidMethod7IntArgs(1, 2, 3, 4, 5, 6, 7);
        testVirtualVoidMethod8IntArgs(1, 2, 3, 4, 5, 6, 7, 8);
        testVirtualVoidMethod9IntArgs(1, 2, 3, 4, 5, 6, 7, 8, 9);
        testVirtualVoidMethod10IntArgs(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        
        println ("");
        println ("Now look at the cost of a try/catch block");
        testVirtualVoidMethod();        
        testThrowVirtualVoidMethod(new ObjectToCall());
        
        println ("");
    }
    
    protected void testStaticVoidMethod()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a 'static void f()' method takes ... ");        
        
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                ObjectToCall.staticVoidMethod();
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    protected void testVirtualVoidMethod()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a 'void f()' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedVirtualVoidMethod();
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }

    // Pass in the object so that the compiler and runtime _must_
    // set up the try/catch.
    protected void testThrowVirtualVoidMethod(ObjectToCall objectToCall)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a 'void f()' method and setting up a try/catch block takes ... ");        
        
        System.gc();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                try
                {
                    objectToCall.unsynchronizedThrowVirtualVoidMethod();
                }
                catch (Exception e)
                {
                }
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    protected void testFinalVoidMethod()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a 'final void f()' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedFinalVoidMethod();
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    protected void testVirtualIntMethod()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling an 'int f()' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedVirtualIntMethod();
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }    
    
    protected void testVirtualLongMethod()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling an 'long f()' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedVirtualLongMethod();
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }    

    protected void testVirtualFloatMethod()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling an 'float f()' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedVirtualFloatMethod();
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }    
    
    protected void testVirtualDoubleMethod()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling an 'double f()' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedVirtualDoubleMethod();
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }

    protected void testVirtualVoidMethod1IntArg(int a)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a 'void f(int a)' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedVirtualVoidMethod1IntArg(a);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    protected void testVirtualVoidMethod2IntArgs(int a, int b)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a 'void f(int a, int b)' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedVirtualVoidMethod2IntArgs(a, b);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }

    protected void testVirtualVoidMethod3IntArgs(int a, int b, int c)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a 'void f(int a, int b, int c)' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedVirtualVoidMethod3IntArgs(a, b, c);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }

    protected void testVirtualVoidMethod4IntArgs(int a, int b, int c, int d)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a 'void f(int a, ..., int d)' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedVirtualVoidMethod4IntArgs(a, b, c, d);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    protected void testVirtualVoidMethod5IntArgs(int a, int b, int c, int d, int e)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a 'void f(int a, ..., int e)' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedVirtualVoidMethod5IntArgs(a, b, c, d, e);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    protected void testVirtualVoidMethod6IntArgs(int a, int b, int c, int d, int e, int f)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a 'void f(int a, ..., int f)' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedVirtualVoidMethod6IntArgs(a, b, c, d, e, f);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }

    protected void testVirtualVoidMethod7IntArgs(int a, int b, int c, int d, int e, int f, int g)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a 'void f(int a, ..., int g)' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedVirtualVoidMethod7IntArgs(a, b, c, d, e, f, g);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }

    protected void testVirtualVoidMethod8IntArgs(int a, int b, int c, int d, int e, int f, int g, int h)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a 'void f(int a, ..., int h)' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedVirtualVoidMethod8IntArgs(a, b, c, d, e, f, g, h);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }

    protected void testVirtualVoidMethod9IntArgs(int a, int b, int c, int d, int e, int f, int g, int h, int i)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a 'void f(int a, ..., int i)' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int index = 0; index < CALLS_TO_MAKE; ++index)
            {
                objectToCall.unsynchronizedVirtualVoidMethod9IntArgs(a, b, c, d, e, f, g, h, i);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }

    protected void testVirtualVoidMethod10IntArgs(int a, int b, int c, int d, int e, int f, int g, int h, int i, int j)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a 'void f(int a, ..., int j)' method takes ... ");        
        
        System.gc();
        ObjectToCall objectToCall = new ObjectToCall();
        
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int index = 0; index < CALLS_TO_MAKE; ++index)
            {
                objectToCall.unsynchronizedVirtualVoidMethod10IntArgs(a, b, c, d, e, f, g, h, i, j);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
}

// We ++count to prevent clever runtimes from optimizing away the entire test.
//
class ObjectToCall
{
    static void staticVoidMethod()
    {
    }
    
    
    private int count;
    long        longCount;
    float       floatCount;
    double      doubleCount;
    
    public synchronized void synchronizedVirtualVoidMethod()
    {
        ++count;
    }

    
    public void unsynchronizedVirtualVoidMethod()
    {
        ++count;
    }

    public void unsynchronizedThrowVirtualVoidMethod() throws Exception
    {
        ++count;
    }
    
    
    public final void unsynchronizedFinalVoidMethod()
    {
        ++count;
    }
    
    public int unsynchronizedVirtualIntMethod()
    {
        ++count;
        return count;
    }
    
    public long unsynchronizedVirtualLongMethod()
    {
        ++count;
        return longCount;
    }
    
    public float unsynchronizedVirtualFloatMethod()
    {
        ++count;
        return floatCount;
    }        

    public double unsynchronizedVirtualDoubleMethod()
    {
        ++count;
        return doubleCount;
    }
    
    
    public void unsynchronizedVirtualVoidMethod1IntArg(int a)
    {
        ++count;
    }

    public void unsynchronizedVirtualVoidMethod2IntArgs(int a, int b)
    {
        ++count;
    }
    
    public void unsynchronizedVirtualVoidMethod3IntArgs(int a, int b, int c)
    {
        ++count;
    }
    
    public void unsynchronizedVirtualVoidMethod4IntArgs(int a, int b, int c, int d)
    {
        ++count;
    }
    
    public void unsynchronizedVirtualVoidMethod5IntArgs(int a, int b, int c, int d, int e)
    {
        ++count;
    }
    
    public void unsynchronizedVirtualVoidMethod6IntArgs(int a, int b, int c, int d, int e, int f)
    {
        ++count;
    }
    
    public void unsynchronizedVirtualVoidMethod7IntArgs(int a, int b, int c, int d, int e, int f, int g)
    {
        ++count;
    }
    
    public void unsynchronizedVirtualVoidMethod8IntArgs(int a, int b, int c, int d, int e, int f, int g, int h)
    {
        ++count;
    }
    
    public void unsynchronizedVirtualVoidMethod9IntArgs(int a, int b, int c, int d, int e, int f, int g, int h, int i)
    {
        ++count;
    }
    
    public void unsynchronizedVirtualVoidMethod10IntArgs(int a, int b, int c, int d, int e, int f, int g, int h, int i, int j)
    {
        ++count;
    }
    
}



//
//
// Monitor Test Code.
//

class MonitorTest extends Test
{
    private static final int CALLS_TO_MAKE = 1000000;
    
    public MonitorTest (String name, TextField status, TextArea output)
    {
        super (name, status, output);   
    }
    
    protected void runImpl ()
    {
        calculateLoopOverhead(100000);
        println ("MONITORS");        
        
        unsynchronizedBaseline();
        testSynchGetAndRelease();
        testMonitorOwned();
        
        println ("");
        
        unsynchronizedStaticBaseline();
        testStaticSynchGetAndRelease();
        testStaticMonitorOwned();
        
        println ("");
    }
    
    protected void unsynchronizedBaseline()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        MonitorObjectToCall objectToCall = new MonitorObjectToCall();
        
        print ("Calling an unsynchronized method (as a baseline) takes ... ");
       
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.unsynchronizedVirtualVoidMethod();
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    protected void testSynchGetAndRelease()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        MonitorObjectToCall objectToCall = new MonitorObjectToCall();
        
        print ("Calling a synchronized method without the monitor takes ... ");
       
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                objectToCall.synchronizedVirtualVoidMethod();
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    protected void testMonitorOwned()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        MonitorObjectToCall objectToCall = new MonitorObjectToCall();
        
        print ("Calling a synchronized method with the monitor takes ... ");
       
        synchronized (objectToCall)
        {
            System.gc();
            long startTime = System.currentTimeMillis ();
            do
            {
                for (int i = 0; i < CALLS_TO_MAKE; ++i)
                {
                    objectToCall.synchronizedVirtualVoidMethod();
                }
            
                long endTime = System.currentTimeMillis();
            
                cumulativeTime = (endTime - startTime);
                ++iterations;
            
                long t1 = System.currentTimeMillis();
                setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
                long t2 = System.currentTimeMillis();
                startTime -= (t2 - t1);
            
            } while (cumulativeTime < 10000);
        
            cumulativeTime -= (long)(loopOverhead * iterations);
        }

        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }    
    
    
    protected void unsynchronizedStaticBaseline()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling an unsynchronized static method (as a baseline) takes ... ");
       
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                MonitorObjectToCall.unsynchronizedStaticVoidMethod();
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    protected void testStaticSynchGetAndRelease()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a static synchronized method without the monitor takes ... ");
       
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                MonitorObjectToCall.synchronizedStaticVoidMethod();
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    protected void testStaticMonitorOwned()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Calling a synchronized method with the monitor takes ... ");
       
        synchronized (MonitorObjectToCall.class)
        {
            System.gc();
            long startTime = System.currentTimeMillis ();
            do
            {
                for (int i = 0; i < CALLS_TO_MAKE; ++i)
                {
                    MonitorObjectToCall.synchronizedStaticVoidMethod();
                }
            
                long endTime = System.currentTimeMillis();
            
                cumulativeTime = (endTime - startTime);
                ++iterations;
            
                long t1 = System.currentTimeMillis();
                setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
                long t2 = System.currentTimeMillis();
                startTime -= (t2 - t1);
            
            } while (cumulativeTime < 10000);
        
            cumulativeTime -= (long)(loopOverhead * iterations);
        }

        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }        
}

class MonitorObjectToCall
{
    static private int staticCount;
    
    static void unsynchronizedStaticVoidMethod()
    {
        ++staticCount;
    }

    static synchronized void synchronizedStaticVoidMethod()
    {
        ++staticCount;
    }
    
    
    private int count;
    
    public synchronized void synchronizedVirtualVoidMethod()
    {
        ++count;
    }
    
    public void unsynchronizedVirtualVoidMethod()
    {
        ++count;
    }
}


//
//
// Cast Operations.
//
//
class CastTest extends Test
{
    private static final int CALLS_TO_MAKE = 1000000;
    
    public CastTest (String name, TextField status, TextArea output)
    {
        super (name, status, output);   
    }
    
    protected void runImpl ()
    {
        calculateLoopOverhead(100000);
        println ("CASTING");                

        // This pre-loading is to get around a bug in
        // a Netscape/Mac version that crashes with a
        // stack overflow when it tries to load too many
        // classes at once.
        try
        {
            Class.forName ("CastHelperInterfaceA");
            Class.forName ("CastHelperInterfaceB");
            Class.forName ("CastHelperInterfaceC");
            Class.forName ("CastHelperInterfaceD");
            Class.forName ("CastHelperInterfaceE");
            Class.forName ("CastHelperInterfaceF");
            Class.forName ("CastHelperInterfaceG");
            Class.forName ("CastHelperInterfaceH");
            Class.forName ("CastHelperInterfaceI");
            Class.forName ("CastHelperInterfaceJ");
            Class.forName ("CastHelperInterfaceK");
            Class.forName ("CastHelperInterfaceL");
            Class.forName ("CastHelperInterfaceM");
            Class.forName ("CastHelperInterfaceN");
            Class.forName ("CastHelperInterfaceO");
            Class.forName ("CastHelperInterfaceP");
            Class.forName ("CastHelperInterfaceQ");
            Class.forName ("CastHelperInterfaceR");
            Class.forName ("CastHelperA");
            Class.forName ("CastHelperB");
            Class.forName ("CastHelperC");
            Class.forName ("CastHelperD");
            Class.forName ("CastHelperE");
            Class.forName ("CastHelperF");
            Class.forName ("CastHelperG");
            Class.forName ("CastHelperH");
            Class.forName ("CastHelperI");
            Class.forName ("CastHelperJ");
            Class.forName ("CastHelperK");
            Class.forName ("CastHelperL");
            Class.forName ("CastHelperM");
            Class.forName ("CastHelperN");
        }
        catch (ClassNotFoundException exception)
        {
            println ("Can't run test because can't load all the classes.");
            return;
        }
        
        downcastBaseling();
        shallowDowncastFromObject();
        deepDowncastFromObject();
        callThrough1stInterface();
        callThrough18thInterface();
        callThrough18thInterfaceTestCaching();

        println ("");
        callThrough1stInterfaceNewObject();
        callThrough18thInterfaceNewObject();
        
        println ("");
    }
    
    private void downcastBaseling ()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        CastHelper objectToCall = new CastHelper(5);
        
        print ("Call without downcast (as a baseline) takes ... ");
       
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                CastHelper2.helper1 (objectToCall);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    private void shallowDowncastFromObject ()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        CastHelper objectToCall = new CastHelper(5);
        
        print ("Call with shallow downcast (from Object) takes ... ");
       
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                CastHelper2.helper2 (objectToCall);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    private void deepDowncastFromObject ()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        CastHelperN objectToCall = new CastHelperN(5);
        
        print ("Call with deep downcast (from Object) takes ... ");
       
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                CastHelper2.helper3 (objectToCall);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    private void callThrough18thInterface ()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        CastHelperN objectToCall = new CastHelperN(5);
        
        print ("Call against 18th interface takes ... ");
       
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                CastHelper2.callThrough18thInterface (objectToCall);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }

    public CastHelperInterfaceH dummy;
    
    private void callThrough18thInterfaceTestCaching ()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        CastHelperN objectToCall = new CastHelperN(5);
        
        print ("Call against 18th interface plus extra cast takes ... ");
        
        
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                CastHelper2.callThrough18thInterface (objectToCall);
                dummy = (CastHelperInterfaceH)objectToCall;
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }

    private void callThrough1stInterfaceNewObject ()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Call against 1st interface with new object each time takes ... ");        
        
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                CastHelper2.callThrough1stInterface (new CastHelperN(5));
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            System.gc();
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }

    private void callThrough18thInterfaceNewObject ()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        print ("Call against 18th interface with new object each time takes ... ");        
        
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                CastHelper2.callThrough18thInterface (new CastHelperN(5));
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            System.gc();
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    private void callThrough1stInterface ()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(CALLS_TO_MAKE);
        
        CastHelperN objectToCall = new CastHelperN(5);
        
        print ("Call against 1st interface takes ... ");
       
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < CALLS_TO_MAKE; ++i)
            {
                CastHelper2.callThrough1stInterface (objectToCall);
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * CALLS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }    
}

class CastHelper
{
    private int value;
    
    public CastHelper (int value)
    {
        this.value = value;
    }
    
    public int getValue()
    {
        return value;
    }
}

interface CastHelperInterfaceA {public int getValue();}
interface CastHelperInterfaceB {public int getValue();}
interface CastHelperInterfaceC {public int getValue();}
interface CastHelperInterfaceD {public int getValue();}
interface CastHelperInterfaceE {public int getValue();}
interface CastHelperInterfaceF {public int getValue();}
interface CastHelperInterfaceG {public int getValue();}
interface CastHelperInterfaceH {public int getValue();}
interface CastHelperInterfaceI {public int getValue();}
interface CastHelperInterfaceJ {public int getValue();}
interface CastHelperInterfaceK {public int getValue();}
interface CastHelperInterfaceL {public int getValue();}
interface CastHelperInterfaceM {public int getValue();}
interface CastHelperInterfaceN {public int getValue();}
interface CastHelperInterfaceO {public int getValue();}
interface CastHelperInterfaceP {public int getValue();}
interface CastHelperInterfaceQ {public int getValue();}
interface CastHelperInterfaceR {public int getValue();}

class CastHelperA
{
}

class CastHelperB extends CastHelperA
{
}

class CastHelperC extends CastHelperB
{
}

class CastHelperD extends CastHelperC
{
}

class CastHelperE extends CastHelperD
{
}

class CastHelperF extends CastHelperE
{
}

class CastHelperG extends CastHelperF
{
}

class CastHelperH extends CastHelperG
{
}

class CastHelperI extends CastHelperH
{
}

class CastHelperJ extends CastHelperI
{
}

class CastHelperK extends CastHelperJ
{
}

class CastHelperL extends CastHelperK
{
}

class CastHelperM extends CastHelperL
{
}


class CastHelperN extends CastHelperM
                  implements CastHelperInterfaceA,
                             CastHelperInterfaceB,
                             CastHelperInterfaceC,
                             CastHelperInterfaceD,
                             CastHelperInterfaceE,
                             CastHelperInterfaceF,
                             CastHelperInterfaceG,
                             CastHelperInterfaceH,
                             CastHelperInterfaceI,
                             CastHelperInterfaceJ,
                             CastHelperInterfaceK,
                             CastHelperInterfaceL,
                             CastHelperInterfaceM,
                             CastHelperInterfaceN,
                             CastHelperInterfaceO,
                             CastHelperInterfaceP,
                             CastHelperInterfaceQ,
                             CastHelperInterfaceR
                             
{
    private int value;
    
    public CastHelperN (int value)
    {
        this.value = value;
    }
    
    public int getValue()
    {
        return value;
    }
}

class CastHelper2
{
    static private int count;
    
    static public void helper1 (CastHelper o)
    {
        o.getValue();    
    }
    
    static public void helper2 (Object o)
    {
        ((CastHelper)o).getValue();    
    }
    
    static public void helper3 (Object o)
    {
        ((CastHelperN)o).getValue();    
    }
    
    static public void callThrough1stInterface (Object o)
    {
        ((CastHelperInterfaceA)o).getValue();    
    }    

    static public void callThrough18thInterface (Object o)
    {
        ((CastHelperInterfaceR)o).getValue();    
    }    
}



//
//
// Array tests
//
//
class ArrayTest extends Test
{
    private static final int ARRAYS_TO_MAKE = 100000;
    
    public ArrayTest (String name, TextField status, TextArea output)
    {
        super (name, status, output);   
    }
    
    protected void runImpl ()
    {
        calculateLoopOverhead(100000);
        println ("ARRAYS");
        
        println ("These tests show how expensive accessing array elements");
        println ("can be.");
        println ("-------------------------------------------------------");
        sumNonIntElement (500000);
        sumIntArray (new int[32000]);
        sumIntArray (new int[65000]);
        sumIntArray (new int[128000]);
        sumIntArray (new int[256000]);
        sumIntArray (new int[512000]);

        println ("These tests show how expensive creating and optionally.");
        println ("filling arrays can be.");
        println ("-------------------------------------------------------");        
        uninitializedZeroLengthIntArray ();

        for (int i = 1; i < 20; ++i)
            uninitializedIntArray (i);

        for (int i = 1; i < 20; ++i)
            initializedIntArray(i);

        println ("");
    }
    
    static int[] dummy;
    
    private void uninitializedZeroLengthIntArray ()
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(ARRAYS_TO_MAKE);
        
        print ("Creating an int[0] array takes ... ");
       
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < ARRAYS_TO_MAKE; ++i)
            {
                dummy = new int[0];
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * ARRAYS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }

    private void uninitializedIntArray (int length)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(ARRAYS_TO_MAKE);
        
        print ("Creating an int[" + length + "] array takes ... ");
       
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < ARRAYS_TO_MAKE; ++i)
            {
                dummy = new int[length];
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * ARRAYS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }
    
    private void initializedIntArray (int length)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        
        double loopOverhead = calculateLoopOverhead(ARRAYS_TO_MAKE);
        
        print ("Creating an initialized int[" + length + "] array takes ... ");
       
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < ARRAYS_TO_MAKE; ++i)
            {
                dummy = new int[length];
                for (int j = 0; j < length; ++j)
                    dummy[j] = j;
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * ARRAYS_TO_MAKE);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds.");        
    }    

    private void sumIntArray (int[] array)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        int  sum = 0;
        
        double loopOverhead = calculateLoopOverhead(array.length);
        
        print ("Summing an int[" + array.length + "] array takes ... ");
       
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < array.length; ++i)
            {
                sum += array[i];
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * array.length);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds per element.");        
    }
    
    static volatile int val = 3;
    
    private void sumNonIntElement (int elements)
    {
        int iterations = 0;
        long cumulativeTime = 0;
        int  sum = 0;
        
        double loopOverhead = calculateLoopOverhead(elements);
        
        print ("Summing " + elements + " elements not in an array (as a baseline) takes ... ");
       
        System.gc();
        long startTime = System.currentTimeMillis ();
        do
        {
            for (int i = 0; i < elements; ++i)
            {
                sum += val;
            }
            
            long endTime = System.currentTimeMillis();
            
            cumulativeTime = (endTime - startTime);
            ++iterations;
            
            long t1 = System.currentTimeMillis();
            setStatus ("" + iterations + " iterations in " + cumulativeTime + " milliseconds.  Test takes 10 seconds.");
            long t2 = System.currentTimeMillis();
            startTime -= (t2 - t1);
            
        } while (cumulativeTime < 10000);
        
        cumulativeTime -= (long)(loopOverhead * iterations);
        
        double microSecondsPerOperation = ( (cumulativeTime) * 1000.0) / ((double)iterations * elements);

        double truncated = ((int)(microSecondsPerOperation * 1000000.0))/ 1000000.0;
        
        println ("" + truncated + " microseconds per element.");        
    }
}    
