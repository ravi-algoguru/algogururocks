/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;

/**
 *
 * @author sony
 */
/**
   This class implements Shell sort
   (diminishing increment sort).

   The implementation is based on a version of
   insertion sort by Robert Cruse and a sorting
   framework by Cay Horstmann.

   Cruse suggests selecting increments by the
   formula incr = incr / 3 + 1.  In their
   "Handbook of Algorithms and Data Structures",
   Gonnet and Baeza-Yates suggest using
   incr = (5 * incr - 1) / 11 for incr >= 5.
   Sedgewick (1983) suggests the sequence
   ..., 1093, 364, 121, 40, 13, 4, 1, which is
   ensured by initializing the increment with
      int increment = 1;
      while ( increment <= a.length )
	 increment = 3 * increment + 1;
      return increment / 3;
   then calculating the next increment with
   incr = incr / 3.  My brief testing on
   arrays of size 500,000 and 1,000,000
   found Cruse's scheme to be the best.

   @author J. Mohr
*/
public class ShellSort
{
   public ShellSort(int[] anArray)
   {
      a = anArray;
   }
      
   /**
      Sorts the array managed by this sorter
   */
   public void sort()
   {
      int increment = a.length / 3 + 1;

      // Sort by insertion sort at diminishing increments.
      while ( increment > 1 )
      {
	 for ( int start = 0; start < increment; start++ )
	    insertSort( start, increment );
	 
	 increment = increment / 3 + 1;
      } 

      // Do a final pass with an increment of 1.
      // (This has to be outside the previous loop because
      // the formula above for calculating the next
      // increment will keep generating 1 repeatedly.)
      insertSort( 0, 1 );
   }
      
   /**
      Insertion sort modified to sort elements at a
      fixed increment apart.

      The code can be revised to eliminate the initial
      'if', but I found that it made the sort slower.

      @param start      the start position 
      @param increment  the increment
   */
   public void insertSort( int start, int increment )
   {
      int j, k, temp;

      for ( int i = start + increment; i < a.length; i += increment )
      {
	 j = i;
	 k = j - increment;
	 if ( a[j] < a[k] )
	 {
	    // Shift all previous entries down by the current
	    // increment until the proper place is found.
	    temp = a[j];
	    do
	    {
	       a[j] = a[k];
	       j = k;
	       k = j - increment;
	    } while ( j != start && a[k] > temp );
	    a[j] = temp;
	 }
      }
   }
     
   private int[] a;
}
