
import java.util.Queue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author RAVI
 */
public class BlockingQueue<E> {

    private int size;

    private final ReentrantLock iLock;
    private final Condition notEmpty, notFull;
    private Queue backingQueue;
    private volatile int count;
    private final int MAX_SIZE = Integer.MAX_VALUE - 8;

    /**
     * @param queue Warning: queue may or may not be empty at the moment of
     * calling this constructor. Warning: queue may or may not be a thread-safe
     * implementation. Assumption: after been passed into this constructor,
     * queue object is not used by any code outside this class.
     */
    public BlockingQueue(java.util.Queue queue) {
        if (queue == null) {
            throw new NullPointerException();
        }
        this.iLock = new ReentrantLock(true);
        this.notEmpty = iLock.newCondition();
        this.notFull = iLock.newCondition();
        this.backingQueue = queue;
      }

    /**
     * Inserts the specified element into the underlying queue, waiting if
     * necessary for the underlying queue to be ready to accept new elements.
     */
    public void push(E e) {
        if (e == null) {
            throw new NullPointerException();
        }

        try {
            while (count == MAX_SIZE) {
                notFull.await();
            }
            iLock.lock();
            backingQueue.offer(e);
            ++count;
            notEmpty.signal();
        } catch (InterruptedException ex) {
            Logger.getLogger(BlockingQueue.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            iLock.unlock();
        }
    }

    /**
     * Retrieves and removes the head of the underlying queue, waiting if
     * necessary until it is capable of providing an element.
     */
    public E pull() {
        E result = null;
        iLock.lock();
        try {
            while (count == 0) {
                notEmpty.await();
            }
            result = (E) backingQueue.poll();
            --count;
            notFull.signal();
            return result;
        } catch (InterruptedException ex) {
            Logger.getLogger(BlockingQueue.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            iLock.unlock();
        }
        return result;
    }

}
