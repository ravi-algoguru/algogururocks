/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

/**
 *
 * @author ravi
 */
class StdOut {

    public static void println(Object obj) {
        System.out.println(obj);
    }

    public static void println(String string) {
        System.out.println(string);
    }
    
    public static void println() {
        System.out.println("\n");
    }
}
