/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;

/**
 *
 * @author sony
 */
public class Singleton {
//Initialization On Demand Holder idiom

    private static class LazySomethingHolder {

        public static Singleton something = new Singleton();
    }

    public static Singleton getInstance() {
        return LazySomethingHolder.something;
    }
    //double check locking  use static volatile 
    private volatile Singleton instance = null;

    public Singleton getInstance1() {
        if (instance == null) {
            synchronized (this) {
                if (instance == null) {
                    instance = new Singleton();
                }
            }
        }
        return instance;
    }
}
