/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;
/**
 *
 * @author sony
 */
public class FindDuplicateInArray {

    static int xorArray, dup;

    public static void main(String args[]) {
        //input array of length n must contain all num [1..n-1] and one number repeating
        // i.e. no missing number except for max num=arr.len-1
        int[] _array = new int[]{5,2, 3, 4, 7,1,7,6};
//int[] _array = new int[]{11,12,13,14,14,15,16};
        int duplicate = findWithXOR(_array);
        System.out.println("Duplicate: " + duplicate);
   
    }

    public static int findWithXOR(int[] input) {
        int xorArray = 1;//,dup=0;
        //int xorArray1 = 1;
        for (int i = 2; i < input.length; i++) {
            xorArray = xorArray ^ i;
            System.out.print(xorArray + ",");
        }
        System.out.println("XOR Array : " + xorArray);
        for (int k = 0; k < input.length; k++) {
            xorArray = xorArray ^ input[k];
            System.out.print(xorArray + ",");
        }
        System.out.println(" \n XOR of Array : " + xorArray);

//System.out.println(“Duplicate : ” + dup);
        return xorArray;
    }
}
