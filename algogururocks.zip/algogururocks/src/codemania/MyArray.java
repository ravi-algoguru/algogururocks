/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;

import java.io.IOException;

/**
 *
 * @author sony
 */
public class MyArray {

    public static void main(String[] args) throws IOException {
        // computing values for extra sector
        int SECTOR_SIZE = 100;
        byte[][] sectors = new byte[10][SECTOR_SIZE];
// ... code to fill in values of sectors
        byte[] extra = new byte[SECTOR_SIZE];
        for (int i = 0; i < SECTOR_SIZE; i++) {
            extra[i] = 0;
            for (int j = 0; j < 10; j++) {
                extra[i] ^= sectors[j][i];
            }
        }
        //====================================================================
        int[] arr = {5, 9, 1, 0, 23, 56, -2, 56, -2};
       // xor
        int sum = 0;
        int XOR = arr[0];
        for (int i : arr) {
            sum += i;
        }
        System.out.print(sum + "\n");
        System.out.print("\n" + (15 ^ 16 ^ 16) + "\n");
        int i = 0;
        while (i < arr.length - 2) {
            XOR ^= arr[i + 1];
            i++;
            System.out.print(XOR + ",");
        }
    }
}
