/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;

/**
 *
 * @author sony
 */
public class BitWise {
  
     void printRepeating(int arr[], int size)
{
  int xor = arr[0]; /* Will hold xor of all elements */
  int set_bit_no;  /* Will have only single set bit of xor */
  int i;
  int n = size - 2;
  int x = 0, y = 0;
   
  /* Get the xor of all elements in arr[] and {1, 2 .. n} */
  for(i = 1; i < size; i++)
    xor ^= arr[i];  
  for(i = 1; i <= n; i++)
    xor ^= i;   
 
  /* Get the rightmost set bit in set_bit_no */
  set_bit_no = xor & ~(xor-1);
 
  /* Now divide elements in two sets by comparing rightmost set
   bit of xor with bit at same position in each element. */
  for(i = 0; i < size; i++)
  {
    if(arr[i] & set_bit_no)
      x = x ^ arr[i]; /*XOR of first set in arr[] */
    else
      y = y ^ arr[i]; /*XOR of second set in arr[] */
  }
  for(i = 1; i <= n; i++)
  {
    if(i & set_bit_no)
      x = x ^ i; /*XOR of first set in arr[] and {1, 2, ...n }*/
    else
      y = y ^ i; /*XOR of second set in arr[] and {1, 2, ...n } */
  }
   
  printf("\n The two repeating elements are %d & %d ", x, y);
}     
 
 
int main()
{
  int arr[] = {4, 2, 4, 5, 2, 3, 1};
  int arr_size = sizeof(arr)/sizeof(arr[0]);  
  printRepeating(arr, arr_size);
  getchar();
  return 0;
}
    /**
* natural log method.
* Calculate how many bits wide a number is,
* i.e. position of highest 1 bit.
* @return p where 2**p is first power of two >= n.
* e.g. binary 0001_0101 -> 5, 0xffffffff -> 32,
* 0 -> 0, 1 -> 1, 2 -> 2, 3 -> 2, 4 -> 3
*/
//public static int widthInBits1(int n ){
//   {// 2^30-1 = 0x3FFFFFFF
//   if ( n < 0 )
//      {
//      return 32;
//      }
//   if ( n > 0x3fffffff )
//      {
//      return 31;
//      }
//   return(int)Math.ceil( Math.log( n+1 ) * invln2 );
//   } // end widthInBits1
//
//private static double invln2 = 1.0 / Math.log(2.0);
//
///**
//* Calculate how many bits wide a number is,
//* i.e. position of highest 1 bit.
//* Fully unraveled binary search method.
//* @return p where 2**p is first power of two >= n.
//* e.g. binary 0001_0101 -> 5, 0xffffffff -> 32,
//* 0 -> 0, 1 -> 1, 2 -> 2, 3 -> 2, 4 -> 3
//* @author Dirk Bosmans Dirk.Bosmans@tijd.com */
//public static final int widthInBits( int n )
//   {
//   if ( n < 0 ) return 32;
//   if ( n > 0x0000ffff )
//      {
//      if ( n > 0x00ffffff )
//         {
//         if ( n > 0x0fffffff )
//            {
//            if ( n > 0x3fffffff )
//               {
//               // if ( n > 0x7fffffff )
//               // return 32
//               // else
//               return 31;
//               }
//            else
//               {
//               // !( n > 0x3fffffff )
//               if ( n > 0x1fffffff ) return 30;
//               else return 29;
//               }
//            }
//         else
//            {
//            // !( n > 0x0fffffff )
//            if ( n > 0x03ffffff )
//               {
//               if ( n > 0x07ffffff ) return 28;
//               else return 27;
//               }
//            else
//               {
//               // !( n > 0x03ffffff )
//               if ( n > 0x01ffffff ) return 26;
//               else return 25;
//               }
//            }
//         }
//      else
//         {
//         // !( n > 0x00ffffff )
//         if ( n > 0x000fffff )
//            {
//            if ( n > 0x003fffff )
//               {
//               if ( n > 0x007fffff ) return 24;
//               else return 23;
//               }
//            else
//               {
//               // !( n > 0x003fffff )
//               if ( n > 0x001fffff ) return 22;
//               else return 21;
//               }
//            }
//         else
//            {
//            // !( n > 0x000fffff )
//            if ( n > 0x0003ffff )
//               {
//               if ( n > 0x0007ffff ) return 20;
//               else return 19;
//               }
//            else
//               {
//               // !( n > 0x0003ffff )
//               if ( n > 0x0001ffff ) return 18;
//               else return 17;
//               }
//            }
//         }
//      }
//   else
//      {
//      // !( n > 0x0000ffff )
//      if ( n > 0x000000ff )
//         {
//         if ( n > 0x00000fff )
//            {
//            if ( n > 0x00003fff )
//               {
//               if ( n > 0x00007fff ) return 16;
//               else return 15;
//               }
//            else
//               {
//               // !( n > 0x00003fff )
//               if ( n > 0x00001fff ) return 14;
//               else return 13;
//               }
//            }
//         else
//            {
//            // !( n > 0x00000fff )
//            if ( n > 0x000003ff )
//               {
//               if ( n > 0x000007ff ) return 12;
//               else return 11;
//               }
//            else
//               {
//               // !( n > 0x000003ff )
//               if ( n > 0x000001ff ) return 10;
//               else return 9;
//               }
//            }
//         }
//      else
//         {
//         // !( n > 0x000000ff )
//         if ( n > 0x0000000f )
//            {
//            if ( n > 0x0000003f )
//               {
//               if ( n > 0x0000007f ) return 8;
//               else return 7;
//               }
//            else
//               {
//               // !( n > 0x0000003f )
//               if ( n > 0x0000001f ) return 6;
//               else return 5;
//               }
//            }
//         else
//            {
//            // !( n > 0x0000000f )
//            if ( n > 0x00000003 )
//               {
//               if ( n > 0x00000007 ) return 4;
//               else return 3;
//               }
//            else
//               {
//               // !( n > 0x00000003 )
//               if ( n > 0x00000001 ) return 2;
//               return n;
//               /*
//               else if ( n > 0x00000000 )
//               return 1;
//               else
//               return 0;
//               */
//               }
//            }
//         }
//      }
//   } // end widthInBits
//
//    public static void main(String[] str) {
//        int n = 100;
//        boolean isPowerOfTwo = (n & -n) == n;
//        System.out.println(n + " isPowerOfTwo : " + isPowerOfTwo);
//
//        //conditional toggle if one true make other false;
//        boolean condition = false;
//        boolean toggle=false;;
////        if (condition) {
////            toggle = ! toggle;
////        }
//        toggle ^= condition;
//    }
//    
   
}
