/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania.sorting;

/**
 *
 * @author sony
 */
public class CombSort extends SortAlgorithm {
    final float SHRINKFACTOR = (float)1.3;

    void sort(int a[]) throws Exception {
        boolean flipped = false;
        int gap, top;
        int i, j;

        gap = a.length;
        do {
            gap = (int) ((float) gap / SHRINKFACTOR);
            switch (gap) {
            case 0: /* the smallest gap is 1 - bubble sort */
                gap = 1;
                break;
            case 9: /* this is what makes this Combsort11 */
            case 10: 
                gap = 11;
                break;
            default: break;
            }
            flipped = false;
            top = a.length - gap;
            for (i = 0; i < top; i++) {
                if (stopRequested) {
                    return;
                }

                j = i + gap;
                if (a[i] > a[j]) {
                    int T = a[i];
                    a[i] = a[j];
                    a[j] = T;
                    flipped = true;
                }
                pause(i,j);
            }
        } while (flipped || (gap > 1));
        /* like the bubble and shell sorts we check for a clean pass */
    }
}

