/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;

/**
 *
 * @author sony
 */
public class InnerClass {
    
}
class A {
static private final Object sharedSecret = new Object();
static {   A$B.receiveSecretForA(sharedSecret); }
private int x;
int access$1(Object secretForA) {
if (secretForA !=sharedSecret) throw
                                 new SecurityException();
 return x;
}
}
class A$B {
private A this$0;
static private Object sharedSecret;
static void receiveSecretForA(Object secretKey) {
if (sharedSecret != null) throw new VerifyError();
 sharedSecret = secretKey;
}
//invoke this$0.access$1(sharedSecret)…
}