/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

/**
 *
 * @author sony
 */
class Node {

    int data;
    Node lChild;
    Node rChild;

    Node(int data) {
        this.data = data;
    }
}

class MaxPathNode {

    int[][] path = new int[2][];
    int data;
    int leftSum, rightSum;

    public MaxPathNode() {
    }

    public void addLeft(int[] left) {
        path[0] = left;
        for (int i = 0; i < left.length; i++) {
            leftSum += left[i];
        }
    }

    public void addRight(int[] right) {
        path[1] = right;
        for (int i = 0; i < right.length; i++) {
            leftSum += right[i];
        }
    }
}

public class BinaryTree {

    Node senital = new Node('.');
    Node root;
    ArrayList maxPathRootList;

    BinaryTree() {
    }

    public static void main(String[] args) {
        System.out.println("Binary Tree");
        BinaryTree bTree = new BinaryTree();
        int[] dataArr = {10, 5, 25, 3, 8, 13, 18, 2, 4, 6, 11, 14, 17, 19, 1, 7, 9, 12, 16, 20, 21, 22, 23, 24};
        //   int[] dataArr = {10,5,8,6,7, 25,13, 18,14, 17, 19, 12, 16, 20, 21, 22, 23, 24};
        for (int data : dataArr) {
            bTree.insert(data);
        }

        bTree.inOrderTreversal();
        System.out.println("Iterative inorder\n");
        bTree.iterative_inOrder();
        System.out.println("\n Iterative preorder\n");
        //bTree.iterative_preOrder();
        bTree.recursive_Preorder();
        //10 ,5 ,3 ,2 ,1 ,4 ,8 ,6 ,7 ,9 ,25 ,13 ,11 ,12 ,18 ,14 ,17 ,16 ,19 ,20 ,21 ,22 ,23 ,24 
        System.out.println("\n recursive PostOrder\n");
        bTree.recursive_PostOrder();
        System.out.println("\n Iterative PostOrder\n");
        //   bTree.recursive_PostOrder();
        bTree.iterative_PostOrder();
        System.out.println("\n Iterative levelOrder\n");
        bTree.levelOrderTreversal();
        System.out.println("Candidate Search :"+ bTree.candidateSearch(25));
      
        bTree.getMaxPathFromRoot();
        Iterator it = bTree.maxPathRootList.iterator();
        while (it.hasNext()) {
            System.out.print(((Node) it.next()).data + ", ");
        }
    }

    public boolean insert(int data) {
        if (root == null) {
            root = new Node(data);
            return true;
        }
        return insert(root, data);
    }

    private boolean insert(Node node, int data) {
        if (data < node.data) {
            if (node.lChild == null) {
                node.lChild = new Node(data);
                return true;
            }
            node = node.lChild;
        }
        if (data > node.data) {
            if (node.rChild == null) {
                node.rChild = new Node(data);
                return true;
            }
           node = node.rChild;
        }
        return insert(node,data);
    }

    public void inOrderTreversal() {
        inOrderTreversal(root);
    }

    private void inOrderTreversal(Node node) {
        if (node == null) {
            return;
        }
        inOrderTreversal(node.lChild);
        System.out.print(node.data + ",");
        inOrderTreversal(node.rChild);

    }

    public void iterative_inOrder() {
        if (root == senital) {
            return;
        }
        iterative_inOrder(root);
    }

    private void iterative_inOrder(Node node) {
        Stack<Node> s = new Stack<Node>();
        Node temp = null;
        while (true) {
            while (node != null) {
                s.push(node);
                node = node.lChild;
            }
            if (s.isEmpty()) {
                break;
            }
            temp = s.pop();
            System.out.print(temp.data + " , ");
            node = temp.rChild;
        }
    }

    public void iterative_preOrder() {
        iterative_preOrder(root);
    }

    private void iterative_preOrder(Node node) {
        Stack<Node> s = new Stack<Node>();
        Node temp = null;
        while (true) {
            while (node != null) {
                System.out.print(node.data + " ,");
                s.push(node);
                node = node.lChild;
            }
            if (s.isEmpty()) {
                return;
            }
            temp = s.pop();
            node = temp.rChild;
        }
    }

    public void recursive_Preorder() {
        if (root == null) {
            return;
        }
        recursive_Preorder(root);
    }

    private void recursive_Preorder(Node node) {
        if (node == null) {
            return;
        }
        System.out.print(node.data + " ,");
        recursive_Preorder(node.lChild);
        recursive_Preorder(node.rChild);
    }

    public void recursive_PostOrder() {
        if (root == null) {
            return;
        }
        recursive_PostOrder(root);
    }

    private void recursive_PostOrder(Node node) {
        if (node == null) {
            return;
        }
        recursive_PostOrder(node.lChild);
        recursive_PostOrder(node.rChild);
        System.out.print(node.data + " ,");

    }

    public void iterative_PostOrder() {
        if (root == null) {
            return;
        }
        iterative_PostOrder(root);
    }

    private void iterative_PostOrder(Node node) {
        Stack<Node> s = new Stack<Node>();
        Node temp = null;
        while (true) {
            while (node != null) {
                s.push(node);
                node = node.lChild;
            }
            if (s.isEmpty()) {
                break;
            }
            if (s.peek().rChild == null || temp == s.peek().rChild) {
                temp = s.pop();
                //   node=temp.rChild;
                System.out.print(temp.data + " ,");
            } else {
                node = s.peek().rChild;
            }
        }
    }

    private void levelOrderTreversal() {
        if (root == null) {
            return;
        }
        levelOrderTreversal(root);
    }

    private void levelOrderTreversal(Node node) {
        Queue<Node> q = new LinkedList<Node>();
        Node mark = new Node('@');
        q.offer(node);
        q.offer(mark);
        Node temp = null;
        while (true) {
            temp = q.poll();
            if (q.isEmpty() || temp == null) {
                break;
            }
            if (temp != mark) {
                System.out.print(temp.data + " ,");
                if (temp.lChild != null) {
                    q.offer(temp.lChild);
                }
                if (temp.rChild != null) {
                    q.offer(temp.rChild);
                }
            } else {
                q.offer(mark);
                System.out.println();
            }
        }
    }

    public boolean candidateSearch(int data) {
        if (root == null) {
            System.out.println("Empty tree");
            return false;
        }
        return candidateSearch(root, data);
    }

    private boolean candidateSearch(Node node, int data) {
        Node candidate = null;
        do {
            if (data < node.data) {
                node = node.lChild;
            } else {
                candidate = node;
                node = node.rChild;
            }
        } while (node != null);
        if (candidate != null && candidate.data == data) {
            return true;
        } else {
            return false;
        }

    }

    private int getHieght(Node node) {
        if (node == null) {
            return 0;
        }
        return Math.max(getHieght(node.lChild), getHieght(node.rChild)) + 1;
    }

//    private void printMaxSumPathViaLeaf(Node node, ArrayList list, int sum, int leftSum, int rightSum) {
//        MaxPathNode maxPath = new MaxPathNode();
//        Stack<Node> s = new Stack<Node>();
//        Node temp = null;
//        while (true) {
//            while (node != null) {
//                s.push(node);
//                if (getHieght(node) == 2) {
//                    if (node.lChild != null && maxPath.leftSum < node.lChild.data) {
//                        maxPath.path[0] = new int[]{node.lChild.data};
//                    }
//                    if (node.rChild != null && maxPath.rightSum < node.lChild.data) {
//                        maxPath.path[1] = new int[]{node.rChild.data};
//                    }
//                    break;
//                }
//                node = node.lChild;
//            }
//            if (s.isEmpty()) {
//                break;
//            }
//            temp = s.pop();
//            maxPath.data = temp.data;
//            System.out.println(temp.data + ",");
//            node = temp.rChild;
//            int rSum = getMaxRight(node);
//            int[] rightPath = getMaxRightPath(node);
//            if (rSum > maxPath.leftSum && rSum < maxPath.rightSum) {
//                maxPath.path[0] = rightPath;
//            }
//            if (rSum > maxPath.rightSum && rSum < maxPath.leftSum) {
//                maxPath.path[1] = rightPath;
//            }
//        }
//    }
    public ArrayList getMaxPathFromRoot() {
        if (root == null) {
            return new ArrayList();
        }
        return getMaxPathFromRoot(root);
    }

    public ArrayList getMaxPathFromRoot(Node node) {
        if (node == null) {
            return null;
        }
        ArrayList arr = new ArrayList();
        int sum = 0;
        int maxSum = Integer.MIN_VALUE;
        return getMaxPathFromRoot(node, arr, sum, maxSum);

    }

    private ArrayList getMaxPathFromRoot(Node node, ArrayList arr, int sum, int maxSum) {
        if (node == null) {
            return arr;
        }
        ArrayList list = new ArrayList(arr);
        list.add(node);
        if (sum + node.data > maxSum) {
            maxPathRootList = list;
            sum += node.data;
            maxSum = sum;
        }
        if (node.lChild != null) {
            getMaxPathFromRoot(node.lChild, list, sum, maxSum);
        }
        if (node.rChild != null) {
            getMaxPathFromRoot(node.rChild, list, sum, maxSum);
        }
        return arr;
    }

    public ArrayList printMaxPathViaLeaf() {
        ArrayList list = new ArrayList();
        if (root == null) {
            return list;
        }
        Stack s = new Stack();
        Node node = null;
        while (true) {
            do {
                s.push(node);
                node = node.lChild;
            } while (node != null);

            if (s.isEmpty()) {
                break;
            }
            Node temp = (Node) s.pop();
            node = temp.rChild;
            if (node != null) {
                getMaxPathFromRoot(node);
            }
        }
        return list;
    }
}
