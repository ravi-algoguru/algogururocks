/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package codemania;

/**
 *
 * @author sony
 */

import corejava.*;	// From Cay Horstmann's book

/**
 *	OptimalBST 
 * 
 * @author Baase and Van Gelder (pseudocode);
 * implemented by Jonathan Mohr
 */
public class OptimalBST
{
	private static double[] prob = {0, .15, .025, .05, .025, .05,
		 .125, .025, .075, .075, .05, .15, .075, .05, .025, .05 };
	
	public static void main(String[] args)
	{
		int n = 15;		// number of keys
		double[][] cost = new double[n + 2][n+1];
		int[][] root = new int[n+2][n+1];
		
		optimalBST( prob, n, cost, root );
		
		for ( int i = 1; i < n + 2; i++ )
		{
			for ( int j = 0; j < n + 1; j++ )
				if ( j >= i - 1 )
					Format.printf( "%7.3f", cost[i][j] );
				else
					System.out.print("       ");
			System.out.println();
		}
		System.out.println();
		
		for ( int i = 1; i < n + 2; i++ )
		{
			for ( int j = 0; j < n + 1; j++ )
				if ( j >= i - 1 )
					Format.printf( "%7d", root[i][j] );
				else
					System.out.print("       ");
			System.out.println();
		}
	}

	public static void optimalBST( double[] prob, int n,
		double[][] cost, int[][] root )
	{
		for ( int low = n + 1; low >= 1; low-- )
			for ( int high = low - 1; high <= n; high++ )
				bestChoice( prob, cost, root, low, high );		
	}
	
	public static void bestChoice( double[] prob, 
		double[][] cost, int[][] root, int low, int high )
	{
		double bestCost;
		int bestRoot = -1;
		
		if ( high < low )
		{
			bestCost = 0;	// empty tree
			bestRoot = -1;
		}
		else	
			bestCost = Double.POSITIVE_INFINITY;
			
		for ( int r = low; r <= high; r++ )
		{
			double rCost = p( prob, low, high ) +
				cost[low][r-1] + cost[r+1][high];
			if (rCost < bestCost)
			{
				bestCost = rCost;
				bestRoot = r;
			}
		}
		
		cost[low][high] = bestCost;
		root[low][high] = bestRoot;
	}

	public static double p( double[] prob, int low, int high )
	{
		double weight = 0.0;
		
		if ( low <= high )	
			for ( int i = low; i <= high; i++ )
				weight += prob[i];

		return weight;
	}
}
