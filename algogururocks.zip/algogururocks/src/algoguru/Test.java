/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package algoguru;

/**
 *
 * @author ravi
 */
public class Test {
 
        public static class Node {
               
                public Node next;
                public String name;
               
                public Node(String name) {
                        this.name = name;
                }
               
        }
       
        public static void reverse(Node previous, Node current) {
                //if there is next node...
            if (current.next != null) {
                //...go forth and pwn
                Node next= current.next;
                reverse(current, next);
            }
               
                if (previous == null) {
                // this was the start node
                        current.next= null;
            } else {
                //reverse
                current.next= previous;
            }
 
           
        }
       
        public static void main(String[] args) {
                Node n1= new Node("1");
                Node n2= new Node("2");
                Node n3= new Node("3");
                Node n4= new Node("4");
                Node n5= new Node("5");
               
                n1.next= n2;
                n2.next= n3;
                n3.next= n4;
                n4.next= n5;
               
                Node cursor= n1;
                while (cursor != null) {
                        System.out.println(cursor.name);
                        cursor= cursor.next;
                }
               
                reverse(null, n1);
               
                cursor= n5;
                while (cursor != null) {
                        System.out.println(cursor.name);
                        cursor= cursor.next;
                }
    }
}
