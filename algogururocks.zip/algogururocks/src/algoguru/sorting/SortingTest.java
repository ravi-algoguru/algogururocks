/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package algoguru.sorting;

/**
 *
 * @author ravi
 */
public class SortingTest {
   // static int [] arr = new int[20];
   // static int[] res = new int[20];
    public static void insertion_sort(int[] arr){
        int i,j;
        for(j = 1; j < arr.length; j++){
            int key = arr[j];
            i = j-1; 
            while(i >=0 && arr[i] > key){
                arr[i+1] = arr[i];
                i--;
            }
            arr[i+1] = key;
        }
    }
    
    public static void insertion_sort(int[] arr, int start, int end){
        int i,j;
        int size = end - start + 1;
        for(j = 1; j < arr.length; j++){
            int key = arr[j];
            i = j-1; 
            while(i >=0 && arr[i] > key){
                arr[i+1] = arr[i];
                i--;
            }
            arr[i+1] = key;
        }
    }
    
    public static void merge_sort(int[] arr, int start, int end){
        if(start >= end) return;
        int mid = start + ( end - start)/2;
        merge_sort(arr, start, mid);
        merge_sort(arr, mid+1, end);
        merge(arr, start, mid, end);
    }
    
    public static void merge_sort_with_InsertionSort(int[] arr, int start, int end){
        if(end - start == 5|| end -start ==3){
            insertion_sort(arr);
            return;
        }
        
        int mid = start + ( end - start)/2;
        merge_sort(arr, start, mid);
        merge_sort(arr, mid+1, end);
        merge_optimized(arr, start, mid, end);
    }
    public static void merge_sort_optimized(int[] arr, int start, int end){
        if(start >= end) return;
        int mid = start + ( end - start)/2;
        merge_sort(arr, start, mid);
        merge_sort(arr, mid+1, end);
        merge_optimized(arr, start, mid, end);
    }
    public static void merge_optimized(int[] arr, int start, int mid, int end){
       int n1 = mid - start + 1;
       int n2 = end - mid;
       int[] arr1 = new int[n1 + 1];
       int[] arr2 = new int[n2 + 1];
       
       int i = 0;
       while(i < n1){
           arr1[i] = arr[start + i];
           i++;
       }
       int j = 0;
       while(j < n2){
           arr2[j] = arr[mid + j + 1]; //arr[mid+j] mid = 0 , j =0
           i++; j++;
       }
       
       arr1[n1] = Integer.MAX_VALUE;
       arr2[n2] = Integer.MAX_VALUE;

       i = 0;j = 0;
       int k = start;
       //int len = n1 + n2;
        while( k <= end){
            if(arr1[i] <= arr2[j]){
                arr[k] = arr1[i];
                i++;
            }else{
                arr[k] = arr2[j];
                j++;
            }
            k++;    
        }
    }
    public static void merge(int[] arr, int start, int mid, int end){
        //System.out.println("\n");
        //print(arr, start, end);
        int[] res = new int[end + 1];
        int i = start, j = mid+1, k = start;
        while(i<= mid && j <= end){
            if(arr[i] < arr[j]){
                res[k] = arr[i];
                k++; i++;
            } else{
                res[k] = arr[j];
                k++; j++;
            } 
        }
        if( i <= mid){
            while(i <= mid){
                res[k] = arr[i];
                i++; k++;
            }
        }
        if(j <= end){
            while(j <= end){
                res[k] = arr[j];
                k++; j++;
            }
        }
        System.arraycopy(res, start, arr, start, end - start + 1 );
    }
    public static void print(int[] arr){
        int size =arr.length;
         for (int i = 0; i < size; i++) {
             System.out.print(arr[i]+", ");
        }
    }
    public static void print(int[] arr, int start, int end){
         for (int i = 0; i <= end; i++) {
             System.out.print(arr[i]+", ");
        }
    }
    
    public static void main(String[] args){
        int n = 20;
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
           arr[i]=Math.round((float) (Math.random() * 100));
        }
        
        //arr = new int[]{99, 29, 58, 23, 24, 38, 62, 20, 86, 88, 50, 51, 79, 44, 2, 30, 34, 34, 18, 32};
        print(arr);
        long start , end;
        start= System.nanoTime();
        merge_sort(arr, 0, arr.length -1);
        end = System.nanoTime();  System.out.println("\n");
        System.out.print(end -start);
        
        //arr = new int[]{99, 29, 58, 23, 24, 38, 62, 20, 86, 88, 50, 51, 79, 44, 2, 30, 34, 34, 18, 32};
        System.out.println("\n");
        for (int i = 0; i < n; i++) {
           arr[i]=Math.round((float) (Math.random() * 100));
        }
        print(arr);
        start= System.nanoTime();
        merge_sort_optimized(arr, 0, arr.length-1);
        end = System.nanoTime();
          System.out.println("\n");
        System.out.print(end -start);
        System.out.println("\n");
        
        System.out.println("\n");
        for (int i = 0; i < n; i++) {
           arr[i]=Math.round((float) (Math.random() * 100));
        }
        arr = new int[]{99, 29, 58, 23, 24, 38, 62, 20, 86, 88, 50, 51, 79, 44, 2, 30, 34, 34, 18, 32};
        print(arr);
        start= System.nanoTime();
        merge_sort_with_InsertionSort(arr, 0, arr.length-1);
        end = System.nanoTime();   
          System.out.println("\n");
        System.out.print(end -start);
        System.out.println("\n");
        print(arr);
       
    }
}
