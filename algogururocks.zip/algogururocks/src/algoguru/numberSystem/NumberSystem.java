/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package algoguru.numberSystem;

/**
 *
 * @author ravi
 */
public class NumberSystem {
    public static double power(int x, int n){
        if(n == 0) return 1;
        if(x == 0) return 0;       
        int r = n%2;
        int q = Math.abs(n/2);
        double res = Double.valueOf(power(x,q));
        if( n < 0){
          if(r == 0) return 1/(res * res);
         return 1/(x* res * res);
        }
         if(r == 0) return res * res;
         return x* res * res;
    }

    public static long fibonaci(int n){
        if(n == 0) return 0;
        if(n == 1) return 1;
        int[] fibArray = new int[n+1];
        fibArray[0] = 0; fibArray[1] = 1;
        for(int i = 2 ; i <= n; i++)
            fibArray[i] = fibArray[i-1] + fibArray[i-2];
        for(int num : fibArray)
        System.out.print(num+ ", ");
        return fibArray[n];
    }
    
    public static int fib_recursive(int n){
        if(n == 0) return 0; 
        if(n == 1) return 1;
        return fib_recursive(n -1)+ fib_recursive(n-2);
    }
    
    public static int fib_inplace_iterative(int n){
        if(n == 0) return 0;
        if(n == 1) return 1;
        int i = 2, a = 0, b = 1;
        int fib = 1;
        while(i <= n ){
            fib = b + a;
            a = b;
            b = fib;
            i++;
        }
        return fib;
    }
    
//    public void findFactor(int num){
//    Math.sqrt(num)
//    }
    public static void main(String[] args){
        int x = 11, n = 1;
       // System.out.println(power(2,-3));
        System.out.println(fibonaci(25));
        System.out.println(fib_recursive(25));
    }
}
