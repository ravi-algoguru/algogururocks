/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algoguru.numberSystem;

/**
 *
 * @author ravi
 */
public class MaxSubArrayProblem {

    public static void maxSubArray(int[] arr) {
        int sum = 0,
                max = Integer.MIN_VALUE,
                a = 0, b = 0, i = 0;

        for (int j = 0; j < arr.length; j++) {
            sum += arr[j];
            if (sum < 0) {
                sum = 0;
                i = j + 1;
            } else if (sum > max) {
                max = sum;
                a = i;
                b = j;
            }
        }
        int[] res = {max, a, b};
       
       System.out.println("sum : " + res[0]+", start:"+res[1]+", end: "+res[2]+"\n elements : ");
      int k=a;
      
       while(k<=b){
           System.out.print(arr[k++]+" , ");
       }
    }

    public static void main(String[] args) {
//        int n = 20;
//        int[] arr = new int[n];
//        for (int i = 0; i < n; i++) {
//            arr[i] = Math.round((float) (Math.random() * 100)) - 50;
//        }
        int[] arr=new int[]{13, -3, -25, 20, -3, -16, -23, 18, 20, -7, 12, -5,-22,15, -4, 7};
        //{-1000,1,5,-3,4,-6,7,100,-1,-200,4 , 5, -10,20, 3, 4, 6, -8};  
//         for (int i = 0; i < arr.length; i++) {
//            arr[i] -= Math.round((float) (Math.random() * 100)) ;
//        }
          for (int i = 0; i < arr.length; i++) {
              System.out.print( arr[i]+", ");  
        }
        maxSubArray(arr);
    }
}
