/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algoguru.linkedList;

/**
 *
 * @author ravi
 */
class Node {

    Node next;
    int data;

    public Node(int data) {
        this.data = data;
    }

}

class MyLinkedList {

    Node head;

    public void insert(int data) {
        if (head == null) {
            head = new Node(data);
            return;
        }
        Node node = head;
        while (node != null) {
            if (node.next == null) {
                node.next = new Node(data);
                break;
            }
            node = node.next;
        }
    }

    public MyLinkedList() {
        head = null;
    }

    public void printList() {
        Node node = head;
        while (node != null) {
            System.out.print(node.data + " ,");
            node = node.next;
        }
    }

    public Node reverseInPair() {
        Node previous = null, current, nextNode, temp;
        if (head == null) {
            return null;
        }
        if (head.next == null) {
            return head;
        }
        previous = head;
        current = head.next;
        head = current;
        while (true) {
            nextNode = current.next;
            current.next = previous;
            if (nextNode == null || nextNode.next == null) {
                previous.next = nextNode;
                break;
            }
            previous.next = nextNode.next;
            current = nextNode.next;
            previous = nextNode;
        }
        return head;
    }

}

public class LinkedListTest {

    public static void printList(Node head) {
        System.out.print("\nlist   : ");
        Node node = head;
        while (node != null) {
            System.out.print(node.data + " ,");
            node = node.next;
        }
    }

    public static void mergeTwoList(MyLinkedList l1, MyLinkedList l2) {
        Node temp1 = null, temp2 = null;
        Node n1 = l1.head, n2 = l2.head;
        Node head = n1;
        while (n1 != null && n2 != null) {
            temp1 = n1.next;
            temp2 = n2.next;
            n1.next = n2;
            n2.next = temp1;
            n2 = temp2;
            n1 = temp1;
        }
        n1 = head;
        l2.head = n2;
        printList(l1.head);
        printList(l2.head);
    }

    // Singly Linked List Binary Search
//public Node binarySearch(Object SearchKey) {
//  Node PartitionFirst = First, MidPtr = null;
//  int Partition Size = NumNodes, Mid, I, Result;
//  while (PartitionSize > 0) {
//    Mid = PartitionSize / 2;
//    MidPtr = PartitionFirst;
//    for(I = 0; I < Mid; I++)
//      MidPtr = MidPtr.next;
//    Result = MidPtr.compareTo(SearchKey);
//    if (Result > 0)
//      PartitionSize = Mid;
//    else if (Result < 0) {
//      PartitionSize -= Mid;
//      PartitionFirst = MidPtr;
//      }
//    else return MidPtr;
//    }
//  return null;
//  }
    public static Node sort_list(MyLinkedList list) {
        Node node = list.head;
        if (node == null || node.next == null) {
            return node;
        }
        Node mark = node, iter = node, pivot = node;
        Node temp, temp1;
        while (iter.next != null) {
            if (iter.next.data <= pivot.data) {
                int lt = pivot.data - iter.next.data;
                //  System.out.println("mark " + mark.data);
                if (iter != mark) {
                    temp1 = iter.next.next;
                    temp = mark.next;
                    mark.next = iter.next;
                    mark.next.next = temp;
                    iter.next = temp1;
                } else {
                    iter = iter.next;
                }
                if (lt > 0) {
                    mark = mark.next;
                }
            } else {
                iter = iter.next;
            }
        }
        if (mark != pivot) {
            temp = mark.next;
            list.head = pivot.next;
            mark.next = pivot;
            pivot.next = temp;
        }

        return mark;
    }

    //Singly Linked List Quicksort
    private Node QuickSort(Node before, Node first, int n) {
        int Num1 = 0, Num2 = n, i = 1;
        Node Pivot = first, aNode = first, aNodePrev = first;
        // Pivot Advancement
        for (i = 1; i < n; i++, aNode = aNode.next) {
            if (aNode.data > aNode.next.data) {
                break;
            }
            if ((i & 1) == 0) { //every other time through the loop
                Pivot = Pivot.next;
                Num1++;
            }
        }
        //Recognize sortedness in linear time
        if (i == n) {
            return first; //Pivot advanced through entire list and found it to be aleady sorted
        }  // Partition list by unlinking nodes with values less 
        // than the pivot and pushing them onto front of list
        for (aNodePrev = aNode; i < n; i++) {
            aNodePrev.next = aNode.next;
            if (Pivot.data > aNode.data) {
                aNode.next = first;
                first = aNode;
                Num1++;
            } else {
                aNodePrev = aNode;
            }
        }
        if (before != null) {
            before.next = first;
        }
        Num2 = n - Num1 - 1;
        // Recurse to sort sublists
        if (Num1 > 1) {
            first = QuickSort(before, first, Num1);
        }
        if (Num2 > 1) {
            QuickSort(Pivot, Pivot.next, Num2);
        }
        return first;

    }

    public static MyLinkedList reverseList_iterative(MyLinkedList list) {
        if (list == null) {
            return null;
        }
        Node current = list.head;
        if (current == null || current.next == null) {
            return list;
        }
        Node previous = null, nextNode = null;
        while (current != null) {
            nextNode = current.next;
            current.next = previous;
            previous = current;
            current = nextNode;
        }
        list.head = previous;
        return list;
    }

    public static Node reverseList_recursive(Node current) {
        if (current == null) {
            return null;
        }
        if (current.next == null) {
            return current;
        }
        // Node previous = current;// Node nextNode = current.next;
        Node temp = reverseList_recursive(current.next);
        if (current.next.next == null) {
            current.next.next = current;
            current.next = null;
        }

        return temp;
    }

    public static Node reverseList_recursive(Node current, Node previous) {
        if (current == null) {
            return previous;
        }
        Node temp = current.next;
        current.next = previous;
        previous = current;
        current = temp;
        System.out.println(previous.data + ",");
        return reverseList_recursive(current, previous);

    }

    public static void recursive(Node start) {
        // Node start = node;
        // exit condition
        if (start == null || start.next == null) {
            return;
        }
        Node first = start;
        Node rest = first.next;
        if (rest == null) {
            return;
        }
        recursive(rest);
        first.next.next = first;
        first.next = null;
        start = rest;

    }

    public static Node recurse2(Node node) {
        Node head = null;
        if (node == null || node.next == null) {
            return node;
        }
        Node previous = node, current = node.next;
        head = recurse2(node.next);
        current.next = previous;
        previous.next = null;
        return head;

    }

    public static void reverse(MyLinkedList list, Node current) {
        if (current.next == null) {
            list.head = current;
            return;
        }
        Node previous = current;
        current = current.next;
        reverse(list, current);
        current.next = previous;
        previous.next = null;
    }

    // Delete N nodes after M nodes of a linked list
//Given a linked list and two integers M and N. Traverse the linked list such that you retain M nodes then delete next N nodes, continue the same till end of the linked list.
    public static Node deleteNnodesAfterEachMNodes(Node node, int m, int n) {
        if (node == null) {
            return node;
        }
        if (m < 0 || n <= 0) {
            return node;
        }
        if (m == 0) {
            return null;
        }
        int keepCount = 1, deleteCount = 0;
        Node temp = null, mark = null;
        Node head = node;
        while (node != null) {
            keepCount = 1;
            deleteCount = 0;

            while (keepCount < m && node != null) {
                node = node.next;
                keepCount++;
            }
            mark = node;
            if (mark == null) {
                break;
            }
            while (deleteCount < n && node != null) {
                node = node.next;
                deleteCount++;
            }
            if (node == null) {
                mark.next = null;
                break;
            }
            if (n > 0) {
                temp = node.next;
                node.next = null;
                mark.next = temp;
            }
            node = mark.next;
        }
        return head;
    }

    public static void swapKthElementFromStart_KthElementFromEnd(Node node, int k) {
        Node current = node, k_Minus_One_From_Start = null, k_Minus_One_From_End = null;
        int countStart = 1, countEnd = 1;
        if (node == null) {
            return;
        }
        if (node.next == null) {
            return;
        }
        //while (true) {
        while (countStart < k-1 && current != null) {
            current = current.next;
            countStart++;
            countEnd++;
        }
        if (current == null) {
            return  ;
        }
        k_Minus_One_From_Start = current;
        while (current.next != null) {
            current = current.next;
            countEnd++;
        }
        int diff = countEnd - (2 * k - 1);
        if (diff == 0) {
            return;
        }
        countStart = 1;
        if (diff > 0) {
            current = k_Minus_One_From_Start;
            while (countStart < diff) {
                current = current.next;
                countStart++;
            }
            k_Minus_One_From_End = current;
        } else {
            current = node;
            int mark = countEnd - k;
            while (countStart < mark) {
                current = current.next;
                countStart++;
            }
            k_Minus_One_From_End = current;
        }
        swap(k_Minus_One_From_Start, k_Minus_One_From_End);
    }

    private static boolean swap(Node node1, Node node2) {
        if ((node1 == null || node1.next == null)
                || (node2 == null || node2.next == null)) {
            return false;
        }
        Node temp = node1.next;
        node1.next = node2.next;
        node2.next = temp;
        temp = node1.next.next;
        node1.next.next = node2.next.next;
        node2.next.next = temp;
        return true;
    }

    public static void main(String[] args) {
        int arr[] = new int[]{1, 2, 3, 4, 5};//97 ,92 ,81 ,95 ,2 ,78 ,97 ,86 ,42 ,74};//{10, 13, 10, 4, 5, 6, 7, 8, 43, 9, 15, 25, 11, 14, 9, 6, 8, 7, 18, 19};
        MyLinkedList list = new MyLinkedList();
        for (int i = 0; i < arr.length; i++) {
            list.insert(arr[i]);
        }
        printList(list.head);
        swapKthElementFromStart_KthElementFromEnd(list.head, 1);
        printList(list.head);

        //       list.reverseInPair();
        //     list.printList();
//        MyLinkedList list1 = new MyLinkedList();
//        for (int i = 0; i <= 20; i++) {
//            list1.insert(Math.round((float) (Math.random() * 100)));
//        }
        //mergeTwoList(list, list1);
        // printList(list1.head);
        // sort_list(list1);
        //list.head = reverseList_recursive(list.head);
        // reverse(list, list.head);
        //  list.head=recurse2(list.head);
        //recursive(list.head);
        //list1.head = deleteNnodesAfterEachMNodes(list1.head, 2, 3);
        //printList(list1.head);
    }

}
