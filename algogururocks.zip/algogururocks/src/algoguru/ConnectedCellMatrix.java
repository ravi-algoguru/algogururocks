/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algoguru;

/**
 *
 * @author admin
 */
public class ConnectedCellMatrix {
    public int findNumberForLargestConnectedRegion(int[][] inputMatrix, boolean[][] backTracingMatrix, int m, int n) {
                 int currentDepth = 0;
		 if (m >= 0 && m < inputMatrix.length && n >= 0 && n < inputMatrix[0].length
				&& backTracingMatrix[m][n] != true && inputMatrix[m][n] != 0) {
			currentDepth++;

		 	backTracingMatrix[m][n] = true;
                        findNumberForLargestConnectedRegion(inputMatrix, backTracingMatrix, m - 1, n);
 			findNumberForLargestConnectedRegion(inputMatrix, backTracingMatrix, m + 1, n);
 			findNumberForLargestConnectedRegion(inputMatrix, backTracingMatrix, m, n - 1);
 			findNumberForLargestConnectedRegion(inputMatrix, backTracingMatrix, m, n + 1);
 			findNumberForLargestConnectedRegion(inputMatrix, backTracingMatrix, m + 1, n + 1);
 			findNumberForLargestConnectedRegion(inputMatrix, backTracingMatrix, m - 1, n - 1);
 			findNumberForLargestConnectedRegion(inputMatrix, backTracingMatrix, m + 1, n - 1);
 			findNumberForLargestConnectedRegion(inputMatrix, backTracingMatrix, m - 1, n + 1);
		}
		return currentDepth;
	}
}
