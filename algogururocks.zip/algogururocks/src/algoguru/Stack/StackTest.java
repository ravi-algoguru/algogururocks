/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package algoguru.Stack;

import algoguru.doublyLinkedList.DoublyLinkedList;
import static algoguru.doublyLinkedList.DoublyLinkedListTest.printList;
import algoguru.doublyLinkedList.Node;

/**
 *
 * @author ravi
 */

interface Stack{
    int pop();
    void push(int data);
    int findMiddle();
    void deleteMiddle();
    void print();
    void pushAtMiddle(int data);
}

class StackImpl implements Stack{
    private DoublyLinkedList dataStack ;
    private int top = 0, middle = 0;
    Node middleNode,topNode;
    private Object emptyMark = new Object();
    
    public StackImpl() {
        this.dataStack = new DoublyLinkedList();
    }
        
    @Override
    public int pop() {
        int obj ;
        if(top > 0){
             obj = topNode.data;
             dataStack.delete(topNode);
             top--;
             if( top > 1 ){
               if(middle < top/2)
                   middleNode = middleNode.previous;
             }else {
                 middle = -1;
                 middleNode = null;
             }
        }
             return topNode.data;
    }

    @Override
    public void push(int data) {
        topNode = dataStack.insertAtEnd(data);
        if(top <=  0) {
            top = 1;
        }else
            top++;
        if(top > 1 && middle < (top+1)/2){
            if(middle == 0)
                middleNode = topNode.previous;
            else middleNode = middleNode.next;
            middle += 1;  
            }       
    }

    @Override
    public int findMiddle() {
        return middleNode.data;
     }

    @Override
    public void deleteMiddle() {
      if(top <= 1) return;
      Node ref = middleNode.previous;
      dataStack.delete(middleNode);
      top -=1; 
      int temp = (top+1)/2;
      if(temp < middle){
          middleNode = ref;
          middle = temp;
      }else{
          middleNode = ref.next;
      };
      }

    @Override
    public void print() {
       dataStack.printList();
    }

    @Override
    public void pushAtMiddle(int data) {
        Node temp =  dataStack.insertInBetween(middleNode, data);
        top++;
        if(middle < (top+1)/2){
            middle++;
            middleNode = temp;
        }
    }
    
}
public class StackTest {
          public static void main(String[] args) {
        int arr[] = new int[]{1,2,3,4,5,6};//97 ,92 ,81 ,95 ,2 ,78 ,97 ,86 ,42 ,74};//{10, 13, 10, 4, 5, 6, 7, 8, 43, 9, 15, 25, 11, 14, 9, 6, 8, 7, 18, 19};
       Stack stack = new StackImpl();
        for (int i = 0; i < arr.length; i++) {
            stack.push(arr[i]);
        }
        stack.print();
        stack.deleteMiddle();
        stack.print();
        stack.pushAtMiddle(10);        
        stack.pushAtMiddle(11);
        stack.pushAtMiddle(12);
        stack.print();
        stack.deleteMiddle();
        stack.print();
        stack.deleteMiddle();
        stack.print();
    }
}
