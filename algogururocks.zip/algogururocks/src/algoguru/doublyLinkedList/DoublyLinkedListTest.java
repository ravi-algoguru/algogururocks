/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package algoguru.doublyLinkedList;

/**
 *
 * @author ravi
 */
public class DoublyLinkedListTest {
        public static void main(String[] args) {
        int arr[] = new int[]{1, 2, 3, 4, 5};//97 ,92 ,81 ,95 ,2 ,78 ,97 ,86 ,42 ,74};//{10, 13, 10, 4, 5, 6, 7, 8, 43, 9, 15, 25, 11, 14, 9, 6, 8, 7, 18, 19};
        DoublyLinkedList list = new DoublyLinkedList();
        for (int i = 0; i < arr.length; i++) {
            list.insertAtEnd(arr[i]);
        }
        printList(list);

        DoublyLinkedList list1 = new DoublyLinkedList();
        for (int i = 0; i <= 20; i++) {
            list1.insertAtEnd(Math.round((float) (Math.random() * 100)));
        }
       // list.insertInBetween(null, data)
        printList(list1);
    }

    public static void printList(DoublyLinkedList list) {
        System.out.print("\nlist   : ");
        Node node = list.head;
        while (node != null) {
            System.out.print(node.data + " ,");
            node = node.next;
        }
    }

}
