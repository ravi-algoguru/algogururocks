/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algoguru.doublyLinkedList;

/**
 *
 * @author ravi
 */
public class DoublyLinkedList {

    Node head;

    public Node insertAtEnd(int data) {
        if (head == null) {
            head = new Node(data);
            return head;
        } else {
            Node node = head;
            while (node.next != null) {
                node = node.next;
            }
            node.next = new Node(data);
            node.next.previous = node;
            return node.next;
        }
    }

    public Node insertInBetween(Node node, int data){
        if(head == null || node == null){
            head = new Node(data);
            return head;
        } 
        if(node.next == null){
            node.next = new Node(data);
            node.next.previous =node;
        }
        else{    
            node.next.previous = new Node(data);
            node.next.previous.next = node.next;
            node.next = node.next.previous;
            node.next.previous = node;
        }
        return node.next;
    }
    public boolean delete(int data) {
        if (head == null) {
            return false;
        }
        Node node = head;
        while (node != null) {
            if (node.data == data) {
                delete(node);
                return true;
            }
            node = node.next;
        }
        return false;
    }

    public void delete(Node node) {
        if(node.previous == null){
            head = node.next;
            node.next = null;
            return;
        }
        if( node.next == null){
            node.previous.next = null;
            node.next = null;
            return;
        }
        node.previous.next = node.next;
        node.next.previous = node.previous;
    }

    public void printList(Node head) {
        System.out.print("\nlist   : ");
        Node node = head;
        while (node != null) {
            System.out.print(node.data + " ,");
            node = node.next;
        }
    }

    public void printList() {
        printList(this.head);
    }

}
