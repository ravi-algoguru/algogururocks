/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package algogururocks;

/**
 *
 * @author alok
 */
public class PermutationAnagram {

    static void doAnagram(String prefix, String suffix){
        if(suffix.length()==1){
            System.out.println(prefix+suffix);
            return;
        }
        for(int i=0;i < suffix.length();i++){
            String a =prefix+suffix.charAt(i);
            String b = suffix.substring(0, i)+suffix.substring(i+1, suffix.length());
            System.out.println(a+":" +b);
            doAnagram(a,b );
        }
    }
    
    static void findSubset(String str){
        for(int i=0;i<str.length();i++)
            doAnagram("", str);
    }
    public static void main(String[] args){
  // doAnagram("", "abcd");
        System.out.println("abcd".substring(0, 0));
   //findSubset("abc");
    }
}
