package algogururocks;


public class MaxMin {

	/**
	 * @param args
	 */
	static int len;
	static int max=0,min=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr={38, 12 ,34 ,23, 11, 23 ,56 ,76,3, 1 ,10 ,-20 ,-50, 29,100};  
		len =arr.length;
		maxMin(arr, len);
	}

	private static void maxMin(int[] arr, int size) {
		// TODO Auto-generated method stub

		if(size==0)
			return;
		if(size==1)
		{
			if(arr[len-1]>max)
				max=arr[len-1];
			if(arr[len-1]<min)
				min=arr[len-1];
			return;
		}
		if(size==2)
		{
			if(	arr[len-1]> arr[len-2])
			{
				max=arr[len-1];
				min=arr[len-2];
			}
			else{
				max=arr[len-2];
				min=arr[len-1];
			}
			return;
		}
		maxMin(arr, size-2);

		if(	arr[len-size]> arr[len-size+1])
		{   
			if(arr[len-size]>max)
				max= arr[len-size];
			if(arr[len-size+1]< min)
				min=arr[len-size+1];
		}
		else if(arr[len-size]< arr[len-size+1])
		{   
			if(arr[len-size]<min)
				min= arr[len-size-1];
			if(arr[len-size+1]> max)
				max=arr[len-size+1];
		}	

		System.out.println(max+ "  "+ min);
	}

}
