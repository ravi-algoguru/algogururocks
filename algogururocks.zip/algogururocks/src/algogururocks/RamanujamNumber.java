/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algogururocks;

/**
 *
 * @author alok
 */
public class RamanujamNumber {

    static long[] cubeArray = new long[10000];
    static int count = -1;
    static long pSum = 1,  a = 1,  b = 1;

    static void findCuberoot(long i) {
        long k = 1;
        // int count=-1;
        while (k * k * k <= i) {
            cubeArray[++count] = k;
            k++;
        }
        System.out.println(--k);
    }

    static void ramanujamNumber(long n) {
        findCuberoot(n);
        System.out.println("find all those two numbers whose sum is a given num : " + n);
        long num = cubeArray[count];
        int i = 1;
        while (i <= n) {
            findCubeSetBySum(i++);
        }
    }

    static void findCubeSetBySum(long n) {
        int i = 0, j = count;
        while (i < j) {
            long x = cubeArray[i];
            long y = cubeArray[j];
            long u = x + 1, v = y + 1;
            long sum = x * x * x + y * y * y;
            if (sum > n) {
                j--;
            } else if (sum < n) {
                i++;
            } else {
                if (pSum == sum) {
                    System.out.println(x + "^3" + "+" + y + "^3  =" + a + "^3+" + b + "^3=" + sum);
                //  System.out.print("\n");
                }
                i++;
                j--;
                pSum = sum;
                a = x;
                b = y;
            }
//            if(x*x*x + y*y*y <= n && (u*u*u+y*y*y >n)||(x*x*x+v*v*v>n))
//            { System.out.println(x+"^3" + "+"+ y+"^3 ="+(x*x*x + y*y*y));
//            i++;j--;}
//            else if ( x*x*x+ y*y*y > n) {
//               j--;
//            } else if (x*x*x+ y*y*y < n) {
//               i++;
//        }
        }
    }

    public static void main(String[] args) {
        ramanujamNumber(100000);
    }
}
