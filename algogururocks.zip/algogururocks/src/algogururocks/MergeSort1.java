package algogururocks;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class MergeSort1 {
	public static void mergeSort(int[] arr1) // called by main()
	{ // provides workspace
		double[] workSpace = new double[arr1.length];

		doMergeSort(workSpace, 0, arr1.length);
	}
	private static void doMergeSort(double[] workSpace, int lowerBound,int upperBound)
	{
		if(lowerBound == upperBound) // if range is 1,
			return; // no use sorting
		else
		{ // find midpoint
			int mid = (lowerBound+upperBound) / 2;
//			sort low half
			doMergeSort(workSpace, lowerBound, mid);
//			sort high half
			doMergeSort(workSpace, mid+1, upperBound);
//			merge them
			merge(workSpace, lowerBound, mid+1, upperBound);
		} // end else
	} // end recMergeSort

	private static void merge(double[] workSpace, int lowPtr,
			int highPtr, int upperBound)
	{
		int j = 0; // workspace index
		int lowerBound = lowPtr;
		int mid = highPtr-1;
		int n = upperBound-lowerBound+1; // # of items
		int[] theArray=new int[highPtr-lowPtr];
		while(lowPtr <= mid && highPtr <= upperBound)
			if( theArray[lowPtr] < theArray[highPtr] )
				workSpace[j++] = theArray[lowPtr++];
			else
				workSpace[j++] = theArray[highPtr++];
		while(lowPtr <= mid)
			workSpace[j++] = theArray[lowPtr++];
		while(highPtr <= upperBound)
			workSpace[j++] = theArray[highPtr++];
		for(j=0; j<n; j++)
			theArray[lowerBound+j] = (int) workSpace[j];
		display(theArray);

	} // end merge()
	public static void display(int[] arr) // displays array contents
	{
		for(int j=0; j<arr.length; j++) // for each element,
			System.out.print(arr[j] + " "); // display it
		System.out.println("");
	}

	public static void main(String[] args) throws IOException
	{
		System.out.println("enter first array");
		InputStreamReader isr1 = new InputStreamReader(System.in);
		BufferedReader br1 = new BufferedReader(isr1);
		String s1 = br1.readLine();
		String [] str1=s1.split(" ");
		int[] intArr1 = new int[str1.length];
		for(int i=0;i< str1.length-1;i++)
			intArr1[i]= Integer.parseInt(str1[i]);

		//mergeSort(intArr1); // mergesort the array
		// display items again
		mergeSort1(intArr1);
	} // end main()
	public static void mergeSort1(int[] arr)
	{
		int h=arr.length-1;
		mergeSort1(arr,0,h);
		for(int i=0;i<h;i++)
		System.out.println(arr[i]);
	}

	private static void mergeSort1(int[] arr,int l, int h)
	{
		if(l==h)
			return;
		int m=(l+h)/2;
		/*if(h-l==1)
		{
			if(arr[l]>arr[h])
			{
				arr[l]=arr[l]+arr[h];
				arr[h]=arr[l]-arr[h];
				arr[l]=arr[l]-arr[h];
			}
			return;
		}*/
		
		{   mergeSort1(arr, l, m);
		mergeSort1(arr,m+1,h);
		merge1(arr,l,m,h);
		}
		
	}
	private static void merge1(int[] arr, int l, int m, int h) {
		// TODO Auto-generated method stub
		int k=m;
		int j=m+1;
		int temp=0;
		int[]arr1=new int[h+1];
		while(l<=k && j<=h)
		{
			if(arr[l]<arr[j])
			{
				arr1[temp]=arr[l];
				temp++;
				l++;
			}else if(arr[l]>arr[j])
			{
				arr1[temp]=arr[j];
				temp++;
				j++;
			}
		}
		while(temp<=h)
		{
			if(l==k)
			{
				arr1[temp]=arr[j];
				temp++;
				j++;
			}
			if(j==h)
			{
				arr1[temp++]=arr[l++];
			    temp++;
			    l++;
			}
		}
	}
}
