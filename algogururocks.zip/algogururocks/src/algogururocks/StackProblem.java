/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package algogururocks;

import java.util.Stack;

/**
 *
 * @author alok
 */
public class StackProblem {
   static Stack stack;
  static void reverse(){
       reverse(stack);
   }
   private static void reverse(Stack stack){
       while(!stack.isEmpty());
         int[]i=(int[])stack.pop();
   }
   public static void main(String[]args){
   stack=new Stack();
   stack.push(new int[]{1});
   stack.push(new int[]{2});
   stack.push(new int[]{3});
   stack.push(new int[]{4});
   reverse();
   }
}
