/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package algogururocks;

/**
 *
 * @author alok
 */
// Recursive method to find all permutations of a String.

public class Permutation
{
   // recursive declaration of method permuteString
      public static void permuteString(String str)
      {
          permuteString("",str);
      }
   private static void permuteString(
      String prefix, String str )
   {
      // base case: if string to permute is length less than or equal to
      // 1, just display this string concatenated with beginningString
      if ( str.length() <= 1 )
         System.out.println( prefix + str );
      else // recursion step: permute endingString
      {
         // for each character in endingString
         for ( int i = 0; i < str.length(); i++ )
         {
            try
            {
               // create new string to permute by eliminating the
               // character at index i
              // recursive call with a new string to permute
               // and a beginning string to concatenate, which
               // includes the character at index i
               permuteString(prefix+str.charAt(i), str.substring( 0, i ) + str.substring( i + 1) );
            } // end try
            catch ( StringIndexOutOfBoundsException exception )
            {
               exception.printStackTrace();
            } // end catch
         } // end for
      } // end else
   } // end method permuteString
   
  public static void main(String[] args) {
        System.out.println("enter string");

        String str = new String("ABCD");
        permuteString(str);
    //doAnagram(str);
    }} // end class Permutation

