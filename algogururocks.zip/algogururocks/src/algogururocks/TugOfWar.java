/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algogururocks;

/**
 *
 * @author alok
 */

public class TugOfWar {

    private static String createTeams(int[] children) {
        int sum = 0, maxWeight, number, i, j, k, newWeight, optimum;
        int[][] teams;
        String solution, team2;

        number = children.length;
        for (int child : children) {
            sum += child;
        }
        maxWeight = sum / 2;
        teams = new int[maxWeight + 1][number + 1];
        for (i = 0; i <= maxWeight; i++) {
            for (j = 0; j <= number; j++) {
                teams[i][j] = 0;
            }
        }
        teams[0][0] = 1;
        for (int a = 0; a <= number; a++) {
            for (int b = 0; b <= maxWeight; b++) {
                System.out.print(teams[b][a] + " ,");
            }
            System.out.println("\n");
        }
        for (i = 0; i < number; i++) {
            for (j = maxWeight; j >= 0; j--) {
                if ((teams[j][0])==1 && (j + children[i] <= maxWeight)
                        && (teams[j + children[i]][0])==0) {
                      System.out.print("\n"+i + "," + j+ " ; \n");
                    newWeight = j + children[i];
                    for (k = 0; k <= number; k++) {
                        teams[newWeight][k] = teams[j][k];
                    }
                    teams[newWeight][i + 1] = 1;
                   // System.out.println("\n i,j : " +i+","+j+"\n");
                    for (int a = 0; a <= number; a++) {
                        for (int b = 0; b <= maxWeight; b++) {
                            System.out.print(teams[b][a] + " ,");
                        }
                        System.out.println("\n");
                    }
                }
            }
        }
        optimum = maxWeight;
        while (teams[optimum][0]==0) {
            optimum--;
        }
        solution = "Team 1:";
        team2 = "";
        for (i = 0; i < number; i++) {
            if (teams[optimum][i + 1]==1) {
                solution += " " + children[i];
            } else {
                team2 += " " + children[i];
            }
        }
        solution += "\nTeam 2:" + team2 + "\nThe weight difference is " + Math.abs(2 * optimum - sum);
        System.out.println("\n");
        for (int a = 0; a <= number; a++) {
            for (int b = 0; b <= maxWeight; b++) {
                System.out.print(teams[b][a] + " ,");
            }
            System.out.println("\n");
        }
        return solution;
    }

    public static void main(String[] args) {

        int[] arr = {4,2,3,8};
        System.out.println(createTeams(arr));
    }
}