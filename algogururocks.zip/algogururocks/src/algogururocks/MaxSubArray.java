package algogururocks;

/**
 * Kadane's Algorithm(arr[1..n]) begin (max, a, b) := (-INFINITY, 0, 0) curr :=
 * 0 aa := 1 for bb := 1 to n do curr := curr + arr[bb] if curr > max then (max,
 * a, b) := (curr, aa, bb) endif
 *
 * if curr < 0 then curr := 0 aa := bb + 1 endif endfor
 *
 * return (max, a, b) end
 *
 *
 * #include <stdio.h>
 *
 * #define SIZEOF(arr) (sizeof(arr)/sizeof(arr[0]))
 *
 * int arr[] = { 2, -3, 4, -1, 5, -1, -3, 6, -1, -1, -4, 2, -1};
 *
 * void MaxSum(int arr[],int length) { int max,sum; int i = 0 ;
 *
 * max = sum = arr[0];
 *
 * for(i=1;i<length;i++) { sum += arr[i]; if(sum > max) { max = sum; }
 *
 * if(sum < 0) { sum = 0; } } printf("The max sum is : %d\n",max); }
 *
 *
 * void PrintArray(int arr[],int size) { int i; for(i=0;i<size;i++) printf("%d
 * ",arr[i]); printf("\n"); }
 *
 * int main() { PrintArray(arr,SIZEOF(arr)); MaxSum(arr,SIZEOF(arr)); return 0;
 * } @author alok
 */
public class MaxSubArray {

    // linear time
    public static void maxSubArray_Kadane(int[] arr) {
        int sum = 0,
                max = Integer.MIN_VALUE,
                a = 0, b = 0, i = 0;

        for (int j = 0; j < arr.length; j++) {
            sum += arr[j];
            if (sum < 0) {
                sum = 0;
                i = j + 1;
            } else if (sum > max) {
                max = sum;
                a = i;
                b = j;
            }
        }

        int[] res = {max, a, b};
        System.out.println("sum : " + res[0] + ", start:" + res[1] + ", end: " + res[2] + "\n elements : ");
        int k = a;

        while (k <= b) {
            System.out.print(arr[k++] + " , ");
        } 
   }

    public static void maxSubArray(int[] arr) {
        maxSubArray(arr, 0, arr.length - 1);
    }

    // nlogn
    private static int maxSubArray(int[] a, int low, int high) {
        int leftSum = 0, rightSum = 0;
        int sum = 0;

        if (low == high) { // Base case
            return a[low];
        }

        int mid = (low + high) >> 1; // (low + high) / 2
        int maxLeftSum = maxSubArray(a, low, mid);
        int maxRightSum = maxSubArray(a, mid + 1, high);
        int left = 0;
        int right = 0;
        //max-crossing-subarray
        for (int i = mid; i >= low; i--) {
            sum += a[i];
            if (sum > leftSum) {
                leftSum = sum;
                left = i;
            }
        }
        sum = 0;
        for (int i = mid + 1; i <= high; i++) {
            sum += a[i];
            if (sum > rightSum) {
                rightSum = sum;
                right = i ;
            }
        }
        System.out.println("low :" +left + " ,   high :"+ right );
        return max3(maxLeftSum, maxRightSum, (leftSum + rightSum));
    }

    private static int max3(int a, int b, int c) {
        return a > b ? (a > c ? a : c) : (b > c ? b : c);
    }

    public static void main(String[] args) {
        int[] arr = {
            -5, 71, 23, 41, 34, 1, 3, 6, 2, 91, 312, 42, 31, 67, 12, 10, 18, 56, 90, 21, 45, 47, 89,100000,
            78, -7, 76, 75, 74, 73, 72, 80, 24, 25, 61, 69, 84, 0, -1, 145, 1902, 200, 199, 198, 197, 196, 195, 194,
            78, 77, 76, 75, 74, 73, 72, 80, 24, 25, 61, 69, 84, 0, -1, 145, 1902, 200, 199, 198, 197, 196, 195, 194,
            5, 71, 23, 41, 34, 1, 3, 6, 2, 91, 312, 42, 31, 67, 12, -1000, 18, 56, 90, 21, 45, 47, 89, -100
        };
     //   int[] arr = new int[]{13, -3, -25, 20, -3, -16, -23, 18, 20, -7, 12, -95,-22,15, -4, 70};
        int maxSum = maxSubArray(arr, 0, arr.length - 1);
        System.out.println("Max sum is " + maxSum);
        maxSubArray_Kadane(arr);

    }

 
}
