/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algogururocks;

/**
 *
 * @author alok
 */
public class LongestCommonSubstring {

    public static String longestSubstr(String str, String toCompare) {
        if (str == null || toCompare == null) {
            return null;
        }
        int[][] compareTable = new int[str.length()][toCompare.length()];
        int maxLen = 0;
        StringBuilder res = new StringBuilder();
        int m = 0, n = 0;
        for (; m < str.length(); m++) {
            for (; n < toCompare.length(); n++) {
                compareTable[m][n] = (str.charAt(m) != toCompare.charAt(n)) ? 0
                        : (((m == 0) || (n == 0)) ? 1
                        : compareTable[m - 1][n - 1] + 1);
                maxLen = (compareTable[m][n] > maxLen) ? compareTable[m][n]
                        : maxLen;
            }
        }
        for (int i = m + 1 - maxLen; i < m; i++) {
            res.append(str.charAt(i));
        }
        return res.toString();
    }

    /**
     * @param s1
     * @param s2
     * @return
     */
    public static String find_lcss(String s1, String s2) {
        if (s1 == null || s2 == null) {
            return "";
        }
        int[][] table = new int[s1.length()][s2.length()];
        int maxLen = 0;
        int end_index = 0;

        for (int i = 0; i < s1.length(); i++) {
            for (int j = 0; j < s2.length(); j++) {
                if (s1.charAt(i) != s2.charAt(j)) {
                    table[i][j] = 0;
                } else {
                    if (i == 0 || j == 0) {
                        table[i][j] = 1;
                    } else {
                        table[i][j] = table[i - 1][j - 1] + 1;
                    }
                }
                if (maxLen < table[i][j]) {
                    maxLen = table[i][j];
                    end_index = i;
                }
            }
        }
       
        StringBuilder res = new StringBuilder();
        for (int i = end_index + 1 - maxLen; i <= end_index ; i++) {
            res.append(s1.charAt(i));
        }
        return res.toString();
//System.out.println(end_index);
    }

    public static void main(String[] args) {
// TODO Auto-generated method stub
        String s1 = "It is snowing and I want to drive home.";
        String s2 = "It is snowing and I want to go skiing.";
        String s3 = "It is hot and I want to go swimming.";
        String len = find_lcss(s1, s2);
        len = find_lcss(len, s3);
//System.out.println("The length of longest: " + len);
        System.out.println(s1.replace(len, " "));
        System.out.println(s2.replace(len, " "));
        System.out.println(s3.replace(len, " "));

    }
}
