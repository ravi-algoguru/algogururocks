package algogururocks;


public class MergeWithoutExtraSpace {

	public static void main(String[] args)
	{
	int[] arrayA = {23, 47, 81, 95};
	int[] arrayB = {7, 14, 39, 55, 62, 74};
	
	merge(arrayA,arrayB);
	} // end main()
//	----------------------------------------------------------

//	 merge A and B into C
	public static void merge( int[] arrayA,int[] arrayB)
	{
	int aDex=0, bDex=0,tempDex=0;
	int sizeA=arrayA.length;
	int sizeB=arrayB.length;
	int[] tempArray=new int[sizeA+sizeB];
	while(aDex < sizeA && bDex < sizeB) // neither arrayempty
	if( arrayA[aDex] < arrayB[bDex] )
		tempArray[tempDex++] = arrayA[aDex++];
	else
		tempArray[tempDex++] = arrayB[bDex++];
	while(aDex < sizeA) // arrayB is empty,
		tempArray[tempDex++] = arrayA[aDex++]; // but arrayA isn't
	while(bDex < sizeB) // arrayA is empty,
		tempArray[tempDex++] = arrayB[bDex++]; // but arrayB isn't
	display(tempArray);
	} // end merge()
//	----------------------------------------------------------

//	 display array
	public static void display(int[] theArray)
	{
	for(int j=0; j<theArray.length; j++)
	System.out.print(theArray[j] + " ");
	System.out.println("");
	}
//	----------------------------------------------------------

}
