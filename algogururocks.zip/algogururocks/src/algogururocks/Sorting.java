/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package algogururocks;

/**
 *
 * @author alok
 */
public class Sorting {
  
    public static void MergeSort(int[] arr){
        int len=arr.length-1;
        int[]res=new int[arr.length];
        MergeSort( arr,res,0, len);
       print(arr);
    }
    private static void MergeSort(int[] arr,int[]res, int start, int end){
        if(end==start) return ;
        int mid=(end+start)/2;
        MergeSort(arr,res , start, mid );
        MergeSort(arr, res,mid+1, end);
         Merge(arr ,res,start, mid, end);
        return ;
     }
    
    private static void Merge(int[] arr,int[] res,int start, int mid, int end){
       // int[] res=new int[end-start+1];
        int j=mid+1,i=start,count=-1;
        while(i<=mid && j<=end){
            if(arr[i]< arr[j])
                res[++count]=arr[i++];
            else res[++count]=arr[j++];
        }
         while(i<=mid)
            res[++count]=arr[i++];
         while(j<=end)
            res[++count]=arr[j++];  
        System.arraycopy(res, 0 , arr, start, count+1);
    }
     public static void print(int[]arr){
         for(int i:arr)
             System.out.print(i+" , ");
     }
     
       public static void QuickSort(int[]arr){
        if(arr==null)return;
        QuickSort(arr,0,arr.length-1);
        print(arr);
    }
    
    private static void QuickSort(int[]arr,int left, int right){
        if(left< 0 || right >= arr.length || left >= right)return;
        int i=left,j=right,current=left+1;
        int pivot=arr[left];
        while(current <=j){
            if(arr[current]< pivot){
                Swap(arr,i+1,current);
                i++;
                current++;
            }else if(arr[current]> pivot) current++;
            else{
                Swap(arr, j, current);
                --j;
            }
        }
        Swap(arr,i, left);
        for(int k=i, count=1;k<=j && count <= right-j;count++)
        {
            arr[j+count]=arr[k+count];
            arr[k+count]=pivot;
        }
        QuickSort(arr, left,i-1);
        QuickSort(arr,i+(right-j+1),right);
    }

    public static void Swap(int[]arr, int i,int j){
               int temp= arr[i];
               arr[i]=arr[j];
               arr[j]=temp;
    }
    
      public static void main(String[]args){
         int[] arr=new int[]{5,2,6,4,3,1,5,3,8,4,9,3,10,3,7,4,2,1,5,8,-1,-11,-11111,0000,20,80,34,34,2,3,12,32,12,34};  
         //MergeSort(arr);
         QuickSort(arr);
     }
}
