/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algogururocks;

/**
 *
 * @author alok
 */
public class MaxSumSubset {

    int[] findMaxSubset(int[] arr) {
          int sum = 0,
                max = Integer.MIN_VALUE,
                a = 0, b = 0,  i = 0;
          
        for (int j = 0; j < arr.length; j++) {
            sum += arr[j];
            if (sum < 0) {
                sum = 0;
                i = j + 1;
            } else if ( sum>max) {
                max=sum;
                a=i;b=j;
            }
        }
      int[] res={max,a,b};
        return res;
    }

    public static void main(String[] args) {
        int[] arr ={-1000,1,5,-3,4,-6,7,100,-1,-200,4 , 5, -10,20, 3, 4, 6, -8};
        //{-1, 4, 5, -10, 20, 3, 4, 6, -8};
        MaxSumSubset s = new MaxSumSubset();
        int[] res = s.findMaxSubset(arr);
         System.out.println("sum : " + res[0]);
         for(int i=res[1];i<=res[2];i++) System.out.print(arr[i]+" ,");

      
    }
}
