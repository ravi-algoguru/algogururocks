/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algogururocks;

/**
 *
 * @author alok
 */
public class Sudoko {

    public static void main(String[] args) {
        main();
    }

    static void main() {
        Square[][] board = new Square[9][9];
        initBoard(board);
        placeNumbers(board);
        printBoard(board);
    }

    static void initBoard(Square[][] board) {
        int[][] b = init();

        for (int r = 0; r < board.length; r++) {

            for (int c = 0; c < board.length; c++) {
                Square cell = new Square();
                board[r][c] = cell;
                board[r][c].val = b[r][c];
            }
        }
        setPossibles(board);
    }

    static void placeNumbers(Square[][] b) {

        while (hasEmptySpace(b)) {
            makeMove(findMove(b), b);
        }
    }

    static void printBoard(Square[][] b) {

        for (int r = 0; r < b.length; r++) {
            System.out.println(" ");

            for (int c = 0; c < b.length; c++) {

                if (b[r][c].val == 0) {
                    System.out.print("   ");
                } else {
                    System.out.print(" " + b[r][c].val + " ");
                }
            }
        }
    }

    static Coord findMove(Square[][] b) {
        Coord co = new Coord();

        for (int r = 0; r < b.length; r++) {

            for (int c = 0; c < b.length; c++) {

                if (b[r][c].val == 0 && unique(b[r][c].possibles)) {
                    co.row = r;
                    co.col = c;
                }
            }
        }
        return co;
    }

    static void makeMove(Coord c, Square[][] b) {
        int num = value(b[c.row][c.col].possibles);
        b[c.row][c.col].val = num;
        removeImpossibles(num, c.row, c.col, b);
    }

    static int[][] init() {
        int[][] b = {{1, 0, 6, 0, 9, 4, 0, 0, 0}, 
        {8, 0, 2, 1, 0, 0, 0, 3, 0},
        {0, 0, 0, 0, 5, 0, 0, 0, 0}, 
        {0, 0, 0, 0, 0, 0, 3, 0, 6},
        {3, 6, 0, 0, 2, 0, 0, 8, 4}, 
        {2, 0, 7, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 6, 0, 0, 0, 0}, 
        {0, 1, 0, 0, 0, 8, 5, 0, 2},
        {0, 0, 0, 5, 3, 0, 9, 0, 7}};
        return b;
    }

    static boolean hasEmptySpace(Square[][] b) {

        for (int r = 0; r < b.length; r++) {

            for (int c = 0; c < b.length; c++) {

                if (b[r][c].val == 0) {
                    return true;
                }
            }
        }
        return false;
    }

    static boolean unique(boolean[] list) {
        int count = 0;

        for (int i = 1; i < list.length; i++) {

            if (list[i]) {
                count++;
            }
        }
        return count == 1;
    }

    static int value(boolean[] list) {
        assert (unique(list)) :
                "you need a look ahead, as this is a hard game";

        for (int i = 1; i < 10; i++) {

            if (list[i]) {
                return i;
            }
        }
        return 0;
    }

    static void setPossibles(Square[][] b) {

        for (int r = 0; r < b.length; r++) {

            for (int c = 0; c < b.length; c++) {

                if (b[r][c].val != 0) {
                    removeImpossibles(b[r][c].val, r, c, b);
                }
            }
        }
    }

    static void removeImpossibles(int n, int r, int c, Square[][] b) {
        unSetInRow(n, r, b);
        unSetInCol(n, c, b);
        unSetInSquare(n, r, c, b);
    }

    static void unSetInRow(int n, int r, Square[][] b) {

        for (int i = 0; i < b.length; i++) {
            b[r][i].possibles[n] = false;
        }
    }

    static void unSetInCol(int n, int c, Square[][] b) {

        for (int i = 0; i < b.length; i++) {
            b[i][c].possibles[n] = false;
        }
    }

    static void unSetInSquare(int n, int r, int c, Square[][] s) {
        r = (r / 3) * 3;
        c = (c / 3) * 3;

        for (int i = r; i < r + 3; i++) {

            for (int j = c; j < c + 3; j++) {
                s[i][j].possibles[n] = false;
            }
        }
    }

    static void printSquare(Square s) {
        System.out.print("val = " + s.val);

        for (int i = 0; i < s.possibles.length; i++) {

            if (s.possibles[i]) {
                System.out.print("t ");
            } else {
                System.out.print("f ");
            }
        }
        System.out.println();
    }

    static void printBoardStructure(Square[][] b) {

        for (int r = 0; r < b.length; r++) {

            for (int c = 0; c < b.length; c++) {
                printSquare(b[r][c]);
            }
        }
    }
}

class Square {

    int val = 0;
    boolean[] possibles = {true, true, true, true, true, true, true, true, true, true};
}

class Coord {

    int row = 0;
    int col = 0;
}
