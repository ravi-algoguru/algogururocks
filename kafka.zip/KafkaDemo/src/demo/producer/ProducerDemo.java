package demo.producer;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

//import java.util.Properties;
//
//import kafka.javaapi.producer.Producer;
//import kafka.producer.KeyedMessage;
//import kafka.producer.ProducerConfig;
//
//
//
//
//
//
//@SuppressWarnings("deprecation")
//public class ProducerDemo {
//	public static void main(String[] a)
//	{
//		Properties p = new Properties();
//		p.put("zk.connect", "prashant02.mylaabs.com:2181");
//		p.put("serializer.class", "kafka.serializer.StringEncoder");
//		p.put("metadata.broker.list", "prashant02.mylabs.com:9000,prashant02.mylabs.com:9001");
//		
//		ProducerConfig producerConfig = new ProducerConfig(p);
//		
//		Producer prod = new Producer (producerConfig);
//		
//		prod.send(new KeyedMessage("DemoTopic1", "hi there.. This is swati!!"));
//		prod.close();
//		
//	}
//
//}


public class ProducerDemo {
	public static void main(String[] a)
	{
		Properties props = new Properties();
		props.put("bootstrap.servers", "prashant02.mylabs.com:9000");
		props.put("acks", "all");
		props.put("retries", 0);
		props.put("batch.size", 16384);
		props.put("linger.ms", 1);
		props.put("buffer.memory", 33554432);
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

		Producer<String, String> producer = new KafkaProducer<>(props);
		for(int i = 0; i < 25; i++)
		    producer.send(new ProducerRecord<String, String>("DemoTopic", Integer.toString(i), Integer.toString(i)));

		producer.close();
		
	}

}
