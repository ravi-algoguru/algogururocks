package demo.producer.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;
import kafka.javaapi.producer.Producer;

public class ProducerMysqlDemo {
	
	private static Connection con;
    public static Statement getStatement() throws Exception
    {
    	Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306","root", "root");
		Statement stmt = con.createStatement();
		return stmt;
    }
    
	public static void main(String[] a) throws Exception
	{
		System.out.println("=============MYSQL PRODUCER=============");
		

		Statement stmt = getStatement();
		
		ResultSet resultSet = stmt.executeQuery("SELECT * FROM test.emp");
		
		Properties p = new Properties();
		p.put("zk.connect", "prashant02.mylaabs.com:2181");
		p.put("serializer.class", "kafka.serializer.StringEncoder");
		//p.put("serializer.class", "demo.encoder.ByteEncoder");
		p.put("metadata.broker.list", "prashant02.mylabs.com:9000,prashant02.mylabs.com:9001");
		
		ProducerConfig producerConfig = new ProducerConfig(p);
		
		Producer prod = new Producer (producerConfig);
		
		while(resultSet.next())
		{
			prod.send(new KeyedMessage("DemoTopic", ""+resultSet.getInt(1) +",'"+resultSet.getString(2)+"'"));
			System.out.println("Emp ID =="+ resultSet.getInt(1) +", Emp Name=="+resultSet.getString(2));
			
		}
		
		stmt.close();
		con.close();
		
		
		
		
		prod.close();
		
	}

}
