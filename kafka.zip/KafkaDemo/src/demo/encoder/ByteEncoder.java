package demo.encoder;


import kafka.serializer.Encoder;
import kafka.utils.VerifiableProperties;

public class ByteEncoder implements Encoder<String> {
   

    public ByteEncoder(VerifiableProperties verifiableProperties) {
        /* This constructor must be present for successful compile. */
    }

    @Override
    public byte[] toBytes(String object) {
        try {
            return ((String)object).getBytes();
        } catch (Exception e) {
           e.printStackTrace();
        }
        return new byte[]{};
    }
}