package demo.encoder;

import kafka.serializer.Encoder;
import kafka.utils.VerifiableProperties;

public class CustomMessageEncoder implements Encoder {
    public CustomMessageEncoder(VerifiableProperties verifiableProperties) {
        /* This constructor must be present for successful compile. */
    }

    @Override
    public byte[] toBytes(Object customMessage) {
        return ((String)customMessage).getBytes();
    }
}