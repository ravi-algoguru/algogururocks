package demo.consumer.lowlevel;


import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import kafka.javaapi.consumer.ConsumerConnector;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;


/**
 * Created by user on 8/4/14.
 */
public class LowLevelKafkaConsumerWithOffsetControl extends  Thread {
    private final static String CLIENT_ID = "SimpleConsumerDemoClient2";
    private final static String TOPIC = "DemoTopic";
   
    private final static String ZOOKEEPER_IDS = "prashant02.mylabs.com:2181";
    private final static String SERVER_IDS = "prashant02.mylabs.com:9000";
    
    private final static String GROUP_ID = "test-group2";
    
    ConsumerConnector consumerConnector ;
    KafkaConsumer<String, String> consumer = null;

    public static void main(String[] argv) throws UnsupportedEncodingException {
    	System.out.println("============LOW LEVEL CONSUMER=============");
        LowLevelKafkaConsumerWithOffsetControl kafkaConsumer = new LowLevelKafkaConsumerWithOffsetControl();
        kafkaConsumer.start();
    }

    public LowLevelKafkaConsumerWithOffsetControl(){
       
//        Properties props = new Properties();
////        props.put("zookeeper.connect",ZOOKEEPER_IDS);
//        props.put("bootstrap.servers", SERVER_IDS);
//        props.put("group.id", GROUP_ID);
//        props.put("enable.auto.commit", "true");
//        props.put("auto.commit.interval.ms", "1000");  
//        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
//        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
//        
//        consumer = new KafkaConsumer<>(props);
//        consumer.subscribe(Arrays.asList(TOPIC));
    	
    	Properties props = new Properties();
        props.put("bootstrap.servers", SERVER_IDS);
        props.put("group.id", GROUP_ID);
        props.put("enable.auto.commit", "false");
        props.put("auto.commit.interval.ms", "1000");
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        consumer = new KafkaConsumer<>(props);
        consumer.subscribe(Arrays.asList(TOPIC));
//        consumer.seekToBeginning(Arrays.asList(new TopicPartition(TOPIC,0),new TopicPartition(TOPIC,1),new TopicPartition(TOPIC,2),new TopicPartition(TOPIC,3),new TopicPartition(TOPIC,4)));
        
        
        
        
    }

    @Override
    public void run() {
    	
    	final int minBatchSize = 10;
        List<ConsumerRecord<String, String>> buffer = new ArrayList<>();
    	int count =0;
        System.out.println("This is beginning...................");
    	while (true) {
    		 ConsumerRecords<String, String> records = consumer.poll(100);
             for (ConsumerRecord<String, String> record : records) {
            	 System.out.printf("partition = %d,offset = %d, key = %s, value = %s%n, timestamp=%d", record.partition(),record.offset(),  record.key(), record.value(), record.timestamp());
            	 buffer.add(record);
             }
             if (buffer.size() >= minBatchSize) {
                System.out.println("Commiting to async mode. Clearing buffer");
                 consumer.commitSync();
                 buffer.clear();
                 if(count<10)
                 {
                	 consumer.seekToBeginning(Arrays.asList(new TopicPartition(TOPIC,0),new TopicPartition(TOPIC,1),new TopicPartition(TOPIC,2),new TopicPartition(TOPIC,3),new TopicPartition(TOPIC,4)));
                	 count++;
                 }
                 
             }
    	}
     

    }

    
}
