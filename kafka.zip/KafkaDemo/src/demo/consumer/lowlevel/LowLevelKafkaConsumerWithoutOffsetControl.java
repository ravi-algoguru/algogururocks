package demo.consumer.lowlevel;


import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import kafka.javaapi.consumer.ConsumerConnector;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;


/**
 * Created by user on 8/4/14.
 */
public class LowLevelKafkaConsumerWithoutOffsetControl extends  Thread {
    private final static String CLIENT_ID = "SimpleConsumerDemoClient2";
    private final static String TOPIC = "DemoTopic";
   
    private final static String ZOOKEEPER_IDS = "prashant02.mylabs.com:2181";
    private final static String SERVER_IDS = "prashant02.mylabs.com:9000";
    
    private final static String GROUP_ID = "test-group2";
    
    ConsumerConnector consumerConnector ;
    KafkaConsumer<String, String> consumer = null;

    public static void main(String[] argv) throws UnsupportedEncodingException {
    	System.out.println("============LOW LEVEL CONSUMER=============");
        LowLevelKafkaConsumerWithoutOffsetControl kafkaConsumer = new LowLevelKafkaConsumerWithoutOffsetControl();
        kafkaConsumer.start();
    }

    public LowLevelKafkaConsumerWithoutOffsetControl(){
       
//        Properties props = new Properties();
////        props.put("zookeeper.connect",ZOOKEEPER_IDS);
//        props.put("bootstrap.servers", SERVER_IDS);
//        props.put("group.id", GROUP_ID);
//        props.put("enable.auto.commit", "true");
//        props.put("auto.commit.interval.ms", "1000");  
//        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
//        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
//        
//        consumer = new KafkaConsumer<>(props);
//        consumer.subscribe(Arrays.asList(TOPIC));
    	
    	Properties props = new Properties();
        props.put("bootstrap.servers", SERVER_IDS);
        props.put("group.id", GROUP_ID);
        props.put("enable.auto.commit", "true");
        props.put("auto.commit.interval.ms", "1000");
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        consumer = new KafkaConsumer<>(props);
        consumer.subscribe(Arrays.asList(TOPIC));
        
        
        
        
    }

    @Override
    public void run() {
    	
    	List<ConsumerRecord<String, String>> buffer = new ArrayList<>();
    	
    	
    	while (true) {
    		 ConsumerRecords<String, String> records = consumer.poll(100);
             for (ConsumerRecord<String, String> record : records)
                 System.out.printf("offset = %d, key = %s, value = %s%n", record.offset(), record.key(), record.value());
         
    
             try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
         }
     

    }

    
}
